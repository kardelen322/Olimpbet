// Comprehensive Mock Data for OLIMPBET Mobile Application

export const mockSportsData = {
  football: {
    name: 'Футбол',
    icon: '⚽',
    popularLeagues: [
      'Премьер-лига', 
      'Лига Чемпионов', 
      'Примера', 
      'Бундеслига', 
      'Серия А'
    ],
    topTeams: [
      'Зенит', 
      'Спартак', 
      'ЦСКА', 
      'Реал Мадрид', 
      'Барселона'
    ],
    upcomingMatches: [
      {
        homeTeam: 'Зенит',
        awayTeam: 'Спартак',
        date: '2024-02-15',
        time: '19:00',
        league: 'Премьер-лига',
        odds: { home: 2.1, draw: 3.5, away: 3.2 }
      },
      {
        homeTeam: 'Реал Мадрид',
        awayTeam: 'Барселона',
        date: '2024-02-16',
        time: '20:00',
        league: 'Примера',
        odds: { home: 1.9, draw: 3.8, away: 4.1 }
      }
    ]
  },
  
  esports: {
    name: 'Киберспорт',
    icon: '🎮',
    popularGames: [
      'CS:GO', 
      'Dota 2', 
      'League of Legends', 
      'Valorant', 
      'Rocket League'
    ],
    topTeams: [
      'Natus Vincere', 
      'Virtus.pro', 
      'Team Liquid', 
      'FaZe Clan', 
      'G2 Esports'
    ],
    liveMatches: [
      {
        team1: 'Natus Vincere',
        team2: 'Virtus.pro',
        game: 'CS:GO',
        tournament: 'BLAST Premier',
        score: { team1: 10, team2: 5 },
        currentMap: 'Dust 2'
      },
      {
        team1: 'Team Liquid',
        team2: 'FaZe Clan',
        game: 'Dota 2',
        tournament: 'The International',
        score: { team1: 15, team2: 12 },
        currentMap: 'Main Stage'
      }
    ]
  },

  betting: {
    totalBets: 245678,
    totalVolume: '₽124,567,890',
    popularBetTypes: [
      { name: 'Исход матча', percentage: 45 },
      { name: 'Тоталы', percentage: 25 },
      { name: 'Форы', percentage: 15 },
      { name: 'Экспресс', percentage: 10 },
      { name: 'Специальные', percentage: 5 }
    ],
    topBonuses: [
      {
        title: 'Приветственный бонус',
        description: 'До 100% от первого депозита',
        code: 'WELCOME100',
        maxBonus: '₽10,000'
      },
      {
        title: 'Экспресс-бонус',
        description: 'Страховка экспресса до 50%',
        code: 'EXPRESS50',
        maxBonus: '₽5,000'
      }
    ]
  },

  live: {
    activeMatches: 342,
    totalLiveBets: '₽8,765,432',
    topLiveEvents: [
      {
        sport: 'Футбол',
        match: 'Зенит - ЦСКА',
        currentScore: '1:1',
        time: '65\'',
        odds: { home: 1.8, draw: 3.5, away: 4.2 }
      },
      {
        sport: 'Теннис',
        match: 'Надаль - Джокович',
        currentScore: '2:1',
        time: '3-й сет',
        odds: { player1: 1.6, player2: 2.4 }
      }
    ]
  },

  support: {
    quickContacts: [
      {
        method: 'Чат',
        icon: '💬',
        availability: '24/7',
        responseTime: 'До 5 минут'
      },
      {
        method: 'Телефон',
        icon: '📞',
        number: '+7 (727) 000-00-00',
        availability: '09:00 - 23:00'
      }
    ],
    faqCategories: [
      {
        title: 'Регистрация',
        questions: [
          {
            question: 'Как зарегистрироваться?',
            answer: 'Нажмите "Регистрация", заполните форму, подтвердите почту.'
          },
          {
            question: 'Какие документы нужны?',
            answer: 'Паспорт, подтверждение адреса, банковская карта.'
          }
        ]
      },
      {
        title: 'Платежи',
        questions: [
          {
            question: 'Как пополнить счет?',
            answer: 'Карта, электронный кошелек, банковский перевод.'
          },
          {
            question: 'Минимальная сумма пополнения?',
            answer: 'От 100 рублей.'
          }
        ]
      }
    ]
  }
};

export const mockBonusesData = {
  activePromotions: [
    {
      title: 'Приветственный бонус',
      description: 'Получи до 100% от первого депозита',
      category: 'Новым игрокам',
      maxBonus: '₽10,000',
      validUntil: '2024-12-31'
    },
    {
      title: 'Кэшбек выходного дня',
      description: 'Возврат до 10% от проигрыша',
      category: 'Постоянным игрокам',
      maxBonus: '₽5,000',
      validUntil: '2024-06-30'
    },
    {
      title: 'Экспресс-страховка',
      description: 'Страховка экспресса до 50%',
      category: 'Специальные',
      maxBonus: '₽3,000',
      validUntil: '2024-09-15'
    }
  ],
  vipProgram: {
    levels: [
      { name: 'Бронза', minDeposit: '₽0', cashbackPercent: 5 },
      { name: 'Серебро', minDeposit: '₽50,000', cashbackPercent: 10 },
      { name: 'Золото', minDeposit: '₽250,000', cashbackPercent: 15 },
      { name: 'Платина', minDeposit: '₽1,000,000', cashbackPercent: 20 }
    ]
  }
};

export const mockResultsData = {
  recentResults: [
    {
      sport: 'Футбол',
      match: 'Зенит - Спартак',
      score: '2:1',
      date: '2024-02-10',
      league: 'Премьер-лига'
    },
    {
      sport: 'Баскетбол',
      match: 'ЦСКА - Химки',
      score: '89:85',
      date: '2024-02-11',
      league: 'ВТБ Единая лига'
    }
  ],
  topResults: [
    {
      sport: 'Теннис',
      tournament: 'Australian Open',
      winner: 'Джокович',
      score: '6:3, 7:6, 6:3',
      date: '2024-01-28'
    },
    {
      sport: 'Хоккей',
      tournament: 'КХЛ',
      match: 'Авангард - Металлург',
      score: '4:2',
      date: '2024-02-12'
    }
  ]
};

export const mockResponsibleGamingData = {
  warningSigns: [
    {
      title: 'Признаки зависимости',
      signs: [
        'Постоянные мысли о ставках',
        'Увеличение сумм ставок',
        'Заем денег для ставок',
        'Пропуск работы/учебы из-за ставок'
      ]
    }
  ],
  helpResources: [
    {
      name: 'Горячая линия поддержки',
      phone: '8-800-555-35-35',
      description: 'Бесплатная психологическая помощь'
    },
    {
      name: 'Центр реабилитации',
      contact: 'help@gambling-support.ru',
      description: 'Программы по преодолению зависимости'
    }
  ]
};

export const mockTermsData = {
  sections: [
    {
      title: 'Общие условия',
      content: 'Использование платформы регулируется настоящими правилами. Продолжая использование, вы соглашаетесь с условиями.'
    },
    {
      title: 'Ответственность',
      content: 'Пользователь несет полную ответственность за свои действия на платформе. Компания не несет ответственности за финансовые потери.'
    }
  ]
};

export default {
  sports: mockSportsData,
  bonuses: mockBonusesData,
  results: mockResultsData,
  responsibleGaming: mockResponsibleGamingData,
  terms: mockTermsData
}; 