import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { 
  getUserNotifications, 
  addNotification as addNotificationToSupabase, 
  markNotificationAsRead, 
  markAllNotificationsAsRead, 
  removeNotification as removeNotificationFromSupabase 
} from '../database/notification-adapter';
import { supabase } from '../config/supabase';

interface Notification {
  id: string;
  message: string;
  read: boolean;
  timestamp: number;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  addNotification: (message: string) => void;
  removeNotification: (id: string) => void;
}

interface NotificationProviderProps {
  children: ReactNode;
}

// Create the context with a default value
const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

// Custom hook to use the notification context
export const useNotifications = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

// Provider component
export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);

  // Load notifications from Supabase on mount and when user changes
  useEffect(() => {
    const fetchNotifications = async () => {
      if (currentUser) {
        try {
          // If Supabase is configured, fetch from there
          if (supabase) {
            const notifs = await getUserNotifications(currentUser.phone);
            setNotifications(notifs);
            updateUnreadCount(notifs);
            
            // If no notifications found, add demo notifications
            if (notifs.length === 0) {
              // Add some demo notifications for testing
              const demoNotifications = [
                {
                  id: 'NOTIF-100001',
                  message: 'Welcome to Olimpbet! Enjoy your betting experience.',
                  read: false,
                  timestamp: Date.now() - 3600000 // 1 hour ago
                },
                {
                  id: 'NOTIF-100002',
                  message: 'Доступен новый бонус! Пополните счёт сейчас, чтобы получить 100% бонус.',
                  read: false,
                  timestamp: Date.now() - 7200000 // 2 hours ago
                },
                {
                  id: 'NOTIF-100003',
                  message: 'Your bet on Manchester United vs Liverpool has been settled.',
                  read: true,
                  timestamp: Date.now() - 86400000 // 1 day ago
                }
              ];
              
              // Add demo notifications to Supabase
              for (const notification of demoNotifications) {
                await addNotificationToSupabase(currentUser.phone, notification.message);
              }
              
              // Fetch again to get the newly added notifications
              const updatedNotifs = await getUserNotifications(currentUser.phone);
              setNotifications(updatedNotifs);
              updateUnreadCount(updatedNotifs);
            }
          } else {
            throw new Error('Supabase client not configured');
          }
        } catch (error) {
          console.error('Error loading notifications:', error);
          setNotifications([]);
          setUnreadCount(0);
        }
      } else {
        setNotifications([]);
        setUnreadCount(0);
      }
    };
    
    fetchNotifications();
  }, [currentUser]);

  // Update unread count
  const updateUnreadCount = (notifs: Notification[]) => {
    const count = notifs.filter(n => !n.read).length;
    setUnreadCount(count);
  };



  // Mark notification as read
  const markAsRead = async (id: string) => {
    try {
      if (!supabase || !currentUser) {
        throw new Error('Supabase client not configured or user not authenticated');
      }
      
      await markNotificationAsRead(id);
      
      // Update local state after successful Supabase update
      const updatedNotifications = notifications.map(notification => {
        if (notification.id === id) {
          return { ...notification, read: true };
        }
        return notification;
      });
      setNotifications(updatedNotifications);
      updateUnreadCount(updatedNotifications);
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  // Mark all notifications as read
  const markAllAsRead = async () => {
    try {
      if (!supabase || !currentUser) {
        throw new Error('Supabase client not configured or user not authenticated');
      }
      
      const success = await markAllNotificationsAsRead(currentUser.phone);
      if (success) {
        const updatedNotifications = notifications.map(notification => ({
          ...notification,
          read: true
        }));
        setNotifications(updatedNotifications);
        setUnreadCount(0);
      }
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
    }
  };

  // Add a new notification
  const addNotification = async (message: string) => {
    try {
      if (!supabase || !currentUser) {
        throw new Error('Supabase client not configured or user not authenticated');
      }
      
      const newNotification = await addNotificationToSupabase(currentUser.phone, message);
      if (newNotification) {
        const updatedNotifications = [newNotification, ...notifications];
        setNotifications(updatedNotifications);
        setUnreadCount(unreadCount + 1);
      }
    } catch (error) {
      console.error('Error adding notification:', error);
    }
  };

  // Remove a notification
  const removeNotification = async (id: string) => {
    try {
      if (!supabase) {
        throw new Error('Supabase client not configured');
      }
      
      const notification = notifications.find(n => n.id === id);
      const success = await removeNotificationFromSupabase(id);
      if (success) {
        const updatedNotifications = notifications.filter(n => n.id !== id);
        setNotifications(updatedNotifications);
        if (notification && !notification.read) {
          setUnreadCount(unreadCount - 1);
        }
      }
    } catch (error) {
      console.error('Error removing notification:', error);
    }
  };

  const value = {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    addNotification,
    removeNotification
  };

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
};