import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { 
  getUserBalance, 
  updateUserBalance, 
  getUserCurrency 
  // updateUserCurrency is imported but not used
} from '../database/balance-adapter';
import { supabase } from '../config/supabase';

interface BalanceContextType {
  balance: number;
  currency: string;
  updateBalance: (newBalance: number) => Promise<void>;
  addFunds: (amount: number) => Promise<void>;
  withdrawFunds: (amount: number) => Promise<boolean>;
  formatBalance: (amount: number) => string;
  refreshBalance: () => Promise<void>;
}

interface BalanceProviderProps {
  children: ReactNode;
}

// Create the context with a default value
const BalanceContext = createContext<BalanceContextType | undefined>(undefined);

// Custom hook to use the balance context
export const useBalance = (): BalanceContextType => {
  const context = useContext(BalanceContext);
  if (context === undefined) {
    throw new Error('useBalance must be used within a BalanceProvider');
  }
  return context;
};

// Provider component
export const BalanceProvider: React.FC<BalanceProviderProps> = ({ children }) => {
  const { currentUser } = useAuth();
  const [balance, setBalance] = useState<number>(0);
  const [currency, setCurrency] = useState<string>('KZT');

  // Function to fetch balance and currency from Supabase
  const fetchBalanceAndCurrency = useCallback(async () => {
    console.log('fetchBalanceAndCurrency called');
    if (currentUser) {
      console.log('Fetching balance for user:', currentUser.phone);
      try {
        if (!supabase) {
          console.log('Supabase client not configured');
          throw new Error('Supabase client not configured');
        }
        
        // Get balance from Supabase
        const userBalance = await getUserBalance(currentUser.phone);
        console.log('User balance from Supabase:', userBalance);
        
        if (userBalance !== null) {
          // If we got a balance from Supabase, use it
          console.log('Setting balance from Supabase:', userBalance);
          setBalance(userBalance);
        } else {
          // If no balance in Supabase, set a demo balance
          const demoBalance = 0;
          console.log('No balance in Supabase, setting demo balance:', demoBalance);
          setBalance(demoBalance);
          
          // Save the demo balance to Supabase
          console.log('Saving demo balance to Supabase');
          await updateUserBalance(currentUser.phone, demoBalance);
        }
        
        // Get currency from Supabase
        const userCurrency = await getUserCurrency(currentUser.phone);
        if (userCurrency) {
          setCurrency(userCurrency);
        }
      } catch (error) {
          console.error('Error fetching from Supabase:', error);
          // Set default values if Supabase fails
          setBalance(0);
          setCurrency('USD');
      }
    } else {
      setBalance(0);
    }
  }, [currentUser]);

  // Refresh balance function that can be called externally
  const refreshBalance = async () => {
    console.log('refreshBalance called');
    console.log('Current user:', currentUser);
    await fetchBalanceAndCurrency();
    console.log('Balance after refresh:', balance);
  };

  // Load balance from Supabase on mount and when user changes
  useEffect(() => {
    fetchBalanceAndCurrency();
    
    // Set up polling to refresh balance every 30 seconds
    const pollingInterval = setInterval(() => {
      fetchBalanceAndCurrency();
    }, 30000); // 30 seconds
    
    // Clean up interval on unmount
    return () => clearInterval(pollingInterval);
  }, [fetchBalanceAndCurrency]);

  // Save balance to Supabase
  const saveBalance = async (newBalance: number) => {
    if (currentUser) {
      try {
        if (!supabase) {
          throw new Error('Supabase client not configured');
        }
        
        await updateUserBalance(currentUser.phone, newBalance);
      } catch (error) {
        console.error('Error saving balance to Supabase:', error);
        throw error;
      }
    }
  };

  // Update balance
  const updateBalance = async (newBalance: number) => {
    // Update local state first for immediate UI feedback
    setBalance(newBalance);
    await saveBalance(newBalance);
  };

  // Add funds to balance
  const addFunds = async (amount: number) => {
    try {
      const newBalance = balance + amount;
      setBalance(newBalance);
      await saveBalance(newBalance);
    } catch (error) {
      console.error('Error adding funds:', error);
      // Still update the local state for better UX even if there was an error with Supabase
      const newBalance = balance + amount;
      setBalance(newBalance);
      localStorage.setItem(`balance_${currentUser?.phone}`, newBalance.toString());
    }
  };

  // Withdraw funds from balance
  const withdrawFunds = async (amount: number): Promise<boolean> => {
    if (amount <= 0) {
      return false;
    }

    if (amount > balance) {
      return false;
    }

    try {
      const newBalance = balance - amount;
      setBalance(newBalance);
      await saveBalance(newBalance);
      return true;
    } catch (error) {
      console.error('Error withdrawing funds:', error);
      // Still update the local state for better UX even if there was an error with Supabase
      const newBalance = balance - amount;
      setBalance(newBalance);
      localStorage.setItem(`balance_${currentUser?.phone}`, newBalance.toString());
      return true;
    }
  };

  // Format balance with currency
  const formatBalance = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const value = {
    balance,
    currency,
    updateBalance,
    addFunds,
    withdrawFunds,
    formatBalance,
    refreshBalance
  };

  return <BalanceContext.Provider value={value}>{children}</BalanceContext.Provider>;
};