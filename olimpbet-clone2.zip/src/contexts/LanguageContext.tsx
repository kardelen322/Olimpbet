import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { translations, TranslationKey, LanguageCode } from '../translations';

interface LanguageContextType {
  currentLanguage: LanguageCode;
  translate: (key: string) => string;
  setLanguage: (language: LanguageCode) => void;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  // Always use Russian language
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>('ru');
  
  // Set localStorage to Russian
  useEffect(() => {
    localStorage.setItem('selectedLanguage', 'ru');
  }, []);
  
  // No longer need to check if we're on admin page since we always use Russian

  const translate = (key: string): string => {
    const currentTranslations = translations[currentLanguage];
    const fallbackTranslations = translations.ru;
    
    if (currentTranslations && key in currentTranslations) {
      return currentTranslations[key as keyof typeof currentTranslations];
    }
    
    if (fallbackTranslations && key in fallbackTranslations) {
      return fallbackTranslations[key as TranslationKey];
    }
    
    return key;
  };

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const setLanguage = (_: LanguageCode) => {
    // Always set language to Russian regardless of page
    setCurrentLanguage('ru');
    localStorage.setItem('selectedLanguage', 'ru');
  };

  const isRTL = false; // None of our supported languages are RTL

  // Set document direction
  useEffect(() => {
    document.dir = 'ltr';
  }, [currentLanguage]);
  
  // Effect to force Russian language on all pages
  useEffect(() => {
    if (currentLanguage !== 'ru') {
      setCurrentLanguage('ru');
      localStorage.setItem('selectedLanguage', 'ru');
    }
  }, [currentLanguage]);
  
  // Add listener for URL changes to enforce Russian language
  useEffect(() => {
    const handleUrlChange = () => {
      // Always force Russian language regardless of page
      if (currentLanguage !== 'ru') {
        setCurrentLanguage('ru');
        localStorage.setItem('selectedLanguage', 'ru');
      }
    };
    
    // Initial check
    handleUrlChange();
    
    // Listen for popstate events (browser back/forward)
    window.addEventListener('popstate', handleUrlChange);
    
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
    };
  }, [currentLanguage]);

  const value: LanguageContextType = {
    currentLanguage,
    translate,
    setLanguage,
    isRTL,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};