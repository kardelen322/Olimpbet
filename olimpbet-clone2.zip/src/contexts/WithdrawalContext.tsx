import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { WithdrawalRequest, WithdrawalContextType } from '../types/withdrawal';
import * as paymentAdapter from '../database/payment-adapter';
import { useAuth } from './AuthContext';
import { useNotifications } from './NotificationContext';

const WithdrawalContext = createContext<WithdrawalContextType | undefined>(undefined);

export const WithdrawalProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const { currentUser } = useAuth();
  const { addNotification } = useNotifications();

  const fetchWithdrawalRequests = async () => {
    try {
      const requests = await paymentAdapter.getWithdrawalRequests();
      
      // Ensure all dates are properly formatted
      const formattedRequests = requests.map(request => ({
        ...request,
        date: paymentAdapter.fixDateFormat(request.date),
        created_at: request.created_at ? paymentAdapter.fixDateFormat(request.created_at) : undefined,
        updated_at: request.updated_at ? paymentAdapter.fixDateFormat(request.updated_at) : undefined
      }));
      
      setWithdrawalRequests(formattedRequests);
    } catch (error) {
      console.error('Error fetching withdrawal requests:', error);
    }
  };

  const addWithdrawalRequest = async (request: Omit<WithdrawalRequest, 'id' | 'date' | 'status'>) => {
    try {
      const newRequest: WithdrawalRequest = {
        ...request,
        id: `WD-${Date.now()}`,
        date: new Date().toISOString(),
        status: 'pending'
      };

      // Add to Supabase if configured
      try {
        await paymentAdapter.addWithdrawalRequest(currentUser?.phone || '', request.amount, request.paymentMethod, `${request.paymentMethod} withdrawal`);
        console.log('Withdrawal request saved to Supabase');
      } catch (supabaseError) {
        console.log('Supabase not configured, using local state only');
      }

      // Update local state
      setWithdrawalRequests(prev => [newRequest, ...prev]);

      // Send notification to user
      if (currentUser) {
        try {
          await addNotification(`Your withdrawal request for ${request.amount.toLocaleString()} has been submitted and is pending.`);
        } catch (notificationError) {
          console.error('Error sending notification:', notificationError);
        }
      }

    } catch (error) {
      console.error('Error adding withdrawal request:', error);
      throw error;
    }
  };

  const approveWithdrawalRequest = async (id: string) => {
    try {
      // Update local state
      setWithdrawalRequests(prev => 
        prev.map(request => 
          request.id === id 
            ? { ...request, status: 'approved' as const }
            : request
        )
      );

      // Find the request to get user info
      const request = withdrawalRequests.find(r => r.id === id);
      if (request && currentUser) {
        // Send notification to user
        try {
          await addNotification(`Your withdrawal request for ${request.amount.toLocaleString()} has been approved and will be processed shortly.`);
        } catch (notificationError) {
          console.error('Error sending notification:', notificationError);
        }
      }

      // Update in Supabase if configured
      try {
        await paymentAdapter.approveWithdrawalRequest(id);
        console.log('Withdrawal request approved in Supabase');
      } catch (supabaseError) {
        console.log('Supabase not configured, using local state only');
      }

    } catch (error) {
      console.error('Error approving withdrawal request:', error);
      throw error;
    }
  };

  const rejectWithdrawalRequest = async (id: string, reason: string) => {
    try {
      // Update local state
      setWithdrawalRequests(prev => 
        prev.map(request => 
          request.id === id 
            ? { ...request, status: 'rejected' as const, rejectionReason: reason }
            : request
        )
      );

      // Find the request to get user info
      const request = withdrawalRequests.find(r => r.id === id);
      if (request && currentUser) {
        // Send notification to user
        try {
          await addNotification(`Your withdrawal request for ${request.amount.toLocaleString()} has been rejected. Reason: ${reason}`);
        } catch (notificationError) {
          console.error('Error sending notification:', notificationError);
        }
      }

      // Update in Supabase if configured
      try {
        await paymentAdapter.rejectWithdrawalRequest(id, reason);
        console.log('Withdrawal request rejected in Supabase');
      } catch (supabaseError) {
        console.log('Supabase not configured, using local state only');
      }

    } catch (error) {
      console.error('Error rejecting withdrawal request:', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchWithdrawalRequests();
  }, []);

  const value: WithdrawalContextType = {
    withdrawalRequests,
    addWithdrawalRequest,
    approveWithdrawalRequest,
    rejectWithdrawalRequest,
    fetchWithdrawalRequests
  };

  return (
    <WithdrawalContext.Provider value={value}>
      {children}
    </WithdrawalContext.Provider>
  );
};

export const useWithdrawal = (): WithdrawalContextType => {
  const context = useContext(WithdrawalContext);
  if (!context) {
    throw new Error('useWithdrawal must be used within a WithdrawalProvider');
  }
  return context;
};