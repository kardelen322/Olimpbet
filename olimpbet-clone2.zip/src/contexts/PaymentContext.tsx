import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { useNotifications } from './NotificationContext';
import { useBalance } from './BalanceContext';
import * as paymentAdapter from '../database/payment-adapter';
import * as balanceAdapter from '../database/balance-adapter';
import { isSupabaseConfigured } from '../config/supabase';

export interface DepositRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  paymentMethod: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
}

interface PaymentContextType {
  paymentLink: string;
  updatePaymentLink: (newLink: string) => Promise<void>;
  depositRequests: DepositRequest[];
  addDepositRequest: (request: Omit<DepositRequest, 'id' | 'date' | 'status'>) => Promise<DepositRequest>;
  approveDepositRequest: (id: string) => Promise<void>;
  rejectDepositRequest: (id: string, reason: string) => Promise<void>;
}

interface PaymentProviderProps {
  children: ReactNode;
}

// Create the context with a default value
const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

// Custom hook to use the payment context
export const usePayment = (): PaymentContextType => {
  const context = useContext(PaymentContext);
  if (context === undefined) {
    throw new Error('usePayment must be used within a PaymentProvider');
  }
  return context;
};

// Provider component
export const PaymentProvider: React.FC<PaymentProviderProps> = ({ children }) => {
  // Initialize with the default Kaspi payment link
  const [paymentLink, setPaymentLink] = useState<string>('https://kaspi.kz/pay/OLIMPBET?7695=92070570');
  const [depositRequests, setDepositRequests] = useState<DepositRequest[]>([]);
  const { addNotification } = useNotifications();
  // We need currentUser for direct notifications in Supabase
  const { currentUser } = useAuth();
  const { refreshBalance } = useBalance();

  // Log current user for debugging
  useEffect(() => {
    if (currentUser) {
      console.log('PaymentContext initialized for user:', currentUser.phone);
    }
    
    // Load payment link and deposit requests on mount
    const fetchData = async () => {
      try {
        // Always check localStorage first for existing data
        const storedPaymentLink = localStorage.getItem('paymentLink');
        if (storedPaymentLink) {
          setPaymentLink(storedPaymentLink);
        }
        
        const storedDepositRequests = localStorage.getItem('depositRequests');
        let localRequests: DepositRequest[] = [];
        
        if (storedDepositRequests) {
          try {
            const parsedRequests = JSON.parse(storedDepositRequests);
            // Ensure each request has a valid status type
            localRequests = parsedRequests.map((req: any) => ({
              ...req,
              status: req.status === 'pending' ? 'pending' : 
                     req.status === 'approved' ? 'approved' : 
                     req.status === 'rejected' ? 'rejected' : 'pending'
            }));
            setDepositRequests(localRequests);
          } catch (error) {
            console.error('Error parsing deposit requests:', error);
          }
        }
        
        // Try to fetch from Supabase if configured
        if (isSupabaseConfigured()) {
          try {
            // Fetch payment link from Supabase
            const link = await paymentAdapter.getPaymentLink();
            if (link) {
              setPaymentLink(link);
              localStorage.setItem('paymentLink', link);
            }
          } catch (linkError) {
            console.error('Failed to get payment link from Supabase (continuing with localStorage):', linkError);
          }
          
          try {
            // Fetch deposit requests from Supabase
            const requests = await paymentAdapter.getDepositRequests();
            if (requests && requests.length > 0) {
              setDepositRequests(requests);
              localStorage.setItem('depositRequests', JSON.stringify(requests));
            }
          } catch (requestsError) {
            console.error('Failed to get deposit requests from Supabase (continuing with localStorage):', requestsError);
            // We already loaded from localStorage if available, so we can continue
          }
        }
      } catch (error) {
        console.error('Error fetching payment data:', error);
      }
    };
    
    fetchData();
  }, [currentUser]); // Add currentUser as a dependency

  // Update payment link
  const updatePaymentLink = async (newLink: string) => {
    // Always update local state first for immediate UI feedback
    setPaymentLink(newLink);
    
    // Always update localStorage
    localStorage.setItem('paymentLink', newLink);
    
    try {
      // Try to update in Supabase if configured
      if (isSupabaseConfigured()) {
        try {
          await paymentAdapter.updatePaymentLink(newLink);
        } catch (supabaseError) {
          console.error('Failed to update payment link in Supabase (continuing with localStorage):', supabaseError);
          // We already updated localStorage and state, so we can continue
        }
      }
    } catch (error) {
      console.error('Error updating payment link:', error);
      // We already updated the UI and localStorage, so the user experience is not affected
    }
  };

  // Add a new deposit request
  const addDepositRequest = async (request: Omit<DepositRequest, 'id' | 'date' | 'status'>): Promise<DepositRequest> => {
    try {
      if (isSupabaseConfigured()) {
        // Add to Supabase
        const newRequest = await paymentAdapter.addDepositRequest(request);
        if (newRequest) {
          setDepositRequests(prev => [...prev, newRequest]);
          return newRequest;
        }
      }
      
      // Fallback to localStorage or if Supabase request failed
      const status: 'pending' | 'approved' | 'rejected' = 'pending';
      
      const newRequest: DepositRequest = {
        ...request,
        id: `DEP-${Date.now().toString().slice(-6)}`,
        date: new Date().toISOString(),
        status
      };
      
      const updatedRequests = [...depositRequests, newRequest];
      setDepositRequests(updatedRequests);
      
      if (!isSupabaseConfigured()) {
        localStorage.setItem('depositRequests', JSON.stringify(updatedRequests));
      }
      
      return newRequest;
    } catch (error) {
      console.error('Error adding deposit request:', error);
      
      // Fallback implementation if everything fails
      const fallbackRequest: DepositRequest = {
        ...request,
        id: `DEP-${Date.now().toString().slice(-6)}`,
        date: new Date().toISOString(),
        status: 'pending'
      };
      
      setDepositRequests(prev => [...prev, fallbackRequest]);
      return fallbackRequest;
    }
  };

  // Approve a deposit request
  const approveDepositRequest = async (id: string) => {
    try {
      console.log('Approving deposit request with ID:', id);
      
      // Find the deposit request to get details for notification
      const depositRequest = depositRequests.find(req => req.id === id);
      console.log('Found deposit request:', depositRequest);
      
      // Always update local state first for better UX
      const updatedRequests = depositRequests.map(req => {
        if (req.id === id) {
          return { ...req, status: 'approved' as const };
        }
        return req;
      });
      setDepositRequests(updatedRequests);
      localStorage.setItem('depositRequests', JSON.stringify(updatedRequests));
      
      // Send notification to the user who made the deposit request
      if (depositRequest) {
        try {
          // Get the user ID from the deposit request
          const userId = depositRequest.userId;
          
          // Add notification directly to Supabase for the user who made the request
          if (isSupabaseConfigured()) {
            const { addNotification: addNotificationToSupabase } = require('../database/notification-adapter');
            await addNotificationToSupabase(userId, `Your deposit request of ${depositRequest.amount} ${depositRequest.paymentMethod} has been approved.`);
            console.log(`Notification sent to user ${userId} for approved deposit`);
          } else {
            // If Supabase is not configured, we'll add to localStorage when that user logs in
            // This is handled by the NotificationContext's addNotification function
            addNotification(`Your deposit request of ${depositRequest.amount} ${depositRequest.paymentMethod} has been approved.`);
          }
        } catch (notificationError) {
          console.error('Error sending notification for approved deposit:', notificationError);
          // Continue with the process even if notification fails
        }
      }
      
      // Add the deposited amount to user's balance
      if (depositRequest && isSupabaseConfigured()) {
        try {
          console.log('Supabase is configured, adding balance to user');
          console.log('Current user:', currentUser);
          console.log('Deposit request user phone:', depositRequest.userId);
          
          const success = await balanceAdapter.addBalanceToUser(
            depositRequest.userId, 
            depositRequest.amount, 
            `Deposit approved: ${depositRequest.paymentMethod}`
          );
          if (success) {
            console.log(`Added ${depositRequest.amount} to user ${depositRequest.userId} balance`);
            
            // Refresh the balance if this is the current user
            if (currentUser && currentUser.phone === depositRequest.userId) {
              console.log('Current user matches deposit user, refreshing balance');
              await refreshBalance();
              console.log('Balance refreshed for current user');
            } else {
              console.log('Current user does not match deposit user, not refreshing balance');
              console.log('Current user phone:', currentUser?.phone);
              console.log('Deposit user phone:', depositRequest.userId);
            }
          } else {
            console.error('Failed to add balance to user');
          }
        } catch (balanceError) {
          console.error('Error adding balance to user:', balanceError);
        }
      }
      
      // Try to update in Supabase if configured
      if (isSupabaseConfigured()) {
        try {
          await paymentAdapter.approveDepositRequest(id);
          console.log('Deposit request approved in Supabase');
        } catch (supabaseError) {
          console.error('Failed to approve deposit request in Supabase (continuing with localStorage):', supabaseError);
          // We already updated localStorage, so we can continue
        }
      }
    } catch (error) {
      console.error('Error approving deposit request:', error);
    }
  };

  // Reject a deposit request with a reason
  const rejectDepositRequest = async (id: string, reason: string) => {
    try {
      // Find the deposit request to get details for notification
      const depositRequest = depositRequests.find(req => req.id === id);
      
      // Always update local state first for better UX
      const updatedRequests = depositRequests.map(req => {
        if (req.id === id) {
          return { ...req, status: 'rejected' as const, rejectionReason: reason };
        }
        return req;
      });
      setDepositRequests(updatedRequests);
      localStorage.setItem('depositRequests', JSON.stringify(updatedRequests));
      
      // Send notification to the user who made the deposit request
      if (depositRequest) {
        try {
          // Get the user ID from the deposit request
          const userId = depositRequest.userId;
          
          // Add notification directly to Supabase for the user who made the request
          if (isSupabaseConfigured()) {
            const { addNotification: addNotificationToSupabase } = require('../database/notification-adapter');
            await addNotificationToSupabase(userId, `Your deposit request of ${depositRequest.amount} ${depositRequest.paymentMethod} has been rejected: ${reason}`);
            console.log(`Notification sent to user ${userId} for rejected deposit`);
          } else {
            // If Supabase is not configured, we'll add to localStorage when that user logs in
            // This is handled by the NotificationContext's addNotification function
            addNotification(`Your deposit request of ${depositRequest.amount} ${depositRequest.paymentMethod} has been rejected: ${reason}`);
          }
        } catch (notificationError) {
          console.error('Error sending notification for rejected deposit:', notificationError);
          // Continue with the process even if notification fails
        }
      }
      
      // Try to update in Supabase if configured
      if (isSupabaseConfigured()) {
        try {
          await paymentAdapter.rejectDepositRequest(id, reason);
          console.log('Deposit request rejected in Supabase');
        } catch (supabaseError) {
          console.error('Failed to reject deposit request in Supabase (continuing with localStorage):', supabaseError);
          // We already updated localStorage, so we can continue
        }
      }
    } catch (error) {
      console.error('Error rejecting deposit request:', error);
    }
  };

  const value = {
    paymentLink,
    updatePaymentLink,
    depositRequests,
    addDepositRequest,
    approveDepositRequest,
    rejectDepositRequest
  };

  return <PaymentContext.Provider value={value}>{children}</PaymentContext.Provider>;
};