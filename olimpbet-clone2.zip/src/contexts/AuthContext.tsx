import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { findUserByPhone, createUser, verifyPassword, recordFailedLoginAttempt, isAccountLocked, isUserBlacklisted } from '../database';
import { initializeDatabase } from '../database';

interface User {
  phone: string;
  username?: string;
}

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (phone: string, password: string) => Promise<boolean>;
  register: (userData: RegisterData, password: string) => Promise<boolean>;
  logout: () => void;
  error: string | null;
  loading: boolean;
}

interface RegisterData {
  phone: string;
  password: string;
  username?: string;
}

interface AuthProviderProps {
  children: ReactNode;
}

// Create the context with a default value
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Custom hook to use the auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Provider component
export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  // Initialize database and restore user session on mount
  useEffect(() => {
    const init = async () => {
      // Initialize the database
      await initializeDatabase();
      
      // Restore user session from localStorage
      const savedUser = localStorage.getItem('olimpbet_user');
      const savedAuth = localStorage.getItem('olimpbet_authenticated');
      
      if (savedUser && savedAuth === 'true') {
        try {
          const user = JSON.parse(savedUser);
          setCurrentUser(user);
          setIsAuthenticated(true);
        } catch (error) {
          console.error('Error parsing saved user data:', error);
          // Clear corrupted data
          localStorage.removeItem('olimpbet_user');
          localStorage.removeItem('olimpbet_authenticated');
        }
      }
    };
    
    init();
  }, []);

  // Login function
  const login = async (phone: string, password: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    
    try {
      // Check if user is blacklisted
      const blacklisted = await isUserBlacklisted(phone);
      if (blacklisted) {
        setError('You have been blocked from accessing this platform. If you believe this is an error, please contact support.');
        setLoading(false);
        return false;
      }

      // Check if account is locked due to too many failed attempts
      const locked = await isAccountLocked(phone);
      if (locked) {
        setError('Account is temporarily locked due to too many failed login attempts. Please try again later.');
        setLoading(false);
        return false;
      }

      // Find user in database
      const user = await findUserByPhone(phone);
      
      if (!user) {
        // Record failed login attempt
        await recordFailedLoginAttempt(phone);
        setError('User not found');
        setLoading(false);
        return false;
      }

      // Check if user is blacklisted by username as well
      if (user.username) {
        const blacklistedByUsername = await isUserBlacklisted(phone, user.username);
        if (blacklistedByUsername) {
          setError('You have been blocked from accessing this platform. If you believe this is an error, please contact support.');
          setLoading(false);
          return false;
        }
      }

      // Check password
      const isPasswordValid = await verifyPassword(user.password, password);
      if (!isPasswordValid) {
        // Record failed login attempt
        await recordFailedLoginAttempt(phone);
        setError('Invalid password');
        setLoading(false);
        return false;
      }

      // Login successful
      const { password: _, ...userWithoutPassword } = user;
      setCurrentUser(userWithoutPassword);
      setIsAuthenticated(true);
      
      // Save user session to localStorage
      localStorage.setItem('olimpbet_user', JSON.stringify(userWithoutPassword));
      localStorage.setItem('olimpbet_authenticated', 'true');
      
      setLoading(false);
      return true;
    } catch (err) {
      setError('An error occurred during login');
      setLoading(false);
      return false;
    }
  };

  // Register function
  const register = async (userData: RegisterData, password: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    
    try {
      // Validate input
      if (!userData.phone || !password) {
        setError('Phone number and password are required');
        setLoading(false);
        return false;
      }

      // Check if phone number already exists
      const existingUser = await findUserByPhone(userData.phone);
      if (existingUser) {
        setError('Phone number already exists');
        setLoading(false);
        return false;
      }

      try {
        // Create user in database (this will validate password policy)
        await createUser(userData.phone, password, userData.username);
      } catch (error) {
        if (error instanceof Error) {
          setError(error.message);
        } else {
          setError('Failed to create user');
        }
        setLoading(false);
        return false;
      }

      // Get user without password for session
      const { password: _, ...userWithoutPassword } = userData;
      
      // Auto login after registration
      setCurrentUser(userWithoutPassword);
      setIsAuthenticated(true);
      
      // Save user session to localStorage
      localStorage.setItem('olimpbet_user', JSON.stringify(userWithoutPassword));
      localStorage.setItem('olimpbet_authenticated', 'true');

      setLoading(false);
      return true;
    } catch (err) {
      setError('An error occurred during registration');
      setLoading(false);
      return false;
    }
  };

  // Logout function
  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    
    // Clear user session from localStorage
    localStorage.removeItem('olimpbet_user');
    localStorage.removeItem('olimpbet_authenticated');
  };

  const value = {
    currentUser,
    isAuthenticated,
    login,
    register,
    logout,
    error,
    loading
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};