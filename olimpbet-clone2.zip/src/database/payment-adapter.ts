import { supabase } from '../config/supabase';
import { DepositRequest } from '../contexts/PaymentContext';

// Get payment link from Supabase
export const getPaymentLink = async (): Promise<string> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { data, error } = await supabase
      .from('payment_links')
      .select('link')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    
    if (error) {
      console.error('Failed to get payment link:', error);
      return 'https://kaspi.kz/pay/OLIMPBET?7695=92070570'; // Default link as fallback
    }
    
    return data?.link || 'https://kaspi.kz/pay/OLIMPBET?7695=92070570';
  } catch (error) {
    console.error('Error fetching payment link:', error);
    return 'https://kaspi.kz/pay/OLIMPBET?7695=92070570'; // Default link as fallback
  }
};

// Update payment link in Supabase
export const updatePaymentLink = async (newLink: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    // First check if any payment link exists
    const { data: existingLinks } = await supabase
      .from('payment_links')
      .select('id')
      .limit(1);
    
    if (existingLinks && existingLinks.length > 0) {
      // Update the existing link
      const { error } = await supabase
        .from('payment_links')
        .update({ link: newLink, updated_at: new Date().toISOString() })
        .eq('id', existingLinks[0].id);
      
      if (error) {
        console.error('Failed to update payment link:', error);
        return false;
      }
    } else {
      // Insert a new link if none exists
      const { error } = await supabase
        .from('payment_links')
        .insert({ link: newLink });
      
      if (error) {
        console.error('Failed to insert payment link:', error);
        return false;
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error updating payment link:', error);
    return false;
  }
};

// Get all withdrawal requests
export const getWithdrawalRequests = async (): Promise<any[]> => {
  if (!supabase) {
    return [];
  }

  try {
    const { data, error } = await supabase
      .from('withdrawal_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching withdrawal requests:', error);
      return [];
    }
    
    // Transform the data to match the WithdrawalRequest interface
    const withdrawalRequests = (data || []).map((item: any) => ({
      id: item.id,
      username: item.username || 'Unknown User',
      user_id: item.user_id || '',
      amount: item.amount,
      paymentMethod: item.method || 'Unknown Method',
      accountNumber: item.details || '',
      date: item.created_at,
      status: item.status,
      rejectionReason: item.rejection_reason,
      created_at: item.created_at,
      updated_at: item.updated_at
    }));

    return withdrawalRequests;
  } catch (error) {
    console.error('Error fetching withdrawal requests:', error);
    return [];
  }
};

// Add withdrawal request
export const addWithdrawalRequest = async (userId: string, amount: number, method: string, details: string): Promise<boolean> => {
  if (!supabase) {
    return false;
  }

  try {
    // First get the username from the users table
    let username = 'Unknown User';
    try {
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('username')
        .eq('phone', userId)
        .single();
      
      if (!userError && userData) {
        username = userData.username || 'Unknown User';
      }
    } catch (userError) {
      console.error('Error fetching user data:', userError);
    }

    const { error } = await supabase
      .from('withdrawal_requests')
      .insert({
        id: crypto.randomUUID(),
        user_id: userId,
        username: username, // Store username directly in the withdrawal_requests table
        amount: amount,
        method: method,
        details: details,
        status: 'pending',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

    if (error) {
      console.error('Error adding withdrawal request:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error adding withdrawal request:', error);
    return false;
  }
};

// Approve withdrawal request
export const approveWithdrawalRequest = async (requestId: string): Promise<boolean> => {
  if (!supabase) {
    return false;
  }

  try {
    const { error } = await supabase
      .from('withdrawal_requests')
      .update({
        status: 'approved',
        updated_at: new Date().toISOString()
      })
      .eq('id', requestId);

    if (error) {
      console.error('Error approving withdrawal request:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error approving withdrawal request:', error);
    return false;
  }
};

// Reject withdrawal request
export const rejectWithdrawalRequest = async (requestId: string, reason: string): Promise<boolean> => {
  if (!supabase) {
    return false;
  }

  try {
    const { error } = await supabase
      .from('withdrawal_requests')
      .update({
        status: 'rejected',
        rejection_reason: reason,
        updated_at: new Date().toISOString()
      })
      .eq('id', requestId);

    if (error) {
      console.error('Error rejecting withdrawal request:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error rejecting withdrawal request:', error);
    return false;
  }
};

// Fix date format for withdrawal requests
export const fixDateFormat = (dateString: string): string => {
  if (!dateString || dateString === 'Invalid Date') {
    return new Date().toISOString();
  }
  
  try {
    return new Date(dateString).toISOString();
  } catch (error) {
    console.error('Error formatting date:', error);
    return new Date().toISOString();
  }
};


// Get all deposit requests from Supabase
export const getDepositRequests = async (): Promise<DepositRequest[]> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { data, error } = await supabase
      .from('deposit_requests')
      .select('*')
      .order('date', { ascending: false });
    
    if (error) {
      console.error('Failed to get deposit requests:', error);
      return [];
    }
    
    // Transform the data to match the DepositRequest interface
    const depositRequests: DepositRequest[] = data.map((item: any) => ({
      id: item.id,
      userId: item.user_id,
      username: item.username,
      amount: item.amount,
      paymentMethod: item.payment_method,
      date: item.date,
      status: item.status as 'pending' | 'approved' | 'rejected',
      rejectionReason: item.rejection_reason
    }));
    
    return depositRequests;
  } catch (error) {
    console.error('Error fetching deposit requests:', error);
    return [];
  }
};

// Add a new deposit request to Supabase
export const addDepositRequest = async (
  request: Omit<DepositRequest, 'id' | 'date' | 'status'>
): Promise<DepositRequest | null> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const newRequest = {
      id: `DEP-${Date.now().toString().slice(-6)}`,
      user_id: request.userId,
      username: request.username,
      amount: request.amount,
      payment_method: request.paymentMethod,
      date: new Date().toISOString(),
      status: 'pending' as const
    };
    
    const { data, error } = await supabase
      .from('deposit_requests')
      .insert(newRequest)
      .select()
      .single();
    
    if (error) {
      console.error('Failed to add deposit request:', error);
      return null;
    }
    
    // Transform the response to match the DepositRequest interface
    const depositRequest: DepositRequest = {
      id: data.id,
      userId: data.user_id,
      username: data.username,
      amount: data.amount,
      paymentMethod: data.payment_method,
      date: data.date,
      status: data.status as 'pending' | 'approved' | 'rejected',
      rejectionReason: data.rejection_reason
    };
    
    return depositRequest;
  } catch (error) {
    console.error('Error adding deposit request:', error);
    return null;
  }
};

// Approve a deposit request in Supabase
export const approveDepositRequest = async (id: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { error } = await supabase
      .from('deposit_requests')
      .update({ 
        status: 'approved',
        updated_at: new Date().toISOString()
      })
      .eq('id', id);
    
    if (error) {
      console.error('Failed to approve deposit request:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error approving deposit request:', error);
    return false;
  }
};

// Reject a deposit request in Supabase
export const rejectDepositRequest = async (id: string, reason: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { error } = await supabase
      .from('deposit_requests')
      .update({ 
        status: 'rejected',
        rejection_reason: reason,
        updated_at: new Date().toISOString()
      })
      .eq('id', id);
    
    if (error) {
      console.error('Failed to reject deposit request:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error rejecting deposit request:', error);
    return false;
  }
};

// Get transaction history for a user
export const getTransactionHistory = async (userId: string): Promise<any[]> => {
  if (!supabase) {
    return [];
  }

  try {
    // Get deposit requests for the user
    const { data: depositData, error: depositError } = await supabase
      .from('deposit_requests')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false });

    if (depositError) {
      console.error('Error fetching deposit requests:', depositError);
    }

    // Get withdrawal requests for the user
    const { data: withdrawalData, error: withdrawalError } = await supabase
      .from('withdrawal_requests')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (withdrawalError) {
      console.error('Error fetching withdrawal requests:', withdrawalError);
    }

    // Get balance transactions for the user
    const { data: balanceTransactionData, error: balanceTransactionError } = await supabase
      .from('balance_transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (balanceTransactionError) {
      console.error('Error fetching balance transactions:', balanceTransactionError);
    }

    // Transform deposit requests to transaction format
    const depositTransactions = (depositData || []).map((item: any) => ({
      id: item.id,
      type: 'deposit',
      amount: item.amount,
      method: item.payment_method,
      status: item.status === 'approved' ? 'completed' : item.status,
      date: new Date(item.date),
      details: `Deposit via ${item.payment_method}`,
      rejectionReason: item.rejection_reason
    }));

    // Transform withdrawal requests to transaction format
    const withdrawalTransactions = (withdrawalData || []).map((item: any) => ({
      id: item.id,
      type: 'withdrawal',
      amount: item.amount,
      method: item.method,
      status: item.status === 'approved' ? 'completed' : item.status,
      date: new Date(item.created_at),
      details: item.details || `Withdrawal to ${item.method}`,
      rejectionReason: item.rejection_reason
    }));

    // Combine all transactions and sort by date (newest first)
    const allTransactions = [...depositTransactions, ...withdrawalTransactions];
    allTransactions.sort((a, b) => b.date.getTime() - a.date.getTime());

    return allTransactions;
  } catch (error) {
    console.error('Error fetching transaction history:', error);
    return [];
  }
};