import knex from 'knex';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';

// Ensure database directory exists
const dbDir = path.resolve(process.cwd(), 'src/database');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// Initialize knex with SQLite
const db = knex({
  client: 'better-sqlite3',
  connection: {
    filename: path.join(dbDir, 'olimpbet.sqlite'),
  },
  useNullAsDefault: true,
});

// Initialize database schema
export const initDatabase = async () => {
  // Check if users table exists
  const userTableExists = await db.schema.hasTable('users');
  
  if (!userTableExists) {
    console.log('Creating users table...');
    await db.schema.createTable('users', (table) => {
      table.increments('id').primary();
      table.string('phone').unique().notNullable();
      table.string('username').nullable();
      table.string('password').notNullable();
      table.timestamp('created_at').defaultTo(db.fn.now());
      table.timestamp('updated_at').defaultTo(db.fn.now());
    });
    console.log('Users table created successfully');
  }

  // Check if failed_login_attempts table exists
  const loginAttemptsTableExists = await db.schema.hasTable('failed_login_attempts');
  
  if (!loginAttemptsTableExists) {
    console.log('Creating failed_login_attempts table...');
    await db.schema.createTable('failed_login_attempts', (table) => {
      table.increments('id').primary();
      table.string('phone').notNullable();
      table.timestamp('attempt_time').defaultTo(db.fn.now());
      table.string('ip_address').nullable();
    });
    console.log('Failed login attempts table created successfully');
  }

  // Check if blacklist table exists
  const blacklistTableExists = await db.schema.hasTable('blacklist');
  
  if (!blacklistTableExists) {
    console.log('Creating blacklist table...');
    await db.schema.createTable('blacklist', (table) => {
      table.increments('id').primary();
      table.string('phone').nullable();
      table.string('username').nullable();
      table.timestamp('blacklisted_at').defaultTo(db.fn.now());
    });
    console.log('Blacklist table created successfully');
  }
};

// Password policy enforcement
export const validatePassword = (password: string): { valid: boolean; message?: string } => {
  // Password must be at least 8 characters
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long' };
  }
  
  // Password must contain at least one uppercase letter
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one uppercase letter' };
  }
  
  // Password must contain at least one lowercase letter
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one lowercase letter' };
  }
  
  // Password must contain at least one number
  if (!/\d/.test(password)) {
    return { valid: false, message: 'Password must contain at least one number' };
  }
  
  // Password must contain at least one special character
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one special character' };
  }
  
  return { valid: true };
};

// User management functions
export const createUser = async (phone: string, password: string, username?: string) => {
  // Validate password against policy
  const passwordValidation = validatePassword(password);
  if (!passwordValidation.valid) {
    throw new Error(passwordValidation.message);
  }
  
  // Hash password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);
  
  // Insert user
  return db('users').insert({
    phone,
    username,
    password: hashedPassword,
  });
};

export const findUserByPhone = async (phone: string) => {
  return db('users').where({ phone }).first();
};

export const verifyPassword = async (hashedPassword: string, password: string) => {
  return bcrypt.compare(password, hashedPassword);
};

export const recordFailedLoginAttempt = async (phone: string, ipAddress?: string) => {
  return db('failed_login_attempts').insert({
    phone,
    ip_address: ipAddress,
  });
};

export const getRecentFailedLoginAttempts = async (phone: string, minutesWindow: number = 30) => {
  const windowTime = new Date(Date.now() - minutesWindow * 60 * 1000);
  
  return db('failed_login_attempts')
    .where({ phone })
    .where('attempt_time', '>=', windowTime)
    .count('id as count')
    .first();
};

export const isAccountLocked = async (phone: string) => {
  const attempts = await getRecentFailedLoginAttempts(phone);
  return attempts && Number(attempts.count) >= 5; // Lock after 5 failed attempts within 30 minutes
};

export default db;