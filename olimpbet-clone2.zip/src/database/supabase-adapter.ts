import { supabase, User, FailedLoginAttempt, BlacklistEntry, validatePassword } from '../config/supabase';
import bcrypt from 'bcryptjs';

// Initialize database tables in Supabase
export const initDatabase = async (): Promise<boolean> => {
  try {
    // Check if Supabase client is available
    if (!supabase) {
      throw new Error('Supabase client not configured');
    }
    
    // Check if we can connect to Supabase
    const { data, error } = await supabase.from('users').select('count', { count: 'exact', head: true });
    
    if (error && error.code === 'PGRST116') {
      console.log('Tables do not exist yet. Please run the SQL setup in your Supabase dashboard.');
      return false;
    }
    
    console.log('Supabase database adapter initialized');
    return true;
  } catch (error) {
    console.error('Failed to initialize Supabase database adapter:', error);
    return false;
  }
};

// User management functions
export const createUser = async (phone: string, password: string, username?: string) => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  // Validate password against policy
  const passwordValidation = validatePassword(password);
  if (!passwordValidation.valid) {
    throw new Error(passwordValidation.message);
  }
  
  // Hash password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);
  
  // Insert user into Supabase
  const { data, error } = await supabase
    .from('users')
    .insert({
      phone,
      username,
      password: hashedPassword,
    })
    .select()
    .single();
  
  if (error) {
    if (error.code === '23505') { // Unique constraint violation
      throw new Error('Phone number already exists');
    }
    throw new Error(`Failed to create user: ${error.message}`);
  }
  
  return data;
};

export const findUserByPhone = async (phone: string): Promise<User | null> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .single();
  
  if (error) {
    if (error.code === 'PGRST116') {
      return null; // User not found
    }
    throw new Error(`Failed to find user: ${error.message}`);
  }
  
  return data;
};

export const verifyPassword = async (hashedPassword: string, plainPassword: string): Promise<boolean> => {
  return bcrypt.compare(plainPassword, hashedPassword);
};

export const recordFailedLoginAttempt = async (phone: string, ipAddress?: string) => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  const { error } = await supabase
    .from('failed_login_attempts')
    .insert({
      phone,
      ip_address: ipAddress,
    });
  
  if (error) {
    console.error('Failed to record login attempt:', error);
  }
};

export const getRecentFailedLoginAttempts = async (phone: string, minutesAgo: number = 15): Promise<FailedLoginAttempt[]> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  const timeThreshold = new Date(Date.now() - minutesAgo * 60 * 1000).toISOString();
  
  const { data, error } = await supabase
    .from('failed_login_attempts')
    .select('*')
    .eq('phone', phone)
    .gte('attempt_time', timeThreshold)
    .order('attempt_time', { ascending: false });
  
  if (error) {
    console.error('Failed to get recent login attempts:', error);
    return [];
  }
  
  return data || [];
};

export const isAccountLocked = async (phone: string): Promise<boolean> => {
  const recentAttempts = await getRecentFailedLoginAttempts(phone, 15);
  return recentAttempts.length >= 5; // Lock after 5 failed attempts in 15 minutes
};

// Admin functions
export const getAllUsers = async (): Promise<Omit<User, 'password'>[]> => {
  console.log('getAllUsers called from supabase-adapter');
  if (!supabase) {
    console.log('Supabase client not configured, returning empty array');
    return [];
  }
  
  try {
    console.log('Attempting to fetch users from Supabase...');
    const { data, error } = await supabase
      .from('users')
      .select('id, phone, username, created_at, updated_at')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Supabase error when fetching users:', error);
      throw new Error(`Failed to get users: ${error.message}`);
    }
    
    console.log('Users fetched successfully from Supabase:', data);
    return data || [];
  } catch (err) {
    console.error('Exception in getAllUsers:', err);
    return [];
  }
};

export const getAllFailedLoginAttempts = async (): Promise<FailedLoginAttempt[]> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  const { data, error } = await supabase
    .from('failed_login_attempts')
    .select('*')
    .order('attempt_time', { ascending: false })
    .limit(100); // Limit to last 100 attempts
  
  if (error) {
    throw new Error(`Failed to get failed login attempts: ${error.message}`);
  }
  
  return data || [];
};

export const deleteUser = async (userId: number): Promise<void> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  const { error } = await supabase
    .from('users')
    .delete()
    .eq('id', userId);
  
  if (error) {
    throw new Error(`Failed to delete user: ${error.message}`);
  }
};

// Blacklist management functions
export const addToBlacklist = async (identifier: string): Promise<void> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  // Determine if identifier is phone or username
  const isPhone = /^[+]?[0-9\s\-\(\)]+$/.test(identifier);
  
  const insertData: any = {
    blacklisted_at: new Date().toISOString()
  };
  
  if (isPhone) {
    insertData.phone = identifier;
  } else {
    insertData.username = identifier;
  }
  
  const { error } = await supabase
    .from('blacklist')
    .insert(insertData);
  
  if (error) {
    throw new Error(`Failed to add to blacklist: ${error.message}`);
  }
};

export const removeFromBlacklist = async (identifier: string): Promise<void> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  const { error } = await supabase
    .from('blacklist')
    .delete()
    .or(`phone.eq.${identifier},username.eq.${identifier}`);
  
  if (error) {
    throw new Error(`Failed to remove from blacklist: ${error.message}`);
  }
};

export const isUserBlacklisted = async (phone: string, username?: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  let orConditions = [`phone.eq.${phone}`];
  
  if (username) {
    orConditions.push(`username.eq.${username}`);
  }
  
  const { data, error } = await supabase
    .from('blacklist')
    .select('id')
    .or(orConditions.join(','));
  
  if (error) {
    console.error('Failed to check blacklist:', error);
    return false;
  }
  
  return (data && data.length > 0) || false;
};

export const getAllBlacklistedUsers = async (): Promise<BlacklistEntry[]> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  const { data, error } = await supabase
    .from('blacklist')
    .select('*')
    .order('blacklisted_at', { ascending: false });
  
  if (error) {
    throw new Error(`Failed to get blacklisted users: ${error.message}`);
  }
  
  return data || [];
};

export { validatePassword };
