/**
 * This file provides a browser-compatible adapter for the database operations.
 * Since SQLite is a Node.js module and won't work directly in the browser,
 * we need to create a compatible layer that uses localStorage for development
 * but could be replaced with API calls to a backend server in production.
 */

import bcrypt from 'bcryptjs';

// User type definition
interface User {
  id?: number;
  phone: string;
  username?: string;
  password: string;
  created_at?: string;
  updated_at?: string;
}

// Failed login attempt type definition
interface FailedLoginAttempt {
  id?: number;
  phone: string;
  attempt_time: string;
  ip_address?: string;
}

// Initialize database tables in localStorage if they don't exist
export const initDatabase = async (): Promise<boolean> => {
  try {
    if (!localStorage.getItem('db_users')) {
      localStorage.setItem('db_users', JSON.stringify([]));
    }
    
    if (!localStorage.getItem('db_failed_login_attempts')) {
      localStorage.setItem('db_failed_login_attempts', JSON.stringify([]));
    }
    
    if (!localStorage.getItem('db_blacklist')) {
      localStorage.setItem('db_blacklist', JSON.stringify([]));
    }
    
    console.log('Browser database adapter initialized');
    return true;
  } catch (error) {
    console.error('Failed to initialize browser database adapter:', error);
    return false;
  }
};

// Password policy enforcement
export const validatePassword = (password: string): { valid: boolean; message?: string } => {
  // Password must be at least 8 characters
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long' };
  }
  
  // Password must contain at least one uppercase letter
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one uppercase letter' };
  }
  
  // Password must contain at least one lowercase letter
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one lowercase letter' };
  }
  
  // Password must contain at least one number
  if (!/\d/.test(password)) {
    return { valid: false, message: 'Password must contain at least one number' };
  }
  
  // Password must contain at least one special character
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one special character' };
  }
  
  return { valid: true };
};

// User management functions
export const createUser = async (phone: string, password: string, username?: string): Promise<number> => {
  // Validate password against policy
  const passwordValidation = validatePassword(password);
  if (!passwordValidation.valid) {
    throw new Error(passwordValidation.message);
  }
  
  // Check if user already exists
  const existingUser = await findUserByPhone(phone);
  if (existingUser) {
    throw new Error('Phone number already exists');
  }
  
  // Hash password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);
  
  // Get users from localStorage
  const users = JSON.parse(localStorage.getItem('db_users') || '[]');
  
  // Create new user
  const newUser: User = {
    id: users.length + 1,
    phone,
    username,
    password: hashedPassword,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
  
  // Add user to array and save back to localStorage
  users.push(newUser);
  localStorage.setItem('db_users', JSON.stringify(users));
  
  return newUser.id!;
};

export const findUserByPhone = async (phone: string): Promise<User | undefined> => {
  const users = JSON.parse(localStorage.getItem('db_users') || '[]');
  return users.find((user: User) => user.phone === phone);
};

export const verifyPassword = async (hashedPassword: string, password: string): Promise<boolean> => {
  return bcrypt.compare(password, hashedPassword);
};

export const recordFailedLoginAttempt = async (phone: string, ipAddress?: string): Promise<number> => {
  const attempts = JSON.parse(localStorage.getItem('db_failed_login_attempts') || '[]');
  
  const newAttempt: FailedLoginAttempt = {
    id: attempts.length + 1,
    phone,
    attempt_time: new Date().toISOString(),
    ip_address: ipAddress
  };
  
  attempts.push(newAttempt);
  localStorage.setItem('db_failed_login_attempts', JSON.stringify(attempts));
  
  return newAttempt.id!;
};

export const getRecentFailedLoginAttempts = async (phone: string, minutesWindow: number = 30): Promise<{ count: number }> => {
  const attempts = JSON.parse(localStorage.getItem('db_failed_login_attempts') || '[]');
  const windowTime = new Date(Date.now() - minutesWindow * 60 * 1000).toISOString();
  
  const recentAttempts = attempts.filter(
    (attempt: FailedLoginAttempt) => 
      attempt.phone === phone && attempt.attempt_time >= windowTime
  );
  
  return { count: recentAttempts.length };
};

export const isAccountLocked = async (phone: string): Promise<boolean> => {
  const attempts = await getRecentFailedLoginAttempts(phone);
  return attempts.count >= 5; // Lock after 5 failed attempts within 30 minutes
};