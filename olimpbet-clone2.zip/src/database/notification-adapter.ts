import { supabase } from '../config/supabase';

interface Notification {
  id: string;
  message: string;
  read: boolean;
  timestamp: number;
}

// Get user notifications from Supabase
export const getUserNotifications = async (userId: string): Promise<Notification[]> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('timestamp', { ascending: false });
    
    if (error) {
      console.error('Failed to get user notifications:', error);
      return [];
    }
    
    // Transform the data to match the Notification interface
    const notifications: Notification[] = data.map((item: any) => ({
      id: item.id,
      message: item.message,
      read: item.read,
      timestamp: new Date(item.timestamp).getTime()
    }));
    
    return notifications;
  } catch (error) {
    console.error('Error fetching user notifications:', error);
    return [];
  }
};

// Add a new notification to Supabase
export const addNotification = async (userId: string, message: string): Promise<Notification | null> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const timestamp = new Date().toISOString();
    const id = `NOTIF-${Date.now().toString().slice(-6)}`;
    
    const { data, error } = await supabase
      .from('notifications')
      .insert({
        id,
        user_id: userId,
        message,
        read: false,
        timestamp
      })
      .select()
      .single();
    
    if (error) {
      console.error('Failed to add notification:', error);
      return null;
    }
    
    // Transform the response to match the Notification interface
    const notification: Notification = {
      id: data.id,
      message: data.message,
      read: data.read,
      timestamp: new Date(data.timestamp).getTime()
    };
    
    return notification;
  } catch (error) {
    console.error('Error adding notification:', error);
    return null;
  }
};

// Mark a notification as read in Supabase
export const markNotificationAsRead = async (id: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ 
        read: true,
        updated_at: new Date().toISOString() 
      })
      .eq('id', id);
    
    if (error) {
      console.error('Failed to mark notification as read:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error marking notification as read:', error);
    return false;
  }
};

// Mark all notifications as read for a user in Supabase
export const markAllNotificationsAsRead = async (userId: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ 
        read: true,
        updated_at: new Date().toISOString() 
      })
      .eq('user_id', userId)
      .eq('read', false);
    
    if (error) {
      console.error('Failed to mark all notifications as read:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    return false;
  }
};

// Remove a notification from Supabase
export const removeNotification = async (id: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Failed to remove notification:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error removing notification:', error);
    return false;
  }
};