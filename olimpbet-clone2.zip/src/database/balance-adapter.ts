import { supabase } from '../config/supabase';

// Get user balance from Supabase
export const getUserBalance = async (userId: string): Promise<number | null> => {
  console.log('getUserBalance called for user:', userId);
  if (!supabase) {
    console.log('Supabase client not configured in getUserBalance');
    throw new Error('Supabase client not configured');
  }
  
  try {
    console.log('Querying user_balances table for user:', userId);
    const { data, error } = await supabase
      .from('user_balances')
      .select('balance')
      .eq('user_id', userId)
      .single();
    
    if (error) {
      console.error('Failed to get user balance:', error);
      return null;
    }
    
    console.log('User balance data from Supabase:', data);
    // Return the balance value, including 0 as a valid balance
    return data?.balance !== undefined ? data.balance : null;
  } catch (error) {
    console.error('Error fetching user balance:', error);
    return null;
  }
};

// Update user balance in Supabase
export const updateUserBalance = async (userId: string, newBalance: number): Promise<boolean> => {
  console.log('updateUserBalance called with:', { userId, newBalance });
  if (!supabase) {
    console.log('Supabase client not configured in updateUserBalance');
    throw new Error('Supabase client not configured');
  }
  
  try {
    // Check if user balance exists
    console.log('Checking if user balance exists for user:', userId);
    const { data: existingBalance } = await supabase
      .from('user_balances')
      .select('id')
      .eq('user_id', userId)
      .single();
    
    console.log('Existing balance check result:', existingBalance);
    
    if (existingBalance) {
      // Update existing balance
      console.log('Updating existing balance to:', newBalance);
      const { error } = await supabase
        .from('user_balances')
        .update({ 
          balance: newBalance,
          updated_at: new Date().toISOString() 
        })
        .eq('user_id', userId);
      
      if (error) {
        console.error('Failed to update user balance:', error);
        return false;
      }
      console.log('Successfully updated balance in Supabase');
    } else {
      // Insert new balance record
      console.log('No existing balance, inserting new record with balance:', newBalance);
      const { error } = await supabase
        .from('user_balances')
        .insert({ 
          user_id: userId,
          balance: newBalance,
          currency: 'KZT' // Default currency
        });
      
      if (error) {
        console.error('Failed to insert user balance:', error);
        return false;
      }
      console.log('Successfully inserted new balance record in Supabase');
    }
    
    return true;
  } catch (error) {
    console.error('Error updating user balance:', error);
    return false;
  }
};

// Add balance to user (for admin manual balance addition)
export const addBalanceToUser = async (userId: string, amount: number, reason?: string): Promise<boolean> => {
  console.log('addBalanceToUser called with:', { userId, amount, reason });
  if (!supabase) {
    console.log('Supabase client not configured in addBalanceToUser');
    throw new Error('Supabase client not configured');
  }

  try {
    // Get current balance
    console.log('Getting current balance for user:', userId);
    const currentBalance = await getUserBalance(userId);
    console.log('Current balance:', currentBalance);
    
    if (currentBalance === null) {
      // Create new balance record if user doesn't have one
      console.log('No existing balance, creating new record with amount:', amount);
      const { error } = await supabase
        .from('user_balances')
        .insert({ 
          user_id: userId,
          balance: amount,
          currency: 'KZT'
        });
      
      if (error) {
        console.error('Failed to create user balance:', error);
        return false;
      }
      console.log('Created new balance record with amount:', amount);
    } else {
      // Update existing balance
      const newBalance = currentBalance + amount;
      console.log('Updating existing balance from', currentBalance, 'to', newBalance);
      const success = await updateUserBalance(userId, newBalance);
      if (!success) {
        console.log('Failed to update user balance');
        return false;
      }
      console.log('Successfully updated balance to:', newBalance);
    }

    // Log the transaction
    const { error: transactionError } = await supabase
      .from('balance_transactions')
      .insert({
        user_id: userId,
        amount: amount,
        type: 'admin_add',
        reason: reason || 'Manual balance addition by admin',
        created_at: new Date().toISOString()
      });

    if (transactionError) {
      console.error('Failed to log balance transaction:', transactionError);
      // Don't fail the operation if logging fails
    }

    return true;
  } catch (error) {
    console.error('Error adding balance to user:', error);
    return false;
  }
};

// Remove balance from user account
export const removeBalanceFromUser = async (userId: string, amount: number, reason?: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }

  if (amount <= 0) {
    console.error('Amount must be positive for balance removal');
    return false;
  }

  try {
    // Get current balance
    console.log('Getting current balance for user:', userId);
    const currentBalance = await getUserBalance(userId);
    console.log('Current balance:', currentBalance);
    
    if (currentBalance === null) {
      console.error('User has no balance record');
      return false;
    }

    // Check if user has sufficient balance
    if (currentBalance < amount) {
      console.error(`Insufficient balance. Current: ${currentBalance}, Requested removal: ${amount}`);
      return false;
    }

    // Calculate new balance
    const newBalance = currentBalance - amount;
    console.log('Removing balance from', currentBalance, 'to', newBalance);
    
    // Update balance
    const success = await updateUserBalance(userId, newBalance);
    if (!success) {
      console.log('Failed to update user balance');
      return false;
    }

    console.log(`Successfully removed ${amount} from user ${userId}. New balance: ${newBalance}`);
    return true;
  } catch (error) {
    console.error('Error removing balance from user:', error);
    return false;
  }
};

// Get user currency from Supabase
export const getUserCurrency = async (userId: string): Promise<string | null> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    const { data, error } = await supabase
      .from('user_balances')
      .select('currency')
      .eq('user_id', userId)
      .single();
    
    if (error) {
      console.error('Failed to get user currency:', error);
      return null;
    }
    
    return data?.currency || null;
  } catch (error) {
    console.error('Error fetching user currency:', error);
    return null;
  }
};

// Update user currency in Supabase
export const updateUserCurrency = async (userId: string, currency: string): Promise<boolean> => {
  if (!supabase) {
    throw new Error('Supabase client not configured');
  }
  
  try {
    // Check if user balance exists
    const { data: existingBalance } = await supabase
      .from('user_balances')
      .select('id')
      .eq('user_id', userId)
      .single();
    
    if (existingBalance) {
      // Update existing currency
      const { error } = await supabase
        .from('user_balances')
        .update({ 
          currency: currency,
          updated_at: new Date().toISOString() 
        })
        .eq('user_id', userId);
      
      if (error) {
        console.error('Failed to update user currency:', error);
        return false;
      }
    } else {
      // Insert new balance record with currency
      const { error } = await supabase
        .from('user_balances')
        .insert({ 
          user_id: userId,
          balance: 0, // Default balance - new users start with 0
          currency: currency
        });
      
      if (error) {
        console.error('Failed to insert user currency:', error);
        return false;
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error updating user currency:', error);
    return false;
  }
};