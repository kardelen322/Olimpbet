// Import adapters
import * as supabaseAdapter from './supabase-adapter';
import * as browserAdapter from './browser-adapter';
import { isSupabaseConfigured } from '../config/supabase';

// Choose the appropriate adapter
const useSupabase = isSupabaseConfigured();
const adapter = useSupabase ? supabaseAdapter : browserAdapter;

// Initialize the database when this module is imported
export const initializeDatabase = async () => {
  console.log('Initializing database...');
  console.log('isSupabaseConfigured():', isSupabaseConfigured());
  console.log('useSupabase:', useSupabase);
  try {
    if (useSupabase) {
      console.log('Using Supabase database adapter');
      const result = await adapter.initDatabase();
      console.log('Supabase adapter initialization result:', result);
    } else {
      console.log('Using browser localStorage adapter (Supabase not configured)');
      const result = await adapter.initDatabase();
      console.log('Browser adapter initialization result:', result);
    }
    console.log('Database initialized successfully');
    return true;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    // Fallback to browser adapter if Supabase fails
    if (useSupabase) {
      console.log('Falling back to browser adapter');
      try {
        const result = await browserAdapter.initDatabase();
        console.log('Fallback database initialization result:', result);
        console.log('Fallback database initialized successfully');
        return true;
      } catch (fallbackError) {
        console.error('Fallback database initialization failed:', fallbackError);
        return false;
      }
    }
    return false;
  }
};

// Export all functions from the chosen adapter
export const {
  validatePassword,
  createUser,
  findUserByPhone,
  verifyPassword,
  recordFailedLoginAttempt,
  getRecentFailedLoginAttempts,
  isAccountLocked
} = adapter;

// Export admin functions if using Supabase
export const getAllUsers = useSupabase && 'getAllUsers' in adapter ? adapter.getAllUsers : async () => {
  console.log('getAllUsers called from index.ts fallback function');
  // Fallback for browser adapter
  const storedUsers = localStorage.getItem('db_users');
  console.log('localStorage db_users:', storedUsers);
  if (storedUsers) {
    const parsedUsers = JSON.parse(storedUsers);
    console.log('Parsed users from localStorage:', parsedUsers);
    const result = parsedUsers.map((user: any) => {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    });
    console.log('Returning users without passwords:', result);
    return result;
  }
  console.log('No users found in localStorage, returning empty array');
  return [];
};

export const getAllFailedLoginAttempts = useSupabase && 'getAllFailedLoginAttempts' in adapter ? adapter.getAllFailedLoginAttempts : async () => {
  // Fallback for browser adapter
  const storedAttempts = localStorage.getItem('db_failed_login_attempts');
  return storedAttempts ? JSON.parse(storedAttempts) : [];
};

export const deleteUser = useSupabase && 'deleteUser' in adapter ? adapter.deleteUser : async (userId: number) => {
  // Fallback for browser adapter
  const storedUsers = localStorage.getItem('db_users');
  if (storedUsers) {
    const users = JSON.parse(storedUsers);
    const filteredUsers = users.filter((user: any) => user.id !== userId);
    localStorage.setItem('db_users', JSON.stringify(filteredUsers));
  }
};

// Export blacklist functions
export const addToBlacklist = useSupabase && 'addToBlacklist' in adapter ? adapter.addToBlacklist : async (identifier: string) => {
  // Fallback for browser adapter
  const storedBlacklist = localStorage.getItem('db_blacklist');
  const blacklist = storedBlacklist ? JSON.parse(storedBlacklist) : [];
  
  // Determine if identifier is phone or username
  const isPhone = /^[+]?[0-9\s\-\(\)]+$/.test(identifier);
  
  const newEntry = {
    id: Date.now(),
    phone: isPhone ? identifier : null,
    username: isPhone ? null : identifier,
    blacklisted_at: new Date().toISOString()
  };
  blacklist.push(newEntry);
  localStorage.setItem('db_blacklist', JSON.stringify(blacklist));
};

export const removeFromBlacklist = useSupabase && 'removeFromBlacklist' in adapter ? adapter.removeFromBlacklist : async (identifier: string) => {
  // Fallback for browser adapter
  const storedBlacklist = localStorage.getItem('db_blacklist');
  if (storedBlacklist) {
    const blacklist = JSON.parse(storedBlacklist);
    const filteredBlacklist = blacklist.filter((entry: any) => 
      entry.phone !== identifier && entry.username !== identifier
    );
    localStorage.setItem('db_blacklist', JSON.stringify(filteredBlacklist));
  }
};

export const isUserBlacklisted = useSupabase && 'isUserBlacklisted' in adapter ? adapter.isUserBlacklisted : async (phone: string, username?: string) => {
  // Fallback for browser adapter
  const storedBlacklist = localStorage.getItem('db_blacklist');
  if (storedBlacklist) {
    const blacklist = JSON.parse(storedBlacklist);
    return blacklist.some((entry: any) => 
      entry.phone === phone || (username && entry.username === username)
    );
  }
  return false;
};

export const getAllBlacklistedUsers = useSupabase && 'getAllBlacklistedUsers' in adapter ? adapter.getAllBlacklistedUsers : async () => {
  // Fallback for browser adapter
  const storedBlacklist = localStorage.getItem('db_blacklist');
  return storedBlacklist ? JSON.parse(storedBlacklist) : [];
};
