import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider } from './contexts/AuthContext';
import { PaymentProvider } from './contexts/PaymentContext';
import { NotificationProvider } from './contexts/NotificationContext';
import { BalanceProvider } from './contexts/BalanceContext';
import { WithdrawalProvider } from './contexts/WithdrawalContext';
import ResponsiveWrapper from './components/ResponsiveWrapper';
import BlacklistChecker from './components/BlacklistChecker';
import PageSEO from './components/PageSEO';
import StructuredData from './components/StructuredData';

// Desktop Components
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import Statistics from './components/Statistics';
import FAQ from './components/FAQ';
import AboutUs from './components/AboutUs';
import Support from './components/Support';
import TermsConditions from './components/TermsConditions';
import Bonuses from './components/Bonuses';
import Results from './components/Results';
import ResponsibleGaming from './components/ResponsibleGaming';
import Sports from './components/Sports';
import Live from './components/Live';
import Bets247 from './components/Bets247';
import Esports from './components/Esports';
import AuthModal from './components/AuthModal';
import Login from './components/Login';
import Register from './components/Register';
import Admin from './components/Admin';

// New Desktop Components
import Notifications from './components/Notifications';
import Settings from './components/Settings';
import QuickBet from './components/QuickBet';
import MyBets from './components/MyBets';
import CashOut from './components/CashOut';
import Deposit from './components/Deposit';
import Withdrawal from './components/Withdrawal';
import PaymentHistory from './components/PaymentHistory';

// Mobile Components
import HeaderMobile from './components/mobile/HeaderMobile';
import HomePageMobile from './components/mobile/HomePageMobile';
import FAQMobile from './components/mobile/FAQMobile';
import AboutUsMobile from './components/mobile/AboutUsMobile';
import ResultsMobile from './components/mobile/ResultsMobile';
import ResponsibleGamingMobile from './components/mobile/ResponsibleGamingMobile';
import SportsMobile from './components/mobile/SportsMobile';
import LiveMobile from './components/mobile/LiveMobile';
import Bets247Mobile from './components/mobile/Bets247Mobile';
import EsportsMobile from './components/mobile/EsportsMobile';
import StatisticsMobile from './components/mobile/StatisticsMobile';
import SupportMobile from './components/mobile/SupportMobile';
import TermsConditionsMobile from './components/mobile/TermsConditionsMobile';
import BonusesMobile from './components/mobile/BonusesMobile';
import AuthModalMobile from './components/mobile/AuthModalMobile';
import LoginMobile from './components/mobile/LoginMobile';
import RegisterMobile from './components/mobile/RegisterMobile';
import AdminMobile from './components/mobile/AdminMobile';

// New Mobile Components
import NotificationsMobile from './components/mobile/NotificationsMobile';
import SettingsMobile from './components/mobile/SettingsMobile';
import QuickBetMobile from './components/QuickBetMobile';
import MyBetsMobile from './components/MyBetsMobile';
import CashOutMobile from './components/CashOutMobile';
import DepositMobile from './components/DepositMobile';
import WithdrawalMobile from './components/WithdrawalMobile';
import PaymentHistoryMobile from './components/PaymentHistoryMobile';

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AuthProvider>
        <NotificationProvider>
          <BalanceProvider>
            <PaymentProvider>
              <WithdrawalProvider>
              <Router>
                <PageSEO />
                <StructuredData />
                <BlacklistChecker>
                  <ResponsiveWrapper
                     desktop={
                        <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
              {/* Desktop Header */}
              <Header />
              
              {/* Desktop Main Content Area */}
              <main style={{ flex: 1 }}>
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/statistics" element={<Statistics />} />
                  <Route path="/faq" element={<FAQ />} />
                  <Route path="/about" element={<AboutUs />} />
                  <Route path="/support" element={<Support />} />
                  <Route path="/terms" element={<TermsConditions />} />
                  <Route path="/bonuses" element={<Bonuses />} />
                  <Route path="/results" element={<Results />} />
                  <Route path="/results-live" element={<Results />} />
                  <Route path="/warning" element={<ResponsibleGaming />} />
                  <Route path="/sports" element={<Sports />} />
                  <Route path="/live" element={<Live />} />
                  <Route path="/bets247" element={<Bets247 />} />
                  <Route path="/esports" element={<Esports />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  <Route path="/auth" element={<AuthModal isOpen={true} onClose={() => {}} />} />
                  <Route path="/admin" element={<Admin />} />
                  
                  {/* New Routes for User Sidebar Features */}
                  <Route path="/notifications" element={<Notifications />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/quick-bet" element={<QuickBet />} />
                  <Route path="/my-bets" element={<MyBets />} />
                  <Route path="/cash-out" element={<CashOut />} />
                  <Route path="/deposit" element={<Deposit />} />
                  <Route path="/withdrawal" element={<Withdrawal />} />
                  <Route path="/payment-history" element={<PaymentHistory />} />
                </Routes>
              </main>
              
              {/* Desktop Footer */}
              <Footer />
            </div>
          }
          mobile={
            <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
              {/* Mobile Header */}
              <HeaderMobile />
              
              {/* Mobile Main Content Area */}
              <main style={{ flex: 1 }}>
                <Routes>
                  <Route path="/" element={<HomePageMobile />} />
                  <Route path="/statistics" element={<StatisticsMobile />} />
                  <Route path="/faq" element={<FAQMobile />} />
                  <Route path="/about" element={<AboutUsMobile />} />
                  <Route path="/support" element={<SupportMobile />} />
                  <Route path="/terms" element={<TermsConditionsMobile />} />
                  <Route path="/bonuses" element={<BonusesMobile />} />
                  <Route path="/results" element={<ResultsMobile />} />
                  <Route path="/results-live" element={<ResultsMobile />} />
                  <Route path="/warning" element={<ResponsibleGamingMobile />} />
                  <Route path="/sports" element={<SportsMobile />} />
                  <Route path="/live" element={<LiveMobile />} />
                  <Route path="/bets247" element={<Bets247Mobile />} />
                  <Route path="/esports" element={<EsportsMobile />} />
                  <Route path="/login" element={<LoginMobile />} />
                  <Route path="/register" element={<RegisterMobile />} />
                  <Route path="/auth" element={<AuthModalMobile />} />
                  <Route path="/admin" element={<AdminMobile />} />
                  
                  {/* New Routes for User Sidebar Features - Mobile */}
                  <Route path="/notifications" element={<NotificationsMobile />} />
                  <Route path="/settings" element={<SettingsMobile />} />
                  <Route path="/quick-bet" element={<QuickBetMobile />} />
                  <Route path="/my-bets" element={<MyBetsMobile />} />
                  <Route path="/cash-out" element={<CashOutMobile />} />
                  <Route path="/deposit" element={<DepositMobile />} />
                  <Route path="/withdrawal" element={<WithdrawalMobile />} />
                  <Route path="/payment-history" element={<PaymentHistoryMobile />} />
                </Routes>
              </main>
              
              {/* Mobile Footer - Could be simplified or hidden */}
              <div style={{ 
                backgroundColor: '#232323', 
                color: 'white', 
                padding: '20px', 
                textAlign: 'center',
                fontSize: '12px'
              }}>
                © 2024 OLIMPBET. All rights reserved.
              </div>
            </div>
          }
        />
                  </BlacklistChecker>
                </Router>
              </WithdrawalProvider>
            </PaymentProvider>
          </BalanceProvider>
        </NotificationProvider>
      </AuthProvider>
    </LanguageProvider>
  );
};

export default App;
