import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const Statistics: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState('popular');

  const popularSportsData = [
    { key: 'football', icon: '⚽', name: translate('football'), bets: '45,230', percentage: 38.2 },
    { key: 'tennis', icon: '🎾', name: translate('tennis'), bets: '28,450', percentage: 24.1 },
    { key: 'basketball', icon: '🏀', name: translate('basketball'), bets: '19,830', percentage: 16.8 },
    { key: 'hockey', icon: '🏒', name: translate('hockey'), bets: '12,470', percentage: 10.6 },
    { key: 'volleyball', icon: '🏐', name: translate('volleyball'), bets: '7,890', percentage: 6.7 },
    { key: 'handball', icon: '🤾', name: translate('handball'), bets: '4,230', percentage: 3.6 }
  ];

  const trendingMatches = [
    { teams: 'Real Madrid vs Barcelona', sport: 'Футбол', odds: '2.15', trend: '↗', volume: '15,430' },
    { teams: 'Lakers vs Warriors', sport: 'Баскетбол', odds: '1.95', trend: '↗', volume: '12,880' },
    { teams: 'Djokovic vs Nadal', sport: 'Теннис', odds: '1.75', trend: '↘', volume: '11,250' },
    { teams: 'Rangers vs Capitals', sport: 'Хоккей', odds: '2.05', trend: '↗', volume: '8,920' }
  ];

  const weeklyStats = [
    { day: 'Пн', bets: 8420, winRate: 62 },
    { day: 'Вт', bets: 9230, winRate: 58 },
    { day: 'Ср', bets: 11450, winRate: 65 },
    { day: 'Чт', bets: 10890, winRate: 61 },
    { day: 'Пт', bets: 15670, winRate: 69 },
    { day: 'Сб', bets: 22340, winRate: 71 },
    { day: 'Вс', bets: 19880, winRate: 67 }
  ];

  const allSportsData = [
    { key: 'football', icon: '⚽', name: translate('football') },
    { key: 'tennis', icon: '🎾', name: translate('tennis') },
    { key: 'hockey', icon: '🏒', name: translate('hockey') },
    { key: 'basketball', icon: '🏀', name: translate('basketball') },
    { key: 'handball', icon: '🤾', name: translate('handball') },
    { key: 'volleyball', icon: '🏐', name: translate('volleyball') },
    { key: 'baseball', icon: '⚾', name: translate('baseball') },
    { key: 'americanFootball', icon: '🏈', name: translate('americanFootball') },
    { key: 'rugby', icon: '🏉', name: translate('rugby') },
    { key: 'badminton', icon: '🏸', name: translate('badminton') },
    { key: 'cycling', icon: '🚴', name: translate('cycling') },
    { key: 'swimming', icon: '🏊', name: translate('swimming') },
    { key: 'stockCar', icon: '🏎️', name: translate('stockCar') },
    { key: 'indyCar', icon: '🏁', name: translate('indyCar') },
    { key: 'motorcycleRacing', icon: '🏍️', name: translate('motorcycleRacing') },
    { key: 'darts', icon: '🎯', name: translate('dartsGame') },
    { key: 'winterSports', icon: '❄️', name: translate('winterSports') },
    { key: 'curling', icon: '🥌', name: translate('curling') },
    { key: 'cricket', icon: '🏏', name: translate('cricketGame') },
    { key: 'crossCountrySkiing', icon: '🎳', name: translate('crossCountrySkiing') },
    { key: 'tabletennis', icon: '🏓', name: translate('tabletennisGame') },
    { key: 'pesapallo', icon: '⚾', name: translate('pesapallo') },
    { key: 'beachVolleyball', icon: '🏐', name: translate('beachVolleyball') },
    { key: 'beachFootball', icon: '⚽', name: translate('beachFootball') },
    { key: 'rally', icon: '🚗', name: translate('rally') },
    { key: 'squash', icon: '🎾', name: translate('squash') },
    { key: 'snooker', icon: '🎱', name: translate('snookerGame') },
    { key: 'speedway', icon: '🏁', name: translate('speedway') },
    { key: 'floorball', icon: '🏑', name: translate('floorball') },
    { key: 'formula1', icon: '🏎️', name: translate('formula1') },
    { key: 'futsal', icon: '⚽', name: translate('futsal') },
    { key: 'fieldHockey', icon: '🏑', name: translate('fieldHockey') },
    { key: 'iceHockeyStick', icon: '🏒', name: translate('iceHockeyStick') }
  ];

  return (
    <div style={{ 
      display: 'flex', 
      margin: '0 auto', 
      padding: '20px 20px 20px 10px',
      gap: '20px' 
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />
      
      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <h1 style={{
            fontSize: '32px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 10px 0'
          }}>
            {translate('statistics')}
          </h1>
          <p style={{
            fontSize: '16px',
            color: '#666',
            margin: '0'
          }}>
            Статистика ставок и аналитика спортивных событий
          </p>
        </div>

        {/* Tab Navigation */}
        <div style={{
          backgroundColor: 'white',
          padding: '0',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ display: 'flex' }}>
            {[
              { key: 'popular', label: 'Популярные виды спорта' },
              { key: 'trending', label: 'Трендовые матчи' },
              { key: 'analytics', label: 'Аналитика' },
              { key: 'all', label: 'Все виды спорта' }
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
              style={{
                  flex: 1,
                  padding: '15px 20px',
                  border: 'none',
                  backgroundColor: activeTab === tab.key ? '#6b0c17' : 'white',
                  color: activeTab === tab.key ? 'white' : '#666',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== tab.key) {
                    e.currentTarget.style.backgroundColor = '#f5f5f5';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== tab.key) {
                    e.currentTarget.style.backgroundColor = 'white';
                  }
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Popular Sports Tab */}
        {activeTab === 'popular' && (
          <div>
            {/* Overall Stats Cards */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: '20px',
              marginBottom: '30px'
            }}>
              <div style={{
                backgroundColor: 'white',
                padding: '25px',
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '32px', marginBottom: '10px' }}>📊</div>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#6b0c17', marginBottom: '5px' }}>
                  118,100
                </div>
                <div style={{ fontSize: '14px', color: '#666' }}>Всего ставок сегодня</div>
              </div>

              <div style={{
                backgroundColor: 'white',
                padding: '25px',
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '32px', marginBottom: '10px' }}>💰</div>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#22c55e', marginBottom: '5px' }}>
                  ₽2.8M
                </div>
                <div style={{ fontSize: '14px', color: '#666' }}>Общий оборот</div>
              </div>

              <div style={{
                backgroundColor: 'white',
                padding: '25px',
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '32px', marginBottom: '10px' }}>🎯</div>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#3b82f6', marginBottom: '5px' }}>
                  64.2%
                </div>
                <div style={{ fontSize: '14px', color: '#666' }}>Средний процент выигрышей</div>
              </div>

              <div style={{
                backgroundColor: 'white',
                padding: '25px',
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '32px', marginBottom: '10px' }}>🔥</div>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#f59e0b', marginBottom: '5px' }}>
                  342
                </div>
                <div style={{ fontSize: '14px', color: '#666' }}>Активные матчи</div>
              </div>
            </div>

            {/* Popular Sports Chart */}
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '12px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
            }}>
              <h2 style={{
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#333',
                marginBottom: '25px'
              }}>
                Популярные виды спорта (по количеству ставок)
              </h2>
              
              {popularSportsData.map((sport, index) => (
                <div key={sport.key} style={{
                  display: 'flex',
                  alignItems: 'center',
                  padding: '15px 0',
                  borderBottom: index < popularSportsData.length - 1 ? '1px solid #f1f5f9' : 'none'
                }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    flex: 1
                  }}>
                    <div style={{
                      fontSize: '24px',
                      marginRight: '15px',
                      width: '40px',
                      textAlign: 'center'
                    }}>
                      {sport.icon}
                    </div>
                    <div>
                      <div style={{
                        fontSize: '16px',
                        fontWeight: 'bold',
                        color: '#333',
                        marginBottom: '2px'
                      }}>
                        {sport.name}
                      </div>
                      <div style={{
                        fontSize: '14px',
                        color: '#666'
                      }}>
                        {sport.bets} ставок
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ width: '200px', marginRight: '20px' }}>
                    <div style={{
                      backgroundColor: '#f1f5f9',
                      borderRadius: '10px',
                      height: '8px',
                      overflow: 'hidden'
                    }}>
                      <div style={{
                        backgroundColor: '#6b0c17',
                        height: '100%',
                        width: `${sport.percentage}%`,
                        borderRadius: '10px',
                        transition: 'width 0.5s ease'
                      }} />
                    </div>
                  </div>
                  
                  <div style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    color: '#6b0c17',
                    minWidth: '60px',
                    textAlign: 'right'
                  }}>
                    {sport.percentage}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Trending Matches Tab */}
        {activeTab === 'trending' && (
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '12px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '20px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '25px'
            }}>
              Трендовые матчи (наибольшее количество ставок)
            </h2>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 120px 100px 80px 100px',
              gap: '20px',
              alignItems: 'center',
              padding: '15px 0',
              borderBottom: '2px solid #f1f5f9',
              fontWeight: 'bold',
              color: '#666',
              fontSize: '14px'
            }}>
              <div>Матч</div>
              <div style={{ textAlign: 'center' }}>Вид спорта</div>
              <div style={{ textAlign: 'center' }}>Коэффициент</div>
              <div style={{ textAlign: 'center' }}>Тренд</div>
              <div style={{ textAlign: 'center' }}>Объем ставок</div>
            </div>

            {trendingMatches.map((match, index) => (
              <div key={index} style={{
                display: 'grid',
                gridTemplateColumns: '1fr 120px 100px 80px 100px',
                gap: '20px',
                alignItems: 'center',
                padding: '15px 0',
                borderBottom: index < trendingMatches.length - 1 ? '1px solid #f1f5f9' : 'none'
              }}>
                <div>
                  <div style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    color: '#333',
                    marginBottom: '4px'
                  }}>
                    {match.teams}
                  </div>
                  <div style={{
                    fontSize: '12px',
                    color: '#666'
                  }}>
                    Сегодня, 19:00
                  </div>
                </div>
                <div style={{
                  textAlign: 'center',
                  fontSize: '14px',
                  color: '#666'
                }}>
                  {match.sport}
                </div>
                <div style={{
                  textAlign: 'center',
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: '#6b0c17'
                }}>
                  {match.odds}
                </div>
                <div style={{
                  textAlign: 'center',
                  fontSize: '20px',
                  color: match.trend === '↗' ? '#22c55e' : '#ef4444'
                }}>
                  {match.trend}
                </div>
                <div style={{
                  textAlign: 'center',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  color: '#333'
                }}>
                  {match.volume}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div>
            {/* Weekly Statistics */}
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '12px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
              marginBottom: '20px'
            }}>
              <h2 style={{
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#333',
                marginBottom: '25px'
              }}>
                Статистика за неделю
              </h2>
              
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: '15px'
              }}>
                {weeklyStats.map((day, index) => (
                  <div key={index} style={{
                    backgroundColor: '#f8f9fa',
                    padding: '20px 15px',
                    borderRadius: '10px',
                    textAlign: 'center',
                    border: '2px solid transparent',
                    transition: 'all 0.3s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = '#6b0c17';
                    e.currentTarget.style.backgroundColor = '#fee2e2';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'transparent';
                    e.currentTarget.style.backgroundColor = '#f8f9fa';
                  }}
                  >
                    <div style={{
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: '#666',
                      marginBottom: '10px'
                    }}>
                      {day.day}
                    </div>
                    <div style={{
                      fontSize: '20px',
                      fontWeight: 'bold',
                      color: '#6b0c17',
                      marginBottom: '8px'
                    }}>
                      {day.bets.toLocaleString()}
                    </div>
                    <div style={{
                      fontSize: '12px',
                      color: '#666',
                      marginBottom: '8px'
                    }}>
                      ставок
                    </div>
                    <div style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: day.winRate > 65 ? '#22c55e' : day.winRate > 60 ? '#f59e0b' : '#ef4444'
                    }}>
                      {day.winRate}%
                    </div>
                    <div style={{
                      fontSize: '12px',
                      color: '#666'
                    }}>
                      выигрышей
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Time Distribution */}
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '12px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
            }}>
              <h2 style={{
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#333',
                marginBottom: '25px'
              }}>
                Распределение ставок по времени
              </h2>
              
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(6, 1fr)',
                gap: '15px'
              }}>
                {[
                  { time: '00-04', percentage: 8, color: '#1e40af' },
                  { time: '04-08', percentage: 12, color: '#3b82f6' },
                  { time: '08-12', percentage: 22, color: '#60a5fa' },
                  { time: '12-16', percentage: 28, color: '#f59e0b' },
                  { time: '16-20', percentage: 35, color: '#ef4444' },
                  { time: '20-24', percentage: 42, color: '#6b0c17' }
                ].map((period, index) => (
                  <div key={index} style={{
                    textAlign: 'center'
                  }}>
                    <div style={{
                      height: `${period.percentage * 3}px`,
                      backgroundColor: period.color,
                      borderRadius: '8px 8px 0 0',
                      marginBottom: '10px',
                      transition: 'all 0.3s ease',
                      cursor: 'pointer'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.opacity = '0.8';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.opacity = '1';
                    }}
                    />
                    <div style={{
                      fontSize: '12px',
                      fontWeight: 'bold',
                      color: '#333',
                      marginBottom: '4px'
                    }}>
                      {period.time}
                    </div>
                    <div style={{
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: period.color
                    }}>
                      {period.percentage}%
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* All Sports Tab */}
        {activeTab === 'all' && (
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '12px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '20px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '25px'
            }}>
              Все виды спорта
            </h2>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(6, 1fr)',
              gap: '15px'
            }}>
              {allSportsData.map((sport, index) => (
                <div
                  key={index}
                  style={{
                    backgroundColor: '#f8f9fa',
                    border: '2px solid #e5e7eb',
                borderRadius: '12px',
                padding: '20px',
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                minHeight: '120px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                    alignItems: 'center'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#6b0c17';
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(107, 12, 23, 0.2)';
                    e.currentTarget.style.backgroundColor = 'white';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = '#e5e7eb';
                e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                    e.currentTarget.style.backgroundColor = '#f8f9fa';
              }}
            >
              <div style={{
                fontSize: '32px',
                    marginBottom: '10px'
              }}>
                {sport.icon}
              </div>
              <div style={{
                fontSize: '12px',
                fontWeight: 'bold',
                color: '#333',
                textAlign: 'center',
                    lineHeight: '1.2'
              }}>
                {sport.name}
              </div>
            </div>
          ))}
        </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Statistics; 