import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useBalance } from '../contexts/BalanceContext';

interface Bet {
  id: string;
  date: string;
  event: string;
  selection: string;
  odds: number;
  amount: number;
  potentialWin: number;
  status: 'pending';
  cashoutValue: number;
  sport: string;
  league: string;
}

const CashOutMobile: React.FC = () => {
  const { translate } = useLanguage();
  const { currentUser } = useAuth();
  const { formatBalance, addFunds } = useBalance();
  
  const [bets, setBets] = useState<Bet[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [sortBy, setSortBy] = useState<string>('date');
  
  // Mock data for bets available for cashout
  const mockBets: Bet[] = [
    {
      id: 'BET-123458',
      date: '2023-06-17T20:00:00',
      event: 'Lakers vs Bulls',
      selection: '1',
      odds: 1.6,
      amount: 2000,
      potentialWin: 3200,
      status: 'pending',
      cashoutValue: 1800,
      sport: 'Basketball',
      league: 'NBA'
    },
    {
      id: 'BET-123459',
      date: '2023-06-18T15:30:00',
      event: 'Djokovic vs Nadal',
      selection: '2',
      odds: 2.1,
      amount: 1500,
      potentialWin: 3150,
      status: 'pending',
      cashoutValue: 1200,
      sport: 'Tennis',
      league: 'Wimbledon'
    },
    {
      id: 'BET-123461',
      date: '2023-06-20T18:00:00',
      event: 'Man City vs Chelsea',
      selection: '1',
      odds: 1.9,
      amount: 2500,
      potentialWin: 4750,
      status: 'pending',
      cashoutValue: 2200,
      sport: 'Football',
      league: 'Premier League'
    },
  ];
  
  // Load bets on component mount
  useEffect(() => {
    const loadBets = async () => {
      setIsLoading(true);
      try {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        setBets(mockBets);
      } catch (error) {
        console.error('Error loading bets:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadBets();
  }, []);
  
  // Sort bets based on selected sort option
  useEffect(() => {
    const sortedBets = [...bets];
    
    if (sortBy === 'date') {
      sortedBets.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    } else if (sortBy === 'cashoutValue') {
      sortedBets.sort((a, b) => b.cashoutValue - a.cashoutValue);
    } else if (sortBy === 'potentialWin') {
      sortedBets.sort((a, b) => b.potentialWin - a.potentialWin);
    }
    
    setBets(sortedBets);
  }, [sortBy]);
  
  const handleCashout = async (betId: string, cashoutValue: number) => {
    // Simulate API call for cashout
    try {
      // Add funds to user's balance
      await addFunds(cashoutValue);
      
      // Remove the bet from the list
      const updatedBets = bets.filter(bet => bet.id !== betId);
      setBets(updatedBets);
      
      // Show success message
      alert(translate('cashoutSuccessful'));
    } catch (error) {
      console.error('Error processing cashout:', error);
      alert(translate('cashoutFailed'));
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getSelectionText = (selection: string) => {
    switch (selection) {
      case '1': return translate('homeWin');
      case '2': return translate('awayWin');
      case 'X': return translate('draw');
      default: return selection;
    }
  };
  
  return (
    <div style={{ padding: '15px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '15px', fontSize: '20px' }}>
        {translate('betsForCashOut')}
      </h1>
      
      <div style={{ marginBottom: '15px' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
          <span style={{ marginRight: '10px', fontSize: '14px' }}>{translate('sortBy')}:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            style={{
              flex: 1,
              padding: '8px 12px',
              backgroundColor: '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            <option value="date">{translate('date')}</option>
            <option value="cashoutValue">{translate('cashoutValue')}</option>
            <option value="potentialWin">{translate('potentialWin')}</option>
          </select>
        </div>
      </div>
      
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '30px' }}>
          <div style={{ fontSize: '16px' }}>{translate('loading')}...</div>
        </div>
      ) : bets.length === 0 ? (
        <div style={{ 
          backgroundColor: '#2c3e50', 
          padding: '15px', 
          borderRadius: '8px', 
          textAlign: 'center',
          marginTop: '15px'
        }}>
          <div style={{ fontSize: '16px', marginBottom: '8px' }}>{translate('noBetsForCashOut')}</div>
          <div style={{ color: '#7f8c8d', fontSize: '14px' }}>{translate('checkBackLater')}</div>
        </div>
      ) : (
        <div>
          {bets.map(bet => (
            <div 
              key={bet.id} 
              style={{
                backgroundColor: '#2c3e50',
                borderRadius: '8px',
                marginBottom: '12px',
                overflow: 'hidden'
              }}
            >
              <div style={{ 
                backgroundColor: '#34495e', 
                padding: '10px 15px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <div style={{ fontWeight: 'bold', fontSize: '14px' }}>{bet.event}</div>
                  <div style={{ color: '#bdc3c7', fontSize: '12px' }}>
                    {bet.sport} - {bet.league}
                  </div>
                </div>
                <div style={{ 
                  backgroundColor: '#f39c12',
                  color: 'white',
                  padding: '3px 8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}>
                  {translate('pending')}
                </div>
              </div>
              
              <div style={{ padding: '12px 15px' }}>
                <div style={{ 
                  display: 'grid', 
                  gridTemplateColumns: '1fr 1fr',
                  gap: '10px',
                  marginBottom: '10px',
                  fontSize: '13px'
                }}>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('betId')}
                    </div>
                    <div>{bet.id}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('date')}
                    </div>
                    <div>{formatDate(bet.date)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('selection')}
                    </div>
                    <div>{getSelectionText(bet.selection)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('odds')}
                    </div>
                    <div>{bet.odds.toFixed(2)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('betAmount')}
                    </div>
                    <div>{formatBalance(bet.amount)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('potentialWin')}
                    </div>
                    <div>{formatBalance(bet.potentialWin)}</div>
                  </div>
                </div>
                
                <div style={{ 
                  backgroundColor: '#34495e',
                  padding: '10px 12px',
                  borderRadius: '4px',
                  marginBottom: '12px'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: '12px', marginBottom: '2px' }}>{translate('currentCashoutValue')}</div>
                      <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#2ecc71' }}>
                        {formatBalance(bet.cashoutValue)}
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '12px', marginBottom: '2px' }}>{translate('profitLoss')}</div>
                      <div style={{ 
                        fontSize: '16px', 
                        fontWeight: 'bold', 
                        color: bet.cashoutValue >= bet.amount ? '#2ecc71' : '#e74c3c'
                      }}>
                        {bet.cashoutValue >= bet.amount ? '+' : ''}
                        {formatBalance(bet.cashoutValue - bet.amount)}
                      </div>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => handleCashout(bet.id, bet.cashoutValue)}
                  style={{
                    width: '100%',
                    padding: '10px',
                    backgroundColor: '#e74c3c',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontWeight: 'bold',
                    fontSize: '14px'
                  }}
                >
                  {translate('cashout')} {formatBalance(bet.cashoutValue)}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CashOutMobile;