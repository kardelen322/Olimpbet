import React, { useState } from 'react';
import { useNotifications } from '../contexts/NotificationContext';
import { useLanguage } from '../contexts/LanguageContext';

const Notifications: React.FC = () => {
  const { notifications, unreadCount, markAsRead, markAllAsRead, removeNotification } = useNotifications();
  const { translate } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const filteredNotifications = filter === 'all' 
    ? notifications 
    : notifications.filter(notification => !notification.read);

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '20px' }}>
        {translate('notifications')} 
        {unreadCount > 0 && (
          <span style={{ 
            backgroundColor: '#e74c3c', 
            color: 'white', 
            borderRadius: '50%', 
            padding: '2px 8px',
            fontSize: '14px',
            marginLeft: '10px'
          }}>
            {unreadCount}
          </span>
        )}
      </h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
        <div>
          <button 
            onClick={() => setFilter('all')}
            style={{
              padding: '8px 16px',
              backgroundColor: filter === 'all' ? '#2c3e50' : '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              marginRight: '10px',
              cursor: 'pointer'
            }}
          >
            {translate('all')}
          </button>
          <button 
            onClick={() => setFilter('unread')}
            style={{
              padding: '8px 16px',
              backgroundColor: filter === 'unread' ? '#2c3e50' : '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            {translate('unread')}
          </button>
        </div>
        {unreadCount > 0 && (
          <button 
            onClick={markAllAsRead}
            style={{
              padding: '8px 16px',
              backgroundColor: '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            {translate('markAllAsRead')}
          </button>
        )}
      </div>

      {filteredNotifications.length === 0 ? (
        <div style={{ 
          textAlign: 'center', 
          padding: '40px', 
          backgroundColor: '#2c3e50',
          borderRadius: '8px',
          color: '#ecf0f1'
        }}>
          <p>{translate('noNotifications')}</p>
        </div>
      ) : (
        <div>
          {filteredNotifications.map(notification => (
            <div 
              key={notification.id} 
              style={{
                padding: '15px',
                backgroundColor: notification.read ? '#2c3e50' : '#34495e',
                marginBottom: '10px',
                borderRadius: '8px',
                position: 'relative',
                cursor: notification.read ? 'default' : 'pointer',
                transition: 'background-color 0.3s'
              }}
              onClick={() => !notification.read && markAsRead(notification.id)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '12px', color: '#bdc3c7' }}>
                  {formatDate(notification.timestamp)}
                </span>
                {!notification.read && (
                  <span style={{ 
                    backgroundColor: '#e74c3c', 
                    color: 'white', 
                    borderRadius: '4px', 
                    padding: '2px 6px',
                    fontSize: '12px'
                  }}>
                    {translate('new')}
                  </span>
                )}
              </div>
              <p style={{ 
                margin: '10px 0',
                color: notification.message.toLowerCase().includes('approved') || notification.message.toLowerCase().includes('increased') ? '#27ae60' : 
                       notification.message.toLowerCase().includes('rejected') || notification.message.toLowerCase().includes('decreased') ? '#e74c3c' : 'inherit'
              }}>
                {notification.message}
              </p>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  removeNotification(notification.id);
                }}
                style={{
                  position: 'absolute',
                  right: '10px',
                  bottom: '10px',
                  backgroundColor: 'transparent',
                  border: 'none',
                  color: '#bdc3c7',
                  cursor: 'pointer',
                  fontSize: '12px',
                  textDecoration: 'underline'
                }}
              >
                {translate('delete')}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Notifications;