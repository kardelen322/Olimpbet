import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const Support: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('general');
  const [expandedQuestion, setExpandedQuestion] = useState<number | null>(null);

  const faqCategories = [
    {
      id: 'general',
      icon: '❓',
      title: 'Общие вопросы',
      questions: [
        {
          id: 1,
          question: 'Как зарегистрироваться на сайте?',
          answer: 'Для регистрации нажмите кнопку "Регистрация" в правом верхнем углу сайта. Заполните все обязательные поля: имя пользователя, электронную почту, номер телефона и пароль. После подтверждения электронной почты ваш аккаунт будет активирован.'
        },
        {
          id: 2,
          question: 'Как восстановить забытый пароль?',
          answer: 'Нажмите "Забыли пароль?" на странице входа. Введите адрес электронной почты, указанный при регистрации. Мы отправим вам ссылку для сброса пароля. Перейдите по ссылке и создайте новый пароль.'
        },
        {
          id: 3,
          question: 'Какие документы нужны для верификации?',
          answer: 'Для верификации аккаунта необходимы: паспорт или удостоверение личности, документ, подтверждающий адрес проживания (не старше 3 месяцев), и банковская карта (при необходимости). Все документы должны быть четкими и читаемыми.'
        },
        {
          id: 4,
          question: 'Как изменить личную информацию?',
          answer: 'Войдите в свой аккаунт и перейдите в раздел "Мой профиль". Здесь вы можете изменить контактную информацию, адрес и другие данные. Некоторые изменения могут потребовать дополнительной верификации.'
        }
      ]
    },
    {
      id: 'deposits',
      icon: '💰',
      title: 'Депозиты и выводы',
      questions: [
        {
          id: 5,
          question: 'Какие способы пополнения доступны?',
          answer: 'Мы принимаем: банковские карты (Visa, MasterCard, Мир), электронные кошельки (Qiwi, WebMoney, Яндекс.Деньги), банковские переводы, и cryptocurrency. Минимальная сумма пополнения - 100 рублей.'
        },
        {
          id: 6,
          question: 'Сколько времени занимает вывод средств?',
          answer: 'Время вывода зависит от способа: электронные кошельки - до 24 часов, банковские карты - 1-5 рабочих дней, банковские переводы - 3-7 рабочих дней. Первый вывод может занять больше времени из-за дополнительных проверок.'
        },
        {
          id: 7,
          question: 'Есть ли комиссия за вывод средств?',
          answer: 'Первые 5 выводов в месяц бесплатны. За последующие выводы взимается комиссия 2-5% в зависимости от способа вывода. Точная сумма комиссии указывается перед подтверждением операции.'
        },
        {
          id: 8,
          question: 'Почему мой депозит не зачислен?',
          answer: 'Обычно депозиты зачисляются мгновенно. Если средства не поступили в течение 30 минут, проверьте статус операции в банке и обратитесь в службу поддержки с деталями транзакции.'
        }
      ]
    },
    {
      id: 'betting',
      icon: '🎯',
      title: 'Ставки',
      questions: [
        {
          id: 9,
          question: 'Как сделать ставку?',
          answer: 'Выберите событие из линии или лайв-раздела, нажмите на коэффициент, введите сумму ставки в купоне и нажмите "Поставить". Ставка будет принята, если у вас достаточно средств на счету.'
        },
        {
          id: 10,
          question: 'Что такое экспресс-ставка?',
          answer: 'Экспресс - это ставка на несколько событий одновременно. Все выбранные события должны пройти для выигрыша. Коэффициенты перемножаются, что дает более высокий потенциальный выигрыш, но и больший риск.'
        },
        {
          id: 11,
          question: 'Можно ли отменить ставку?',
          answer: 'Принятые ставки нельзя отменить или изменить. Исключение составляют технические ошибки или отмена события организаторами. В таких случаях ставки возвращаются с коэффициентом 1.0.'
        },
        {
          id: 12,
          question: 'Что означают разные типы ставок?',
          answer: 'П1/П2 - победа первой/второй команды, Х - ничья, Тотал больше/меньше - количество голов/очков, Фора - ставка с учетом преимущества одной из команд, Обе забьют - обе команды забьют голы.'
        }
      ]
    },
    {
      id: 'technical',
      icon: '🔧',
      title: 'Технические вопросы',
      questions: [
        {
          id: 13,
          question: 'Сайт не загружается, что делать?',
          answer: 'Попробуйте: очистить кэш браузера, отключить VPN/прокси, проверить интернет-соединение, использовать другой браузер или зайти через мобильное приложение. Если проблема сохраняется, обратитесь в техподдержку.'
        },
        {
          id: 14,
          question: 'Как скачать мобильное приложение?',
          answer: 'Для Android: перейдите на сайт через мобильный браузер и нажмите "Скачать приложение". Для iOS: загрузите через App Store. Приложение бесплатное и содержит все функции веб-версии.'
        },
        {
          id: 15,
          question: 'Проблемы с входом в аккаунт',
          answer: 'Убедитесь в правильности логина и пароля, проверьте раскладку клавиатуры и Caps Lock. Если аккаунт заблокирован, обратитесь в службу поддержки. Используйте функцию восстановления пароля при необходимости.'
        },
        {
          id: 16,
          question: 'Как включить двухфакторную аутентификацию?',
          answer: 'В настройках аккаунта выберите "Безопасность" → "Двухфакторная аутентификация". Установите приложение Google Authenticator, отсканируйте QR-код и введите проверочный код. Сохраните резервные коды в безопасном месте.'
        }
      ]
    }
  ];

  const quickActions = [
    {
      icon: '💬',
      title: 'Онлайн чат',
      description: 'Получите мгновенную помощь от наших операторов',
      subtitle: 'Доступен 24/7',
      action: () => window.open('#', '_blank'),
      color: '#22c55e'
    },
    {
      icon: '📧',
      title: 'Написать письмо',
      description: 'Отправьте детальное описание вашей проблемы',
      subtitle: 'support@olimpbet.kz',
      action: () => window.open('mailto:support@olimpbet.kz', '_blank'),
      color: '#3b82f6'
    },
    {
      icon: '📞',
      title: 'Горячая линия',
      description: 'Свяжитесь с нами по телефону',
      subtitle: '+7 (727) 000-00-00',
      action: () => window.open('tel:+77270000000', '_blank'),
      color: '#f59e0b'
    },
    {
      icon: '📋',
      title: 'Правила и условия',
      description: 'Ознакомьтесь с полными правилами сайта',
      subtitle: 'Актуальная версия',
      action: () => window.open('/terms', '_blank'),
      color: '#6b0c17'
    }
  ];

  const helpTopics = [
    {
      icon: '🎮',
      title: 'Начало работы',
      description: 'Пошаговое руководство для новых пользователей',
      items: ['Регистрация', 'Верификация', 'Первая ставка', 'Пополнение счета']
    },
    {
      icon: '🔐',
      title: 'Безопасность',
      description: 'Защита аккаунта и персональных данных',
      items: ['Двухфакторная аутентификация', 'Безопасные пароли', 'Фишинг', 'Подозрительная активность']
    },
    {
      icon: '🏆',
      title: 'Бонусы и акции',
      description: 'Как получить и использовать бонусы',
      items: ['Приветственный бонус', 'Кэшбек', 'Фрибеты', 'VIP программа']
    },
    {
      icon: '📱',
      title: 'Мобильная версия',
      description: 'Использование сайта на мобильных устройствах',
      items: ['Скачать приложение', 'Мобильная версия', 'Push-уведомления', 'Ставки на ходу']
    }
  ];

  return (
    <div style={{ 
      display: 'flex', 
      margin: '0 auto', 
      padding: '20px 20px 20px 10px',
      gap: '20px',
      backgroundColor: '#f5f5f5',
      minHeight: '100vh',
      fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      
      <Sidebar />
      
      <div style={{ flex: 1, maxWidth: '1200px' }}>
        
        {/* Page Header */}
        <div style={{ 
          backgroundColor: 'white', 
          borderRadius: '12px', 
          padding: '40px', 
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: 20, 
            justifyContent: 'center',
            marginBottom: 20
          }}>
            <div style={{ 
              width: 60, 
              height: 60, 
              backgroundColor: '#6b0c17', 
              borderRadius: '50%', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center'
            }}>
              <span style={{ fontSize: 28, color: 'white' }}>🎧</span>
            </div>
            <h1 style={{ 
              color: '#6b0c17', 
              fontSize: 36, 
              fontWeight: 'bold', 
              margin: 0
            }}>
              Центр поддержки
            </h1>
          </div>
          <p style={{ 
            color: '#666', 
            fontSize: 18, 
            margin: 0,
            lineHeight: 1.6
          }}>
            Найдите ответы на часто задаваемые вопросы или свяжитесь с нашей службой поддержки
          </p>
          </div>

        {/* Quick Actions */}
          <div style={{ 
            display: 'grid', 
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '20px',
          marginBottom: '30px'
        }}>
          {quickActions.map((action, index) => (
            <div
              key={index}
              onClick={action.action}
              style={{
                backgroundColor: 'white',
                borderRadius: '12px',
                padding: '25px',
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                border: `2px solid ${action.color}20`,
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-5px)';
                e.currentTarget.style.boxShadow = `0 8px 25px ${action.color}30`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
              }}
            >
              <div style={{
                fontSize: '36px',
                marginBottom: '15px'
              }}>
                {action.icon}
              </div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: action.color,
                marginBottom: '10px',
                margin: '0 0 10px 0'
              }}>
                {action.title}
              </h3>
                <p style={{ 
                fontSize: '14px',
                color: '#666',
                marginBottom: '8px',
                lineHeight: 1.4
              }}>
                {action.description}
              </p>
              <div style={{
                fontSize: '12px',
                color: action.color,
                fontWeight: 'bold'
              }}>
                {action.subtitle}
              </div>
            </div>
          ))}
        </div>

        {/* Help Topics */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '30px',
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '25px',
            textAlign: 'center'
          }}>
            Популярные разделы помощи
          </h2>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '20px'
          }}>
            {helpTopics.map((topic, index) => (
              <div
                key={index}
                style={{
                  border: '1px solid #e5e7eb',
                  borderRadius: '10px',
                  padding: '20px',
                  transition: 'all 0.3s ease',
                  cursor: 'pointer'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = '#6b0c17';
                  e.currentTarget.style.backgroundColor = '#fef7f7';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = '#e5e7eb';
                  e.currentTarget.style.backgroundColor = 'white';
                }}
              >
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  marginBottom: '15px'
                }}>
                  <div style={{
                    fontSize: '24px',
                    marginRight: '12px'
                  }}>
                    {topic.icon}
                  </div>
                  <h3 style={{
                    fontSize: '18px',
                    fontWeight: 'bold',
                  color: '#333', 
                    margin: 0
                  }}>
                    {topic.title}
                  </h3>
                </div>
                <p style={{
                  fontSize: '14px',
                  color: '#666',
                  marginBottom: '15px',
                  lineHeight: 1.5
                }}>
                  {topic.description}
                </p>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '8px'
                }}>
                  {topic.items.map((item, itemIndex) => (
                    <span
                      key={itemIndex}
                      style={{
                        backgroundColor: '#f3f4f6',
                        color: '#6b0c17',
                        padding: '4px 10px',
                        borderRadius: '12px',
                        fontSize: '12px',
                        fontWeight: '500'
                      }}
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <div style={{ 
          backgroundColor: 'white', 
          borderRadius: '12px', 
          padding: '30px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '25px',
                textAlign: 'center'
              }}>
            {translate('frequentlyAskedQuestions')}
          </h2>

          {/* Category Tabs */}
          <div style={{
            display: 'flex',
            marginBottom: '30px',
            backgroundColor: '#f8f9fa',
            borderRadius: '10px',
            padding: '5px'
          }}>
            {faqCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                style={{
                  flex: 1,
                  padding: '12px 16px',
                  border: 'none',
                  borderRadius: '8px',
                  backgroundColor: activeCategory === category.id ? 'white' : 'transparent',
                  color: activeCategory === category.id ? '#6b0c17' : '#666',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                  boxShadow: activeCategory === category.id ? '0 2px 4px rgba(0,0,0,0.1)' : 'none'
                }}
              >
                <span style={{ fontSize: '16px' }}>{category.icon}</span>
                {category.title}
              </button>
            ))}
          </div>

          {/* FAQ Questions */}
          <div>
            {faqCategories
              .find(cat => cat.id === activeCategory)
              ?.questions.map((faq) => (
                <div
                  key={faq.id}
                  style={{
                    border: '1px solid #e5e7eb',
                    borderRadius: '10px',
                    marginBottom: '15px',
                    overflow: 'hidden',
                    transition: 'all 0.3s ease'
                  }}
                >
                  <div
                    onClick={() => setExpandedQuestion(expandedQuestion === faq.id ? null : faq.id)}
                    style={{
                      padding: '20px',
                      backgroundColor: expandedQuestion === faq.id ? '#f8f9fa' : 'white',
                      cursor: 'pointer',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      borderBottom: expandedQuestion === faq.id ? '1px solid #e5e7eb' : 'none'
                    }}
                  >
                    <h3 style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#333',
                      margin: 0,
                      flex: 1
                    }}>
                      {faq.question}
                    </h3>
                    <div style={{
                      fontSize: '14px',
                      color: '#6b0c17',
                      transform: expandedQuestion === faq.id ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}>
                      ▼
                    </div>
                  </div>
                  
                  {expandedQuestion === faq.id && (
                    <div style={{
                      padding: '20px',
                      backgroundColor: 'white',
                      borderTop: '1px solid #f1f5f9'
                    }}>
                      <p style={{
                        fontSize: '14px',
                        color: '#555',
                        lineHeight: 1.6,
                        margin: 0
                      }}>
                        {faq.answer}
                      </p>
                    </div>
                  )}
                </div>
              ))}
          </div>

          {/* Contact Footer */}
          <div style={{
            marginTop: '40px',
            padding: '25px',
            backgroundColor: '#f8f9fa',
            borderRadius: '10px',
            textAlign: 'center'
          }}>
            <h3 style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '10px'
            }}>
              Не нашли ответ на свой вопрос?
            </h3>
            <p style={{
              fontSize: '14px',
              color: '#666',
              marginBottom: '20px'
            }}>
              Наша служба поддержки работает 24/7 и всегда готова помочь
            </p>
            <button
              onClick={() => window.open('#', '_blank')}
              style={{
                backgroundColor: '#6b0c17',
                color: 'white',
                border: 'none',
                padding: '12px 30px',
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: 'bold',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#7f1d1d';
                  e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#6b0c17';
                  e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              Связаться с поддержкой
                </button>
              </div>
        </div>
      </div>
    </div>
  );
};

export default Support; 