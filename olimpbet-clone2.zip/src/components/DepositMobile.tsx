import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useBalance } from '../contexts/BalanceContext';
import { usePayment } from '../contexts/PaymentContext';
import { useAuth } from '../contexts/AuthContext';

const DepositMobile: React.FC = () => {
  const { translate } = useLanguage();
  const { balance, formatBalance, refreshBalance } = useBalance();
  const { paymentLink, addDepositRequest } = usePayment();
  const { currentUser } = useAuth();
  
  const [amount, setAmount] = useState<string>('1000');
  const [paymentMethod, setPaymentMethod] = useState<string>('kaspi');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [showSuccess, setShowSuccess] = useState<boolean>(false);
  const [transactionId, setTransactionId] = useState<string>('');
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) {
      setAmount(value);
    }
  };
  
  const handleQuickAmounts = (amount: number) => {
    setAmount(amount.toString());
  };
  
  const handlePaymentMethodChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setPaymentMethod(e.target.value);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || parseInt(amount) < 100) {
      alert(translate('minimumDepositAmount'));
      return;
    }
    
    if (!currentUser) {
      alert(translate('pleaseLogin'));
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Create a deposit request
      const request = await addDepositRequest({
        userId: currentUser.phone,
        username: currentUser.username || currentUser.phone,
        amount: parseInt(amount),
        paymentMethod: paymentMethod
      });
      
      // Generate a transaction ID from the request ID
      setTransactionId(request.id);
      
      // Show success message
      setShowSuccess(true);
      
      // Refresh balance after successful deposit request
      refreshBalance();
    } catch (error) {
      console.error('Error creating deposit request:', error);
      alert(translate('depositRequestFailed'));
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleNewDeposit = () => {
    setShowSuccess(false);
    setAmount('1000');
    setPaymentMethod('kaspi');
    refreshBalance(); // Refresh balance when starting a new deposit
  };
  
  // Refresh balance when component mounts
  useEffect(() => {
    refreshBalance();
  }, [refreshBalance]);
  
  return (
    <div style={{ padding: '15px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '15px', fontSize: '20px' }}>
        {translate('deposit')}
      </h1>
      
      {!showSuccess ? (
        <div>
          <div style={{ 
            backgroundColor: '#2c3e50', 
            padding: '15px', 
            borderRadius: '8px',
            marginBottom: '15px'
          }}>
            <div style={{ fontSize: '14px' }}>
              {translate('currentBalance')}: <span style={{ fontWeight: 'bold' }}>{formatBalance(balance)}</span>
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div style={{ backgroundColor: '#2c3e50', padding: '15px', borderRadius: '8px' }}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
                  {translate('selectPaymentMethod')}
                </label>
                <select
                  value={paymentMethod}
                  onChange={handlePaymentMethodChange}
                  style={{
                    width: '100%',
                    padding: '10px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white',
                    fontSize: '14px'
                  }}
                >
                  <option value="kaspi">{translate('kaspi')}</option>
                  <option value="visa">{translate('visa')}</option>
                  <option value="mastercard">{translate('mastercard')}</option>
                  <option value="qiwi">{translate('qiwi')}</option>
                </select>
              </div>
              
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
                  {translate('enterAmount')}
                </label>
                <input
                  type="text"
                  value={amount}
                  onChange={handleAmountChange}
                  style={{
                    width: '100%',
                    padding: '10px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white',
                    fontSize: '14px'
                  }}
                  placeholder={translate('enterAmount')}
                />
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginTop: '8px' }}>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(1000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    1,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(5000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    5,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(10000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    10,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(50000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    50,000
                  </button>
                </div>
              </div>
              
              {paymentMethod === 'kaspi' && (
                <div style={{ marginBottom: '15px' }}>
                  <div style={{ 
                    backgroundColor: '#34495e', 
                    padding: '12px', 
                    borderRadius: '4px',
                    marginBottom: '12px',
                    fontSize: '14px'
                  }}>
                    <div style={{ marginBottom: '8px', fontWeight: 'bold' }}>
                      {translate('kaspiTransferInstructions')}
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      {translate('transferToPhoneNumber')}: <span style={{ fontWeight: 'bold' }}>+7 777 123 4567</span>
                    </div>
                    <div>
                      {translate('includeYourUsernameInComment')}: <span style={{ fontWeight: 'bold' }}>@{localStorage.getItem('username') || 'username'}</span>
                    </div>
                  </div>
                  
                  <div style={{ 
                    backgroundColor: '#34495e', 
                    padding: '12px', 
                    borderRadius: '4px',
                    marginBottom: '12px'
                  }}>
                    <div style={{ marginBottom: '8px', fontWeight: 'bold', fontSize: '14px' }}>
                      {translate('kaspiQR')}
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <a href={paymentLink} target="_blank" rel="noopener noreferrer">
                        <div style={{ 
                          width: '150px', 
                          height: '150px', 
                          backgroundColor: '#fff', 
                          margin: '0 auto',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '14px',
                          color: '#000',
                          fontWeight: 'bold'
                        }}>
                          Kaspi QR Code
                        </div>
                      </a>
                      <div style={{ marginTop: '8px', fontSize: '12px' }}>
                        {translate('scanQRWithKaspiApp')}
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {paymentMethod !== 'kaspi' && (
                <div style={{ marginBottom: '15px' }}>
                  <div style={{ 
                    backgroundColor: '#34495e', 
                    padding: '12px', 
                    borderRadius: '4px',
                    marginBottom: '12px',
                    fontSize: '14px'
                  }}>
                    <div style={{ marginBottom: '8px', fontWeight: 'bold' }}>
                      {translate('cardPaymentInstructions')}
                    </div>
                    <div>
                      {translate('youWillBeRedirectedToPaymentProcessor')}
                    </div>
                  </div>
                </div>
              )}
              
              <button
                type="submit"
                disabled={isProcessing}
                style={{
                  width: '100%',
                  padding: '12px',
                  backgroundColor: isProcessing ? '#7f8c8d' : '#27ae60',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: isProcessing ? 'not-allowed' : 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}
              >
                {isProcessing ? translate('processing') : translate('confirmDeposit')}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div style={{ backgroundColor: '#2c3e50', padding: '15px', borderRadius: '8px', textAlign: 'center' }}>
          <div style={{ 
            backgroundColor: '#f39c12', 
            color: 'white', 
            width: '60px', 
            height: '60px', 
            borderRadius: '50%', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            margin: '0 auto 15px',
            fontSize: '30px'
          }}>
            ⏱
          </div>
          
          <h2 style={{ marginBottom: '15px', fontSize: '18px' }}>{translate('depositRequestSubmitted')}</h2>
          <p style={{ marginBottom: '15px', fontSize: '14px' }}>{translate('depositPendingApproval')}</p>

          
          <div style={{ 
            backgroundColor: '#34495e', 
            padding: '12px', 
            borderRadius: '4px', 
            marginBottom: '15px',
            textAlign: 'left',
            fontSize: '14px'
          }}>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('transactionId')}:</span>
              <span>{transactionId}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('amount')}:</span>
              <span>{formatBalance(parseInt(amount))}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('paymentMethod')}:</span>
              <span>{translate(paymentMethod)}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('date')}:</span>
              <span>{new Date().toLocaleString()}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
              <span>{translate('newBalance')}:</span>
              <span>{formatBalance(balance)}</span>
            </div>
          </div>
          
          <button
            onClick={handleNewDeposit}
            style={{
              width: '100%',
              padding: '12px',
              backgroundColor: '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: 'bold'
            }}
          >
            {translate('makeAnotherDeposit')}
          </button>
        </div>
      )}
    </div>
  );
};

export default DepositMobile;