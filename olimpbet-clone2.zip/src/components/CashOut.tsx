import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useBalance } from '../contexts/BalanceContext';

interface Bet {
  id: string;
  date: string;
  event: string;
  selection: string;
  odds: number;
  amount: number;
  potentialWin: number;
  status: 'pending';
  cashoutValue: number;
  sport: string;
  league: string;
}

const CashOut: React.FC = () => {
  const { translate } = useLanguage();
  const { currentUser } = useAuth();
  const { formatBalance, addFunds } = useBalance();
  
  const [bets, setBets] = useState<Bet[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [sortBy, setSortBy] = useState<string>('date');
  
  // Mock data for bets available for cashout
  const mockBets: Bet[] = [
    {
      id: 'BET-123458',
      date: '2023-06-17T20:00:00',
      event: 'LA Lakers vs Chicago Bulls',
      selection: '1',
      odds: 1.6,
      amount: 2000,
      potentialWin: 3200,
      status: 'pending',
      cashoutValue: 1800,
      sport: 'Basketball',
      league: 'NBA'
    },
    {
      id: 'BET-123459',
      date: '2023-06-18T15:30:00',
      event: 'Djokovic vs Nadal',
      selection: '2',
      odds: 2.1,
      amount: 1500,
      potentialWin: 3150,
      status: 'pending',
      cashoutValue: 1200,
      sport: 'Tennis',
      league: 'Wimbledon'
    },
    {
      id: 'BET-123461',
      date: '2023-06-20T18:00:00',
      event: 'Manchester City vs Chelsea',
      selection: '1',
      odds: 1.9,
      amount: 2500,
      potentialWin: 4750,
      status: 'pending',
      cashoutValue: 2200,
      sport: 'Football',
      league: 'Premier League'
    },
  ];
  
  // Load bets on component mount
  useEffect(() => {
    const loadBets = async () => {
      setIsLoading(true);
      try {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        setBets(mockBets);
      } catch (error) {
        console.error('Error loading bets:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadBets();
  }, []);
  
  // Sort bets based on selected sort option
  useEffect(() => {
    const sortedBets = [...bets];
    
    if (sortBy === 'date') {
      sortedBets.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    } else if (sortBy === 'cashoutValue') {
      sortedBets.sort((a, b) => b.cashoutValue - a.cashoutValue);
    } else if (sortBy === 'potentialWin') {
      sortedBets.sort((a, b) => b.potentialWin - a.potentialWin);
    }
    
    setBets(sortedBets);
  }, [sortBy]);
  
  const handleCashout = async (betId: string, cashoutValue: number) => {
    // Simulate API call for cashout
    try {
      // Add funds to user's balance
      await addFunds(cashoutValue);
      
      // Remove the bet from the list
      const updatedBets = bets.filter(bet => bet.id !== betId);
      setBets(updatedBets);
      
      // Show success message
      alert(translate('cashoutSuccessful'));
    } catch (error) {
      console.error('Error processing cashout:', error);
      alert(translate('cashoutFailed'));
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getSelectionText = (selection: string) => {
    switch (selection) {
      case '1': return translate('homeWin');
      case '2': return translate('awayWin');
      case 'X': return translate('draw');
      default: return selection;
    }
  };
  
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '20px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '20px' }}>
        {translate('betsForCashOut')}
      </h1>
      
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <span style={{ marginRight: '10px' }}>{translate('sortBy')}:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            style={{
              padding: '8px 16px',
              backgroundColor: '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            <option value="date">{translate('date')}</option>
            <option value="cashoutValue">{translate('cashoutValue')}</option>
            <option value="potentialWin">{translate('potentialWin')}</option>
          </select>
        </div>
      </div>
      
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '40px' }}>
          <div style={{ fontSize: '20px' }}>{translate('loading')}...</div>
        </div>
      ) : bets.length === 0 ? (
        <div style={{ 
          backgroundColor: '#2c3e50', 
          padding: '20px', 
          borderRadius: '8px', 
          textAlign: 'center',
          marginTop: '20px'
        }}>
          <div style={{ fontSize: '18px', marginBottom: '10px' }}>{translate('noBetsForCashOut')}</div>
          <div style={{ color: '#7f8c8d' }}>{translate('checkBackLater')}</div>
        </div>
      ) : (
        <div>
          {bets.map(bet => (
            <div 
              key={bet.id} 
              style={{
                backgroundColor: '#2c3e50',
                borderRadius: '8px',
                marginBottom: '15px',
                overflow: 'hidden'
              }}
            >
              <div style={{ 
                backgroundColor: '#34495e', 
                padding: '12px 20px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <div style={{ fontWeight: 'bold' }}>{bet.event}</div>
                  <div style={{ color: '#bdc3c7', fontSize: '14px' }}>
                    {bet.sport} - {bet.league}
                  </div>
                </div>
                <div style={{ 
                  backgroundColor: '#f39c12',
                  color: 'white',
                  padding: '4px 10px',
                  borderRadius: '4px',
                  fontSize: '14px',
                  fontWeight: 'bold'
                }}>
                  {translate('pending')}
                </div>
              </div>
              
              <div style={{ padding: '15px 20px' }}>
                <div style={{ 
                  display: 'grid', 
                  gridTemplateColumns: '1fr 1fr 1fr',
                  gap: '15px',
                  marginBottom: '15px'
                }}>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '5px', fontSize: '14px' }}>
                      {translate('betId')}
                    </div>
                    <div>{bet.id}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '5px', fontSize: '14px' }}>
                      {translate('date')}
                    </div>
                    <div>{formatDate(bet.date)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '5px', fontSize: '14px' }}>
                      {translate('selection')}
                    </div>
                    <div>{getSelectionText(bet.selection)}</div>
                  </div>
                </div>
                
                <div style={{ 
                  display: 'grid', 
                  gridTemplateColumns: '1fr 1fr 1fr',
                  gap: '15px',
                  marginBottom: '20px'
                }}>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '5px', fontSize: '14px' }}>
                      {translate('odds')}
                    </div>
                    <div>{bet.odds.toFixed(2)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '5px', fontSize: '14px' }}>
                      {translate('betAmount')}
                    </div>
                    <div>{formatBalance(bet.amount)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '5px', fontSize: '14px' }}>
                      {translate('potentialWin')}
                    </div>
                    <div>{formatBalance(bet.potentialWin)}</div>
                  </div>
                </div>
                
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  backgroundColor: '#34495e',
                  padding: '12px 15px',
                  borderRadius: '4px',
                  marginBottom: '15px'
                }}>
                  <div>
                    <div style={{ fontSize: '14px', marginBottom: '3px' }}>{translate('currentCashoutValue')}</div>
                    <div style={{ fontSize: '18px', fontWeight: 'bold', color: '#2ecc71' }}>
                      {formatBalance(bet.cashoutValue)}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '14px', marginBottom: '3px' }}>{translate('profitLoss')}</div>
                    <div style={{ 
                      fontSize: '18px', 
                      fontWeight: 'bold', 
                      color: bet.cashoutValue >= bet.amount ? '#2ecc71' : '#e74c3c'
                    }}>
                      {bet.cashoutValue >= bet.amount ? '+' : ''}
                      {formatBalance(bet.cashoutValue - bet.amount)}
                    </div>
                  </div>
                </div>
                
                <div style={{ textAlign: 'right' }}>
                  <button
                    onClick={() => handleCashout(bet.id, bet.cashoutValue)}
                    style={{
                      padding: '10px 20px',
                      backgroundColor: '#e74c3c',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                      fontSize: '16px'
                    }}
                  >
                    {translate('cashout')} {formatBalance(bet.cashoutValue)}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CashOut;