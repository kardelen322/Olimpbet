import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { usePayment } from '../contexts/PaymentContext';
import { useBalance } from '../contexts/BalanceContext';
import { useNotifications } from '../contexts/NotificationContext';
import { addNotification as addNotificationToUser } from '../database/notification-adapter';
import { useNavigate } from 'react-router-dom';
import { getAllUsers, getAllFailedLoginAttempts, addToBlacklist, removeFromBlacklist, getAllBlacklistedUsers } from '../database';
import * as balanceAdapter from '../database/balance-adapter';
import { useWithdrawal } from '../contexts/WithdrawalContext';

interface User {
  id?: number;
  phone: string;
  username?: string;
  created_at?: string;
}

const Admin: React.FC = () => {
  const { translate, currentLanguage, setLanguage } = useLanguage();
  const { paymentLink, updatePaymentLink, depositRequests, approveDepositRequest, rejectDepositRequest } = usePayment();
  const { withdrawalRequests, approveWithdrawalRequest, rejectWithdrawalRequest, fetchWithdrawalRequests } = useWithdrawal();
  const { refreshBalance } = useBalance();
  const { currentUser } = useAuth();
  const { addNotification } = useNotifications();
  const navigate = useNavigate();
  
  // Payment management state
  const [newPaymentLink, setNewPaymentLink] = useState('');
  const [showPaymentLinkForm, setShowPaymentLinkForm] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [failedAttempts, setFailedAttempts] = useState<any[]>([]);
  const [blacklistedUsers, setBlacklistedUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'attempts' | 'blacklist' | 'payments' | 'deposit-requests' | 'balance-management' | 'withdrawal-requests' | 'analytics' | 'settings'>('overview');
  const [adminPassword, setAdminPassword] = useState<string>('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState<boolean>(false);
  const sessionTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastActivityRef = useRef<number>(Date.now());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  
  // Blacklist management state
  const [showAddBlacklistForm, setShowAddBlacklistForm] = useState(false);
  const [blacklistIdentifier, setBlacklistIdentifier] = useState('');
  const [blacklistReason, setBlacklistReason] = useState('');
  const [showRemoveBlacklistConfirm, setShowRemoveBlacklistConfirm] = useState<number | null>(null);
  
  // Admin login state
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [adminEmail, setAdminEmail] = useState<string>('');
  const [adminLoginPassword, setAdminLoginPassword] = useState<string>('');
  const [adminLoginError, setAdminLoginError] = useState<string>('');
  
  // Balance management state
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [balanceAmount, setBalanceAmount] = useState<string>('');
  const [balanceReason, setBalanceReason] = useState<string>('');
  const [showBalanceForm, setShowBalanceForm] = useState<boolean>(false);
  
  // Remove balance state
  const [removeUserId, setRemoveUserId] = useState<string>('');
  const [removeAmount, setRemoveAmount] = useState<string>('');
  const [removeReason, setRemoveReason] = useState<string>('');
  
  // Manual withdrawal processing state
  const [manualWithdrawalUserId, setManualWithdrawalUserId] = useState<string>('');
  const [manualWithdrawalAmount, setManualWithdrawalAmount] = useState<string>('');
  const [manualWithdrawalMethod, setManualWithdrawalMethod] = useState<string>('');

  
  // Admin credentials (hardcoded for security)
  const ADMIN_EMAIL = 'admin@olimpbet.com';
  const ADMIN_PASSWORD = 'admin7001';

  // Session timeout management
  const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes

  const handleActivity = useCallback(() => {
    lastActivityRef.current = Date.now();
    if (sessionTimeoutRef.current) {
      clearTimeout(sessionTimeoutRef.current);
    }
    sessionTimeoutRef.current = setTimeout(() => {
      handleAdminLogout();
    }, SESSION_TIMEOUT);
  }, []);

  useEffect(() => {
    if (isAdminLoggedIn) {
      handleActivity();
      const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
      activityEvents.forEach(event => {
        document.addEventListener(event, handleActivity, true);
      });
      return () => {
        activityEvents.forEach(event => {
          document.removeEventListener(event, handleActivity, true);
        });
        if (sessionTimeoutRef.current) {
          clearTimeout(sessionTimeoutRef.current);
        }
      };
    }
  }, [isAdminLoggedIn, handleActivity]);

  // Restore admin session from localStorage on component mount
  useEffect(() => {
    const savedAdminAuth = localStorage.getItem('olimpbet_admin_authenticated');
    const savedAdminEmail = localStorage.getItem('olimpbet_admin_email');
    
    if (savedAdminAuth === 'true' && savedAdminEmail) {
      setIsAdminLoggedIn(true);
      setAdminEmail(savedAdminEmail);
      console.log('Admin session restored from localStorage');
    }
  }, []);

  useEffect(() => {
    console.log('Admin component mounted, isAdminLoggedIn:', isAdminLoggedIn);
    if (isAdminLoggedIn) {
      console.log('Admin is logged in, fetching data...');
      fetchData();
    }
  }, [isAdminLoggedIn]);

  const fetchData = async () => {
    try {
      setLoading(true);
      console.log('Fetching data for admin dashboard...');
      
      // Fetch users and attempts first
      const [usersData, attemptsData] = await Promise.all([
        getAllUsers(),
        getAllFailedLoginAttempts()
      ]);
      console.log('Users data received:', usersData);
      console.log('Attempts data received:', attemptsData);
      
      // Set the data we have so far
      setUsers(usersData);
      setFailedAttempts(attemptsData);
      
      // Try to fetch blacklist data separately to handle potential errors
      try {
        const blacklistData = await getAllBlacklistedUsers();
        console.log('Blacklist data received:', blacklistData);
        setBlacklistedUsers(blacklistData);
      } catch (blacklistErr: any) {
        console.error('Failed to fetch blacklist data:', blacklistErr);
        // Set empty blacklist if table doesn't exist
        setBlacklistedUsers([]);
        // Set a specific error message for the blacklist table issue
        if (blacklistErr?.message?.includes('blacklist') || 
            blacklistErr?.message?.includes('relation') || 
            blacklistErr?.toString().includes('blacklist')) {
          setError('Failed to get blacklisted users: relation "public.blacklist" does not exist');
        }
        console.warn('Blacklist functionality may not be available. Please run the SQL setup in your Supabase dashboard.');
      }
      
      // Try to fetch withdrawal requests
      try {
        await fetchWithdrawalRequests();
      } catch (withdrawalErr) {
        console.error('Failed to fetch withdrawal requests:', withdrawalErr);
      }
      
      setError(null);
    } catch (err) {
      console.error('Failed to fetch data:', err);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (adminEmail === ADMIN_EMAIL && adminLoginPassword === ADMIN_PASSWORD) {
      setIsAdminLoggedIn(true);
      setAdminLoginError('');
      
      // Save admin session to localStorage
      localStorage.setItem('olimpbet_admin_authenticated', 'true');
      localStorage.setItem('olimpbet_admin_email', adminEmail);
      
      handleActivity();
    } else {
      setAdminLoginError('Invalid credentials');
    }
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setAdminEmail('');
    setAdminLoginPassword('');
    setAdminLoginError('');
    
    // Clear admin session from localStorage
    localStorage.removeItem('olimpbet_admin_authenticated');
    localStorage.removeItem('olimpbet_admin_email');
    
    if (sessionTimeoutRef.current) {
      clearTimeout(sessionTimeoutRef.current);
    }
    navigate('/');
  };

  const verifyAdminPassword = async (password: string): Promise<boolean> => {
    return password === ADMIN_PASSWORD;
  };

  // Blacklist management functions
  const handleAddToBlacklist = async () => {
    if (!blacklistIdentifier.trim()) {
      setError('Please enter a phone number or username');
      return;
    }

    try {
      await addToBlacklist(blacklistIdentifier.trim());
      setBlacklistIdentifier('');
      setBlacklistReason('');
      setShowAddBlacklistForm(false);
      await fetchData(); // Refresh data
    } catch (err) {
      console.error('Failed to add to blacklist:', err);
      setError('Failed to add user to blacklist');
    }
  };

  const handleRemoveFromBlacklist = async (entry: any) => {
    try {
      const identifier = entry.phone || entry.username;
      await removeFromBlacklist(identifier);
      setShowRemoveBlacklistConfirm(null);
      await fetchData(); // Refresh data
    } catch (err) {
      console.error('Failed to remove from blacklist:', err);
      setError('Failed to remove user from blacklist');
    }
  };

  // Balance management functions
  const handleAddBalance = async () => {
    if (!selectedUserId || !balanceAmount || !balanceReason) {
      setError('Please fill in all fields');
      return;
    }

    const amount = parseFloat(balanceAmount);
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid positive amount');
      return;
    }

    try {
      const success = await balanceAdapter.addBalanceToUser(selectedUserId, amount, balanceReason);
      if (success) {
        // If the current user is the one receiving the balance, refresh their balance
        if (currentUser && currentUser.phone === selectedUserId) {
          await refreshBalance();
        }
        
        // Add notification for the user
        await addNotificationToUser(selectedUserId, `Ваш баланс увеличен на ${amount} KZT. Причина: ${balanceReason}`);
        
        setSelectedUserId('');
        setBalanceAmount('');
        setBalanceReason('');
        setShowBalanceForm(false);
        setError(null);
        alert(`Successfully added ${amount} to user ${selectedUserId}`);
      } else {
        setError('Failed to add balance to user');
      }
    } catch (err) {
      console.error('Error adding balance:', err);
      setError('Failed to add balance to user');
    }
  };

  // Handle remove balance
  const handleRemoveBalance = async () => {
    if (!removeUserId || !removeAmount || !removeReason) {
      setError('Please fill in all fields');
      return;
    }

    const amount = parseFloat(removeAmount);
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid positive amount');
      return;
    }

    try {
      const success = await balanceAdapter.removeBalanceFromUser(removeUserId, amount, removeReason);
      if (success) {
        // If the current user is the one losing balance, refresh their balance
        if (currentUser && currentUser.phone === removeUserId) {
          await refreshBalance();
        }
        
        // Add notification for the user
        await addNotificationToUser(removeUserId, `Ваш баланс уменьшен на ${amount} KZT. Причина: ${removeReason}`);
        
        setRemoveUserId('');
        setRemoveAmount('');
        setRemoveReason('');
        setError(null);
        alert(`Successfully removed ${amount} from user ${removeUserId}`);
      } else {
        setError('Failed to remove balance from user. Check if user exists and has sufficient balance.');
      }
    } catch (err) {
      console.error('Error removing balance:', err);
      setError('Failed to remove balance from user');
    }
  };

  // Manual withdrawal processing
  const handleManualWithdrawal = async () => {
    if (!manualWithdrawalUserId || !manualWithdrawalAmount || !manualWithdrawalMethod) {
      setError('Please fill in all fields');
      return;
    }

    const amount = parseFloat(manualWithdrawalAmount);
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid positive amount');
      return;
    }

    try {
      // First remove balance from user
      const success = await balanceAdapter.removeBalanceFromUser(manualWithdrawalUserId, amount, 'Manual withdrawal processing');
      
      if (success) {
        // If the current user is the one withdrawing, refresh their balance
        if (currentUser && currentUser.phone === manualWithdrawalUserId) {
          await refreshBalance();
        }
        
        // Add notification for the user
        await addNotificationToUser(manualWithdrawalUserId, `Ваш запрос на вывод ${amount} KZT через ${manualWithdrawalMethod} обработан успешно.`);
        
        // Reset form fields
        setManualWithdrawalUserId('');
        setManualWithdrawalAmount('');
        setManualWithdrawalMethod('');
        setError(null);
        alert(`Successfully processed withdrawal of ${amount} KZT for user ${manualWithdrawalUserId}`);
      } else {
        setError('Failed to process withdrawal. Check if user exists and has sufficient balance.');
      }
    } catch (err) {
      console.error('Error processing manual withdrawal:', err);
      setError('Failed to process withdrawal');
    }
  };

  // Withdrawal request functions
  const handleApproveWithdrawal = async (id: string) => {
    try {
      await approveWithdrawalRequest(id);
      alert('Withdrawal request approved successfully');
    } catch (err) {
      console.error('Failed to approve withdrawal:', err);
      setError('Failed to approve withdrawal request');
    }
  };

  const handleRejectWithdrawal = async (id: string, reason: string) => {
    try {
      await rejectWithdrawalRequest(id, reason);
      alert('Withdrawal request rejected successfully');
    } catch (err) {
      console.error('Failed to reject withdrawal:', err);
      setError('Failed to reject withdrawal request');
    }
  };

  if (!isAdminLoggedIn) {
    return (
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}>
        <div style={{
          background: 'white',
          borderRadius: '20px',
          padding: '40px',
          boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
          width: '100%',
          maxWidth: '400px'
        }}>
          <div style={{ textAlign: 'center', marginBottom: '30px' }}>
            <h1 style={{
              fontSize: '28px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '10px'
            }}>
              {translate('admin_dashboard')}
            </h1>
            <p style={{ color: '#666', fontSize: '14px' }}>
              {translate('welcome_back')}
            </p>
          </div>
          
          <form onSubmit={handleAdminLogin}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '500',
                color: '#333'
              }}>
                Email
              </label>
              <input
                type="email"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  border: '2px solid #e1e5e9',
                  borderRadius: '10px',
                  fontSize: '14px',
                  outline: 'none',
                  transition: 'border-color 0.3s'
                }}
                onFocus={(e) => e.target.style.borderColor = '#667eea'}
                onBlur={(e) => e.target.style.borderColor = '#e1e5e9'}
                required
              />
            </div>
            
            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '500',
                color: '#333'
              }}>
                {translate('enter_password')}
              </label>
              <input
                type="password"
                value={adminLoginPassword}
                onChange={(e) => setAdminLoginPassword(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  border: '2px solid #e1e5e9',
                  borderRadius: '10px',
                  fontSize: '14px',
                  outline: 'none',
                  transition: 'border-color 0.3s'
                }}
                onFocus={(e) => e.target.style.borderColor = '#667eea'}
                onBlur={(e) => e.target.style.borderColor = '#e1e5e9'}
                required
              />
            </div>
            
            {adminLoginError && (
              <div style={{
                background: '#fee2e2',
                color: '#dc2626',
                padding: '12px',
                borderRadius: '8px',
                marginBottom: '20px',
                fontSize: '14px'
              }}>
                {adminLoginError}
              </div>
            )}
            
            <button
              type="submit"
              style={{
                width: '100%',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                border: 'none',
                padding: '14px',
                borderRadius: '10px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'transform 0.2s'
              }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              {translate('confirm')}
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        background: '#f8fafc'
      }}>
        <div style={{
          width: '50px',
          height: '50px',
          border: '4px solid #e2e8f0',
          borderTop: '4px solid #667eea',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
      </div>
    );
  }

  const sidebarItems = [
    { id: 'overview', icon: '📊', label: translate('overview') },
    { id: 'users', icon: '👥', label: translate('users') },
    { id: 'attempts', icon: '🔒', label: translate('failed_login_attempts') },
    { id: 'blacklist', icon: '🚫', label: translate('blacklist') },
    { id: 'payments', icon: '💳', label: translate('payment_management') },
    { id: 'deposit-requests', icon: '💰', label: translate('depositRequests') },
    { id: 'balance-management', icon: '💸', label: 'Balance Management' },
    { id: 'withdrawal-requests', icon: '🏦', label: 'Withdrawal Requests' },
    { id: 'analytics', icon: '📈', label: translate('analytics') },
    { id: 'settings', icon: '⚙️', label: translate('settings') }
  ];

  const stats = [
    {
      title: translate('total_users'),
      value: users.length.toString(),
      icon: '👥',
      color: '#3b82f6',
      change: '+12%'
    },
    {
      title: translate('active_sessions'),
      value: '24',
      icon: '🟢',
      color: '#10b981',
      change: '+5%'
    },
    {
      title: translate('total_payments'),
      value: '1,234',
      icon: '💰',
      color: '#f59e0b',
      change: '+18%'
    },
    {
      title: translate('system_health'),
      value: translate('healthy'),
      icon: '❤️',
      color: '#ef4444',
      change: '100%'
    }
  ];

  const recentActivities = [
    { user: 'user123', action: 'Login', time: '2 min ago', type: 'success' },
    { user: 'user456', action: 'Payment', time: '5 min ago', type: 'info' },
    { user: 'user789', action: 'Failed Login', time: '10 min ago', type: 'warning' },
    { user: 'user101', action: 'Registration', time: '15 min ago', type: 'success' }
  ];

  return (
    <div style={{
      display: 'flex',
      minHeight: '100vh',
      background: '#f8fafc'
    }}>
      {/* Sidebar */}
      <div style={{
        width: sidebarCollapsed ? '80px' : '280px',
        background: 'linear-gradient(180deg, #1e293b 0%, #334155 100%)',
        transition: 'width 0.3s ease',
        position: 'relative'
      }}>
        <div style={{
          padding: '20px',
          borderBottom: '1px solid #475569'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            {!sidebarCollapsed && (
              <h2 style={{
                color: 'white',
                fontSize: '20px',
                fontWeight: 'bold',
                margin: 0
              }}>
                OLIMPBET
              </h2>
            )}
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              style={{
                background: 'none',
                border: 'none',
                color: 'white',
                fontSize: '18px',
                cursor: 'pointer',
                padding: '5px'
              }}
            >
              {sidebarCollapsed ? '→' : '←'}
            </button>
          </div>
        </div>
        
        <nav style={{ padding: '20px 0' }}>
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                padding: sidebarCollapsed ? '15px 20px' : '15px 25px',
                background: activeTab === item.id ? 'rgba(255,255,255,0.1)' : 'transparent',
                border: 'none',
                color: 'white',
                fontSize: '14px',
                cursor: 'pointer',
                transition: 'background 0.2s',
                borderLeft: activeTab === item.id ? '4px solid #667eea' : '4px solid transparent'
              }}
              onMouseEnter={(e) => {
                if (activeTab !== item.id) {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeTab !== item.id) {
                  e.currentTarget.style.background = 'transparent';
                }
              }}
            >
              <span style={{ fontSize: '18px', marginRight: sidebarCollapsed ? '0' : '12px' }}>
                {item.icon}
              </span>
              {!sidebarCollapsed && (
                <span>{item.label}</span>
              )}
            </button>
          ))}
        </nav>
        
        <div style={{
          position: 'absolute',
          bottom: '20px',
          left: '0',
          right: '0',
          padding: '0 20px'
        }}>
          <button
            onClick={handleAdminLogout}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
              padding: '12px',
              background: '#dc2626',
              border: 'none',
              borderRadius: '8px',
              color: 'white',
              fontSize: '14px',
              cursor: 'pointer',
              transition: 'background 0.2s'
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#b91c1c'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#dc2626'}
          >
            <span style={{ fontSize: '16px', marginRight: sidebarCollapsed ? '0' : '8px' }}>🚪</span>
            {!sidebarCollapsed && translate('logout')}
          </button>
        </div>
      </div>
      
      {/* Main Content */}
      <div style={{ flex: 1, padding: '30px' }}>
        {/* Header */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px'
        }}>
          <div>
            <h1 style={{
              fontSize: '32px',
              fontWeight: 'bold',
              color: '#1e293b',
              margin: 0,
              marginBottom: '5px'
            }}>
              {translate('dashboard')}
            </h1>
            <p style={{
              color: '#64748b',
              margin: 0,
              fontSize: '14px'
            }}>
              {translate('welcome_back')}, {adminEmail}
            </p>
          </div>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            {/* Language Selector */}
            <select
              value={currentLanguage}
              onChange={(e) => setLanguage(e.target.value as any)}
              style={{
                padding: '10px 15px',
                border: '2px solid #e2e8f0',
                borderRadius: '10px',
                background: 'white',
                fontSize: '14px',
                fontWeight: '500',
                color: '#1e293b',
                cursor: 'pointer',
                outline: 'none',
                transition: 'all 0.2s ease',
                boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
              }}
              onFocus={(e) => e.target.style.borderColor = '#667eea'}
              onBlur={(e) => e.target.style.borderColor = '#e2e8f0'}
            >
              <option value="en">🇺🇸 English</option>
              <option value="tr">🇹🇷 Türkçe</option>
            </select>
            
            <div style={{
              background: 'white',
              padding: '12px 16px',
              borderRadius: '10px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              fontSize: '14px',
              color: '#64748b'
            }}>
              {translate('last_login')}: {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
        
        {/* Content based on active tab */}
        {activeTab === 'overview' && (
          <div>
            {/* Stats Cards */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
              gap: '20px',
              marginBottom: '30px'
            }}>
              {stats.map((stat, index) => (
                <div key={index} style={{
                  background: 'white',
                  padding: '25px',
                  borderRadius: '15px',
                  boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
                  border: '1px solid #f1f5f9'
                }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '15px'
                  }}>
                    <div style={{
                      width: '50px',
                      height: '50px',
                      borderRadius: '12px',
                      background: `${stat.color}20`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '20px'
                    }}>
                      {stat.icon}
                    </div>
                    <span style={{
                      background: '#dcfce7',
                      color: '#16a34a',
                      padding: '4px 8px',
                      borderRadius: '6px',
                      fontSize: '12px',
                      fontWeight: '600'
                    }}>
                      {stat.change}
                    </span>
                  </div>
                  <h3 style={{
                    fontSize: '28px',
                    fontWeight: 'bold',
                    color: '#1e293b',
                    margin: '0 0 5px 0'
                  }}>
                    {stat.value}
                  </h3>
                  <p style={{
                    color: '#64748b',
                    margin: 0,
                    fontSize: '14px'
                  }}>
                    {stat.title}
                  </p>
                </div>
              ))}
            </div>
            
            {/* Recent Activity */}
            <div style={{
              background: 'white',
              borderRadius: '15px',
              padding: '25px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              border: '1px solid #f1f5f9'
            }}>
              <h3 style={{
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#1e293b',
                marginBottom: '20px'
              }}>
                {translate('recent_activity')}
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                {recentActivities.map((activity, index) => (
                  <div key={index} style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '15px',
                    background: '#f8fafc',
                    borderRadius: '10px',
                    border: '1px solid #e2e8f0'
                  }}>
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      background: activity.type === 'success' ? '#dcfce7' : 
                                 activity.type === 'warning' ? '#fef3c7' : '#dbeafe',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: '15px',
                      fontSize: '16px'
                    }}>
                      {activity.type === 'success' ? '✅' : 
                       activity.type === 'warning' ? '⚠️' : 'ℹ️'}
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{
                        margin: 0,
                        fontWeight: '600',
                        color: '#1e293b',
                        fontSize: '14px'
                      }}>
                        {activity.user} - {activity.action}
                      </p>
                      <p style={{
                        margin: 0,
                        color: '#64748b',
                        fontSize: '12px'
                      }}>
                        {activity.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'users' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h2 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#1e293b',
                margin: 0
              }}>
                {translate('user_management')}
              </h2>
              <div style={{
                background: '#3b82f6',
                color: 'white',
                padding: '8px 16px',
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600'
              }}>
                {users.length} {translate('users')}
              </div>
            </div>
            
            <div style={{ overflowX: 'auto' }}>
              <table style={{
                width: '100%',
                borderCollapse: 'collapse'
              }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th style={{
                      padding: '15px',
                      textAlign: 'left',
                      fontWeight: '600',
                      color: '#475569',
                      fontSize: '14px',
                      borderBottom: '2px solid #e2e8f0'
                    }}>
                      {translate('id')}
                    </th>
                    <th style={{
                      padding: '15px',
                      textAlign: 'left',
                      fontWeight: '600',
                      color: '#475569',
                      fontSize: '14px',
                      borderBottom: '2px solid #e2e8f0'
                    }}>
                      {translate('phoneNumber')}
                    </th>
                    <th style={{
                      padding: '15px',
                      textAlign: 'left',
                      fontWeight: '600',
                      color: '#475569',
                      fontSize: '14px',
                      borderBottom: '2px solid #e2e8f0'
                    }}>
                      {translate('username')}
                    </th>
                    <th style={{
                      padding: '15px',
                      textAlign: 'left',
                      fontWeight: '600',
                      color: '#475569',
                      fontSize: '14px',
                      borderBottom: '2px solid #e2e8f0'
                    }}>
                      {translate('created_at')}
                    </th>
                    <th style={{
                      padding: '15px',
                      textAlign: 'left',
                      fontWeight: '600',
                      color: '#475569',
                      fontSize: '14px',
                      borderBottom: '2px solid #e2e8f0'
                    }}>
                      {translate('actions')}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user, index) => (
                    <tr key={user.id} style={{
                      borderBottom: '1px solid #f1f5f9',
                      transition: 'background 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                    >
                      <td style={{
                        padding: '15px',
                        fontSize: '14px',
                        color: '#1e293b'
                      }}>
                        {user.id}
                      </td>
                      <td style={{
                        padding: '15px',
                        fontSize: '14px',
                        color: '#1e293b'
                      }}>
                        {user.phone}
                      </td>
                      <td style={{
                        padding: '15px',
                        fontSize: '14px',
                        color: '#1e293b'
                      }}>
                        {user.username || '-'}
                      </td>
                      <td style={{
                        padding: '15px',
                        fontSize: '14px',
                        color: '#1e293b'
                      }}>
                        {user.created_at ? new Date(user.created_at).toLocaleString() : '-'}
                      </td>
                      <td style={{ padding: '15px' }}>
                        <button
                          onClick={() => setShowDeleteConfirm(user.phone)}
                          style={{
                            background: '#fee2e2',
                            color: '#dc2626',
                            border: 'none',
                            padding: '8px 16px',
                            borderRadius: '6px',
                            fontSize: '12px',
                            fontWeight: '600',
                            cursor: 'pointer',
                            transition: 'background 0.2s'
                          }}
                          onMouseEnter={(e) => e.currentTarget.style.background = '#fecaca'}
                          onMouseLeave={(e) => e.currentTarget.style.background = '#fee2e2'}
                        >
                          {translate('delete')}
                        </button>
                      </td>
                    </tr>
                  ))}
                  {users.length === 0 && (
                    <tr>
                      <td colSpan={5} style={{
                        padding: '40px',
                        textAlign: 'center',
                        color: '#64748b',
                        fontSize: '16px'
                      }}>
                        {translate('no_users_found')}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {activeTab === 'payments' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h2 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#1e293b',
                margin: 0
              }}>
                {translate('payment_management')}
              </h2>
              <button
                onClick={() => setShowPaymentLinkForm(true)}
                style={{
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  color: 'white',
                  border: 'none',
                  padding: '12px 24px',
                  borderRadius: '10px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'transform 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                {translate('update_payment_link')}
              </button>
            </div>
            
            <div style={{
              background: '#f8fafc',
              padding: '25px',
              borderRadius: '12px',
              marginBottom: '25px',
              border: '1px solid #e2e8f0'
            }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '600',
                color: '#1e293b',
                marginBottom: '15px'
              }}>
                {translate('current_payment_link')}
              </h3>
              <div style={{
                background: 'white',
                padding: '15px',
                borderRadius: '8px',
                border: '1px solid #e2e8f0',
                wordBreak: 'break-all',
                fontSize: '14px',
                color: '#475569',
                marginBottom: '15px'
              }}>
                {paymentLink}
              </div>
              <button
                onClick={() => window.open(paymentLink, '_blank', 'noopener,noreferrer')}
                style={{
                  background: '#10b981',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <span>🔗</span>
                Test Payment Link
              </button>
            </div>
            
            <div style={{
              background: '#eff6ff',
              border: '1px solid #bfdbfe',
              borderRadius: '12px',
              padding: '20px'
            }}>
              <h4 style={{
                fontSize: '16px',
                fontWeight: '600',
                color: '#1e40af',
                marginBottom: '15px'
              }}>
                Payment Link Instructions
              </h4>
              <ul style={{
                color: '#1e40af',
                fontSize: '14px',
                lineHeight: '1.6',
                margin: 0,
                paddingLeft: '20px'
              }}>
                <li>The payment link will be used across all payment buttons on the website</li>
                <li>Make sure the link is valid and accessible to users</li>
                <li>Test the link before updating to ensure it works correctly</li>
                <li>Changes take effect immediately across the entire website</li>
              </ul>
            </div>
          </div>
        )}
        
        {activeTab === 'blacklist' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h2 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#1e293b',
                margin: 0
              }}>
                {translate('blacklist_management')}
              </h2>
            </div>
            
            {/* Supabase setup notification */}
             {error && error.includes('blacklist') && (
               <div style={{
                 backgroundColor: '#fff3cd',
                 color: '#856404',
                 padding: '20px',
                 borderRadius: '12px',
                 marginBottom: '25px',
                 border: '1px solid #ffeeba',
                 display: 'flex',
                 flexDirection: 'column',
                 gap: '10px'
               }}>
                 <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                   <span style={{ fontSize: '24px' }}>⚠️</span>
                   <h3 style={{ margin: 0, fontSize: '18px', fontWeight: '600' }}>Supabase Setup Required</h3>
                 </div>
                 <p style={{ margin: '0 0 10px 0', fontSize: '14px', lineHeight: '1.5' }}>
                   The blacklist table does not exist in your Supabase database. Please run the SQL setup script in your Supabase dashboard to enable blacklist functionality.
                 </p>
                 <div style={{ background: '#ffecb5', padding: '15px', borderRadius: '8px' }}>
                   <h4 style={{ margin: '0 0 10px 0', fontSize: '16px', fontWeight: '600' }}>Setup Instructions:</h4>
                   <ol style={{ margin: '0', paddingLeft: '20px', fontSize: '14px', lineHeight: '1.6' }}>
                     <li>Go to your Supabase dashboard</li>
                     <li>Navigate to the SQL Editor</li>
                     <li>Copy and paste the contents of <code style={{ background: '#fff', padding: '2px 4px', borderRadius: '4px' }}>supabase-schema.sql</code> from your project</li>
                     <li>Click Run to execute the schema</li>
                     <li>Refresh this page</li>
                   </ol>
                 </div>
               </div>
             )}
            
            {/* Add to Blacklist Form */}
            <div style={{
              background: '#f8fafc',
              padding: '20px',
              borderRadius: '12px',
              marginBottom: '25px',
              border: '1px solid #e2e8f0'
            }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '600',
                color: '#1e293b',
                marginBottom: '15px'
              }}>
                {translate('add_to_blacklist')}
              </h3>
              <div style={{
                display: 'flex',
                gap: '15px',
                alignItems: 'flex-end'
              }}>
                <div style={{ flex: 1 }}>
                  <label style={{
                    display: 'block',
                    marginBottom: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151'
                  }}>
                    Username or Phone Number
                  </label>
                  <input
                    type="text"
                    value={blacklistIdentifier}
                    onChange={(e) => setBlacklistIdentifier(e.target.value)}
                    placeholder="Enter username or phone number"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '1px solid #d1d5db',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none',
                      transition: 'border-color 0.2s'
                    }}
                    onFocus={(e) => e.target.style.borderColor = '#667eea'}
                    onBlur={(e) => e.target.style.borderColor = '#d1d5db'}
                  />
                </div>
                <button
                  onClick={handleAddToBlacklist}
                  disabled={!blacklistIdentifier.trim() || loading}
                  style={{
                    background: blacklistIdentifier.trim() && !loading ? '#dc2626' : '#9ca3af',
                    color: 'white',
                    border: 'none',
                    padding: '12px 24px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: blacklistIdentifier.trim() && !loading ? 'pointer' : 'not-allowed',
                    transition: 'all 0.2s'
                  }}
                >
                  {loading ? 'Adding...' : 'Add to Blacklist'}
                </button>
              </div>
            </div>
            
            {/* Blacklisted Users Table */}
            <div style={{
              background: 'white',
              borderRadius: '12px',
              overflow: 'hidden',
              border: '1px solid #e2e8f0'
            }}>
              <div style={{
                background: '#f8fafc',
                padding: '15px 20px',
                borderBottom: '1px solid #e2e8f0'
              }}>
                <h3 style={{
                  fontSize: '16px',
                  fontWeight: '600',
                  color: '#1e293b',
                  margin: 0
                }}>
                  Blacklisted Users ({blacklistedUsers.length})
                </h3>
              </div>
              <table style={{
                width: '100%',
                borderCollapse: 'collapse'
              }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th style={{
                      padding: '15px 20px',
                      textAlign: 'left',
                      fontSize: '14px',
                      fontWeight: '600',
                      color: '#374151',
                      borderBottom: '1px solid #e2e8f0'
                    }}>ID</th>
                    <th style={{
                      padding: '15px 20px',
                      textAlign: 'left',
                      fontSize: '14px',
                      fontWeight: '600',
                      color: '#374151',
                      borderBottom: '1px solid #e2e8f0'
                    }}>Phone</th>
                    <th style={{
                      padding: '15px 20px',
                      textAlign: 'left',
                      fontSize: '14px',
                      fontWeight: '600',
                      color: '#374151',
                      borderBottom: '1px solid #e2e8f0'
                    }}>Username</th>
                    <th style={{
                      padding: '15px 20px',
                      textAlign: 'left',
                      fontSize: '14px',
                      fontWeight: '600',
                      color: '#374151',
                      borderBottom: '1px solid #e2e8f0'
                    }}>Blacklisted Date</th>
                    <th style={{
                      padding: '15px 20px',
                      textAlign: 'center',
                      fontSize: '14px',
                      fontWeight: '600',
                      color: '#374151',
                      borderBottom: '1px solid #e2e8f0'
                    }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {blacklistedUsers.length > 0 ? (
                    blacklistedUsers.map((user, index) => (
                      <tr key={user.id || index} style={{
                        borderBottom: index < blacklistedUsers.length - 1 ? '1px solid #f1f5f9' : 'none'
                      }}>
                        <td style={{
                          padding: '15px 20px',
                          fontSize: '14px',
                          color: '#1e293b'
                        }}>
                          {user.id || 'N/A'}
                        </td>
                        <td style={{
                          padding: '15px 20px',
                          fontSize: '14px',
                          color: '#1e293b'
                        }}>
                          {user.phone || 'N/A'}
                        </td>
                        <td style={{
                          padding: '15px 20px',
                          fontSize: '14px',
                          color: '#1e293b'
                        }}>
                          {user.username || 'N/A'}
                        </td>
                        <td style={{
                          padding: '15px 20px',
                          fontSize: '14px',
                          color: '#64748b'
                        }}>
                          {user.blacklisted_at ? new Date(user.blacklisted_at).toLocaleDateString() : 'N/A'}
                        </td>
                        <td style={{
                          padding: '15px 20px',
                          textAlign: 'center'
                        }}>
                          <button
                            onClick={() => handleRemoveFromBlacklist(user)}
                            disabled={loading}
                            style={{
                              background: '#10b981',
                              color: 'white',
                              border: 'none',
                              padding: '8px 16px',
                              borderRadius: '6px',
                              fontSize: '12px',
                              fontWeight: '600',
                              cursor: loading ? 'not-allowed' : 'pointer',
                              transition: 'all 0.2s',
                              opacity: loading ? 0.6 : 1
                            }}
                            onMouseEnter={(e) => {
                              if (!loading) {
                                e.currentTarget.style.background = '#059669';
                              }
                            }}
                            onMouseLeave={(e) => {
                              if (!loading) {
                                e.currentTarget.style.background = '#10b981';
                              }
                            }}
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} style={{
                        padding: '40px 20px',
                        textAlign: 'center',
                        color: '#64748b',
                        fontSize: '16px'
                      }}>
                        No blacklisted users found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* Other tabs content can be added here */}
        {activeTab === 'analytics' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9',
            textAlign: 'center'
          }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#1e293b',
              marginBottom: '15px'
            }}>
              {translate('analytics')}
            </h2>
            <p style={{ color: '#64748b', fontSize: '16px' }}>
              Analytics dashboard coming soon...
            </p>
          </div>
        )}
        
        {activeTab === 'deposit-requests' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h2 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#1e293b',
                margin: 0
              }}>
                {translate('depositRequests')}
              </h2>
            </div>
            
            {/* Debug Test Button */}
            <div style={{ marginBottom: '20px', padding: '15px', backgroundColor: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <h3 style={{ color: '#1e293b', marginBottom: '10px', fontSize: '16px' }}>Debug Balance Update</h3>
              <button
                onClick={async () => {
                  console.log('=== DEBUG TEST START ===');
                  console.log('Current user:', currentUser);
                  if (currentUser) {
                    try {
                      console.log('Testing addBalanceToUser with 100 KZT');
                      const success = await balanceAdapter.addBalanceToUser(currentUser.phone, 100, 'Debug test');
                      console.log('addBalanceToUser result:', success);
                      
                      console.log('Calling refreshBalance');
                      await refreshBalance();
                      console.log('refreshBalance completed');
                    } catch (error) {
                      console.error('Debug test error:', error);
                    }
                  }
                  console.log('=== DEBUG TEST END ===');
                }}
                style={{
                  background: '#f59e0b',
                  color: 'white',
                  border: 'none',
                  padding: '10px 15px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '600'
                }}
              >
                Test Balance Update (+100 KZT)
              </button>
            </div>
            
            <div style={{ marginBottom: '30px' }}>
              <table style={{
                width: '100%',
                borderCollapse: 'collapse',
                fontSize: '14px'
              }}>
                <thead>
                  <tr style={{
                    background: '#f8fafc',
                    borderBottom: '2px solid #e2e8f0'
                  }}>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>{translate('id')}</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>{translate('username')}</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>{translate('amount')}</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>{translate('paymentMethod')}</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>{translate('date')}</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>{translate('status')}</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>{translate('actions')}</th>
                  </tr>
                </thead>
                <tbody>
                  {depositRequests.length > 0 ? (
                    depositRequests.map((request) => (
                      <tr key={request.id} style={{ borderBottom: '1px solid #e2e8f0' }}>
                        <td style={{ padding: '15px', color: '#1e293b' }}>
                          {new Date(request.date).toLocaleDateString()} {new Date(request.date).toLocaleTimeString()}
                        </td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>{request.username}</td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>{request.amount.toLocaleString()}</td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>{request.paymentMethod}</td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>
                          {new Date(request.date).toLocaleDateString()} {new Date(request.date).toLocaleTimeString()}
                        </td>
                        <td style={{ padding: '15px' }}>
                          <span style={{
                            display: 'inline-block',
                            padding: '6px 12px',
                            borderRadius: '6px',
                            fontSize: '12px',
                            fontWeight: '600',
                            background: 
                              request.status === 'pending' ? '#fef3c7' : 
                              request.status === 'approved' ? '#dcfce7' : 
                              '#ff0000',
                            color: 
                              request.status === 'pending' ? '#d97706' : 
                              request.status === 'approved' ? '#16a34a' : 
                              '#ffffff',
                          }}>
                            {translate(request.status)}
                          </span>
                        </td>
                        <td style={{ padding: '15px' }}>
                          {request.status === 'pending' && (
                            <div style={{ display: 'flex', gap: '8px' }}>
                              <button
                                onClick={async () => {
                                  console.log('Admin: Approve button clicked for request:', request.id);
                                  await approveDepositRequest(request.id);
                                  console.log('Admin: Approve request completed');
                                }}
                                style={{
                                  background: '#10b981',
                                  color: 'white',
                                  border: 'none',
                                  padding: '8px 12px',
                                  borderRadius: '6px',
                                  fontSize: '12px',
                                  fontWeight: '600',
                                  cursor: 'pointer',
                                  transition: 'background 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = '#059669'}
                                onMouseLeave={(e) => e.currentTarget.style.background = '#10b981'}
                              >
                                {translate('approve')}
                              </button>
                              <button
                                onClick={async () => {
                                  const reason = prompt(translate('enterRejectionReason'));
                                  if (reason) {
                                    await rejectDepositRequest(request.id, reason);
                                  }
                                }}
                                style={{
                                  background: '#ef4444',
                                  color: 'white',
                                  border: 'none',
                                  padding: '8px 12px',
                                  borderRadius: '6px',
                                  fontSize: '12px',
                                  fontWeight: '600',
                                  cursor: 'pointer',
                                  transition: 'background 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = '#dc2626'}
                                onMouseLeave={(e) => e.currentTarget.style.background = '#ef4444'}
                              >
                                {translate('reject')}
                              </button>
                            </div>
                          )}
                          {request.status === 'rejected' && request.rejectionReason && (
                            <div style={{ fontSize: '12px', color: '#64748b' }}>
                              <strong>{translate('rejectionReason')}:</strong> {request.rejectionReason}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} style={{
                        padding: '40px',
                        textAlign: 'center',
                        color: '#64748b',
                        fontSize: '16px'
                      }}>
                        {translate('no_deposit_requests_found')}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {activeTab === 'balance-management' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h2 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#1e293b',
                margin: 0
              }}>
                Balance Management
              </h2>
            </div>
            
            {/* Balance Addition Form */}
            <div style={{
              background: '#f8fafc',
              padding: '25px',
              borderRadius: '12px',
              marginBottom: '25px',
              border: '1px solid #e2e8f0'
            }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '600',
                color: '#1e293b',
                marginBottom: '20px'
              }}>
                Add Balance to User
              </h3>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 2fr auto', gap: '15px', alignItems: 'end' }}>
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    User phone number
                  </label>
                  <input
                    type="text"
                    value={selectedUserId}
                    onChange={(e) => setSelectedUserId(e.target.value)}
                    placeholder="Enter phone number"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Amount
                  </label>
                  <input
                    type="number"
                    value={balanceAmount}
                    onChange={(e) => setBalanceAmount(e.target.value)}
                    placeholder="Enter amount"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Reason/Note
                  </label>
                  <input
                    type="text"
                    value={balanceReason}
                    onChange={(e) => setBalanceReason(e.target.value)}
                    placeholder="Enter reason for balance adjustment"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <button
                  onClick={handleAddBalance}
                  style={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    color: 'white',
                    border: 'none',
                    padding: '12px 24px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'transform 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                  onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
                >
                  Add Balance
                </button>
              </div>
            </div>
            
            {/* Balance Removal Form */}
            <div style={{
              background: '#fef2f2',
              padding: '25px',
              borderRadius: '12px',
              marginBottom: '25px',
              border: '1px solid #fecaca'
            }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '600',
                color: '#dc2626',
                marginBottom: '20px'
              }}>
                Remove Balance from User
              </h3>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 2fr auto', gap: '15px', alignItems: 'end' }}>
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    User phone number
                  </label>
                  <input
                    type="text"
                    value={removeUserId}
                    onChange={(e) => setRemoveUserId(e.target.value)}
                    placeholder="Enter phone number"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Amount
                  </label>
                  <input
                    type="number"
                    value={removeAmount}
                    onChange={(e) => setRemoveAmount(e.target.value)}
                    placeholder="Enter amount"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Reason/Note
                  </label>
                  <input
                    type="text"
                    value={removeReason}
                    onChange={(e) => setRemoveReason(e.target.value)}
                    placeholder="Enter reason for balance removal"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <button
                  onClick={handleRemoveBalance}
                  style={{
                    background: 'linear-gradient(135deg, #dc2626 0%, #b91c1c 100%)',
                    color: 'white',
                    border: 'none',
                    padding: '12px 24px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'transform 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                  onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
                >
                  Remove Balance
                </button>
              </div>
            </div>
            
            <div style={{
              background: '#eff6ff',
              border: '1px solid #bfdbfe',
              borderRadius: '12px',
              padding: '20px'
            }}>
              <h4 style={{
                fontSize: '16px',
                fontWeight: '600',
                color: '#1e40af',
                marginBottom: '15px'
              }}>
                Balance Management Instructions
              </h4>
              <ul style={{
                color: '#1e40af',
                fontSize: '14px',
                lineHeight: '1.6',
                margin: 0,
                paddingLeft: '20px'
              }}>
                <li><strong>Add Balance:</strong> Enter the exact User phone number to add balance to their account</li>
                <li><strong>Remove Balance:</strong> Enter the exact User phone number to remove balance (checks for sufficient funds)</li>
                <li>Always provide a clear reason for any balance adjustment</li>
                <li>Remove operations will fail if user has insufficient balance</li>
                <li>All balance changes are logged and tracked for audit purposes</li>
              </ul>
            </div>
          </div>
        )}
        
        {activeTab === 'withdrawal-requests' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h2 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#1e293b',
                margin: 0
              }}>
                Withdrawal Requests
              </h2>
            </div>
            
            {/* Manual Withdrawal Processing Form */}
            <div style={{
              background: '#f8fafc',
              padding: '25px',
              borderRadius: '12px',
              marginBottom: '25px',
              border: '1px solid #e2e8f0'
            }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '600',
                color: '#1e293b',
                marginBottom: '20px'
              }}>
                Process Manual Withdrawal
              </h3>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '15px', alignItems: 'end' }}>
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    User phone number
                  </label>
                  <input
                    type="text"
                    value={manualWithdrawalUserId}
                    onChange={(e) => setManualWithdrawalUserId(e.target.value)}
                    placeholder="Enter phone number"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Amount
                  </label>
                  <input
                    type="number"
                    value={manualWithdrawalAmount}
                    onChange={(e) => setManualWithdrawalAmount(e.target.value)}
                    placeholder="Enter amount"
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
                
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Payment Method
                  </label>
                  <select
                    value={manualWithdrawalMethod}
                    onChange={(e) => setManualWithdrawalMethod(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  >
                    <option value="">Select method</option>
                    <option value="Kaspi">Kaspi</option>
                    <option value="Qiwi">Qiwi</option>
                    <option value="Card">Card</option>
                  </select>
                </div>
                
                <button
                  onClick={handleManualWithdrawal}
                  style={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    color: 'white',
                    border: 'none',
                    padding: '12px 24px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'transform 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                  onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
                >
                  Process Withdrawal
                </button>
              </div>
            </div>
            
            {/* Withdrawal Requests Table */}
            <div style={{ marginBottom: '30px' }}>
              <table style={{
                width: '100%',
                borderCollapse: 'collapse',
                fontSize: '14px'
              }}>
                <thead>
                  <tr style={{
                    background: '#f8fafc',
                    borderBottom: '2px solid #e2e8f0'
                  }}>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>ID</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>Phone Number</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>Amount</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>Payment Method</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>Date</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>Status</th>
                    <th style={{ padding: '15px', textAlign: 'left', fontWeight: '600', color: '#475569' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {withdrawalRequests.length > 0 ? (
                    withdrawalRequests.map((request) => (
                      <tr key={request.id} style={{ borderBottom: '1px solid #e2e8f0' }}>
                        <td style={{ padding: '15px', color: '#1e293b' }}>{request.id}</td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>{request.user_id || 'Unknown'}</td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>{request.amount.toLocaleString()}</td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>{request.paymentMethod}</td>
                        <td style={{ padding: '15px', color: '#1e293b' }}>
                          {new Date(request.date).toLocaleDateString()} {new Date(request.date).toLocaleTimeString()}
                        </td>
                        <td style={{ padding: '15px' }}>
                          <span style={{
                            display: 'inline-block',
                            padding: '6px 12px',
                            borderRadius: '6px',
                            fontSize: '12px',
                            fontWeight: '600',
                            background: 
                              request.status === 'pending' ? '#fef3c7' : 
                              request.status === 'approved' ? '#dcfce7' : 
                              '#fecaca',
                            color: 
                              request.status === 'pending' ? '#d97706' : 
                              request.status === 'approved' ? '#16a34a' : 
                              '#dc2626',
                          }}>
                            {request.status}
                          </span>
                        </td>
                        <td style={{ padding: '15px' }}>
                          {request.status === 'pending' && (
                            <div style={{ display: 'flex', gap: '8px' }}>
                              <button
                                onClick={async () => await handleApproveWithdrawal(request.id)}
                                style={{
                                  background: '#10b981',
                                  color: 'white',
                                  border: 'none',
                                  padding: '8px 12px',
                                  borderRadius: '6px',
                                  fontSize: '12px',
                                  fontWeight: '600',
                                  cursor: 'pointer',
                                  transition: 'background 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = '#059669'}
                                onMouseLeave={(e) => e.currentTarget.style.background = '#10b981'}
                              >
                                Approve
                              </button>
                              <button
                                onClick={async () => {
                                  const reason = prompt('Enter rejection reason:');
                                  if (reason) {
                                    await handleRejectWithdrawal(request.id, reason);
                                  }
                                }}
                                style={{
                                  background: '#ef4444',
                                  color: 'white',
                                  border: 'none',
                                  padding: '8px 12px',
                                  borderRadius: '6px',
                                  fontSize: '12px',
                                  fontWeight: '600',
                                  cursor: 'pointer',
                                  transition: 'background 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = '#dc2626'}
                                onMouseLeave={(e) => e.currentTarget.style.background = '#ef4444'}
                              >
                                Reject
                              </button>
                            </div>
                          )}
                          {request.status === 'rejected' && request.rejectionReason && (
                            <div style={{ fontSize: '12px', color: '#64748b' }}>
                              <strong>Rejection Reason:</strong> {request.rejectionReason}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} style={{
                        padding: '40px',
                        textAlign: 'center',
                        color: '#64748b',
                        fontSize: '16px'
                      }}>
                        No withdrawal requests found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {/* Withdrawal Instructions */}
            <div style={{
              background: '#eff6ff',
              border: '1px solid #bfdbfe',
              borderRadius: '12px',
              padding: '20px'
            }}>
              <h4 style={{
                fontSize: '16px',
                fontWeight: '600',
                color: '#1e40af',
                marginBottom: '15px'
              }}>
                Withdrawal Management Instructions
              </h4>
              <ul style={{
                color: '#1e40af',
                fontSize: '14px',
                lineHeight: '1.6',
                margin: 0,
                paddingLeft: '20px'
              }}>
                <li><strong>Process Manual Withdrawal:</strong> Use the form above to manually process a withdrawal for a user</li>
                <li><strong>Approve Withdrawal:</strong> Verify payment details before approving any withdrawal request</li>
                <li><strong>Reject Withdrawal:</strong> Always provide a clear reason when rejecting a withdrawal</li>
                <li>All withdrawal transactions are logged for audit purposes</li>
                <li>Contact the finance team for any issues with payment processing</li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div style={{
            background: 'white',
            borderRadius: '15px',
            padding: '25px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
            border: '1px solid #f1f5f9',
            textAlign: 'center'
          }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#1e293b',
              marginBottom: '15px'
            }}>
              {translate('settings')}
            </h2>
            <p style={{ color: '#64748b', fontSize: '16px' }}>
              Settings panel coming soon...
            </p>
          </div>
        )}
      </div>
      
      {/* Payment Link Update Modal */}
      {showPaymentLinkForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: 'white',
            borderRadius: '20px',
            padding: '30px',
            width: '90%',
            maxWidth: '500px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#1e293b',
              marginBottom: '20px',
              textAlign: 'center'
            }}>
              {translate('update_payment_link')}
            </h3>
            
            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: '#374151'
              }}>
                {translate('enter_new_payment_link')}
              </label>
              <input
                type="url"
                value={newPaymentLink}
                onChange={(e) => setNewPaymentLink(e.target.value)}
                placeholder="https://kaspi.kz/pay/OLIMPBET?7695=92070570"
                style={{
                  width: '100%',
                  padding: '15px',
                  border: '2px solid #e5e7eb',
                  borderRadius: '10px',
                  fontSize: '14px',
                  outline: 'none',
                  transition: 'border-color 0.3s'
                }}
                onFocus={(e) => e.target.style.borderColor = '#667eea'}
                onBlur={(e) => e.target.style.borderColor = '#e5e7eb'}
                autoFocus
              />
            </div>
            
            <div style={{
              display: 'flex',
              gap: '15px',
              justifyContent: 'flex-end'
            }}>
              <button
                onClick={() => {
                  setNewPaymentLink('');
                  setShowPaymentLinkForm(false);
                }}
                style={{
                  padding: '12px 24px',
                  background: '#f3f4f6',
                  color: '#374151',
                  border: 'none',
                  borderRadius: '10px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#e5e7eb'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#f3f4f6'}
              >
                {translate('cancel')}
              </button>
              <button
                onClick={async () => {
                  if (newPaymentLink.trim()) {
                    await updatePaymentLink(newPaymentLink.trim());
                    setNewPaymentLink('');
                    setShowPaymentLinkForm(false);
                  }
                }}
                style={{
                  padding: '12px 24px',
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '10px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'transform 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                {translate('update')}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: 'white',
            borderRadius: '20px',
            padding: '30px',
            width: '90%',
            maxWidth: '400px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
            textAlign: 'center'
          }}>
            <div style={{
              width: '60px',
              height: '60px',
              background: '#fee2e2',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              fontSize: '24px'
            }}>
              ⚠️
            </div>
            
            <h3 style={{
              fontSize: '20px',
              fontWeight: 'bold',
              color: '#1e293b',
              marginBottom: '10px'
            }}>
              {translate('confirm_delete_user')}
            </h3>
            
            <p style={{
              color: '#64748b',
              marginBottom: '25px',
              fontSize: '14px'
            }}>
              {translate('delete_user_warning')} {showDeleteConfirm}
            </p>
            
            <div style={{
              display: 'flex',
              gap: '15px',
              justifyContent: 'center'
            }}>
              <button
                onClick={() => setShowDeleteConfirm(null)}
                style={{
                  padding: '12px 24px',
                  background: '#f3f4f6',
                  color: '#374151',
                  border: 'none',
                  borderRadius: '10px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                {translate('cancel')}
              </button>
              <button
                onClick={() => {
                  // Add delete logic here
                  setShowDeleteConfirm(null);
                }}
                style={{
                  padding: '12px 24px',
                  background: '#dc2626',
                  color: 'white',
                  border: 'none',
                  borderRadius: '10px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                {translate('delete')}
              </button>
            </div>
          </div>
        </div>
      )}
      
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
    </div>
  );
};

export default Admin;