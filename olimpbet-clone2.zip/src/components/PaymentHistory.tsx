import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useBalance } from '../contexts/BalanceContext';
import { useAuth } from '../contexts/AuthContext';
import { getTransactionHistory } from '../database/payment-adapter';

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  method: string;
  status: 'completed' | 'pending' | 'failed' | 'rejected';
  date: Date;
  details?: string;
  rejectionReason?: string;
}

const PaymentHistory: React.FC = () => {
  const { translate } = useLanguage();
  const { formatBalance } = useBalance();
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<{ from: string; to: string }>({ 
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days ago
    to: new Date().toISOString().split('T')[0] // today
  });
  
  const { currentUser } = useAuth();

  // Fetch real transaction data
  useEffect(() => {
    const fetchTransactionHistory = async () => {
      if (currentUser?.phone) {
        try {
          const history = await getTransactionHistory(currentUser.phone);
          setTransactions(history);
        } catch (error) {
          console.error('Error fetching transaction history:', error);
          // Fallback to empty array if there's an error
          setTransactions([]);
        }
      }
    };
    
    fetchTransactionHistory();
  }, [currentUser]);
  
  // Apply filters
  useEffect(() => {
    let filtered = [...transactions];
    
    // Filter by type
    if (filter === 'deposits') {
      filtered = filtered.filter(tx => tx.type === 'deposit');
    } else if (filter === 'withdrawals') {
      filtered = filtered.filter(tx => tx.type === 'withdrawal');
    }
    
    // Filter by date range
    const fromDate = new Date(dateRange.from);
    fromDate.setHours(0, 0, 0, 0);
    
    const toDate = new Date(dateRange.to);
    toDate.setHours(23, 59, 59, 999);
    
    filtered = filtered.filter(tx => {
      const txDate = new Date(tx.date);
      return txDate >= fromDate && txDate <= toDate;
    });
    
    // Sort by date (newest first)
    filtered.sort((a, b) => b.date.getTime() - a.date.getTime());
    
    setFilteredTransactions(filtered);
  }, [transactions, filter, dateRange]);
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilter(e.target.value);
  };
  
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDateRange(prev => ({ ...prev, [name]: value }));
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return '#27ae60';
      case 'pending':
        return '#f39c12';
      case 'failed':
        return '#e74c3c';
      case 'rejected':
        return '#ff0000';
      default:
        return '#7f8c8d';
    }
  };
  
  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '20px' }}>
        {translate('paymentHistory')}
      </h1>
      
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        marginBottom: '20px',
        backgroundColor: '#2c3e50',
        padding: '15px',
        borderRadius: '8px'
      }}>
        <div>
          <label style={{ marginRight: '10px' }}>{translate('filterBy')}:</label>
          <select 
            value={filter} 
            onChange={handleFilterChange}
            style={{
              padding: '8px',
              backgroundColor: '#34495e',
              border: '1px solid #445566',
              borderRadius: '4px',
              color: 'white'
            }}
          >
            <option value="all">{translate('allTransactions')}</option>
            <option value="deposits">{translate('deposits')}</option>
            <option value="withdrawals">{translate('withdrawals')}</option>
          </select>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{ marginRight: '10px' }}>
            <label style={{ marginRight: '5px', fontSize: '14px' }}>{translate('from')}:</label>
            <input 
              type="date" 
              name="from" 
              value={dateRange.from} 
              onChange={handleDateChange}
              style={{
                padding: '8px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white'
              }}
            />
          </div>
          
          <div>
            <label style={{ marginRight: '5px', fontSize: '14px' }}>{translate('to')}:</label>
            <input 
              type="date" 
              name="to" 
              value={dateRange.to} 
              onChange={handleDateChange}
              style={{
                padding: '8px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white'
              }}
            />
          </div>
        </div>
      </div>
      
      {filteredTransactions.length > 0 ? (
        <div style={{ backgroundColor: '#2c3e50', borderRadius: '8px', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#34495e', textAlign: 'left' }}>
                <th style={{ padding: '12px 15px' }}>{translate('date')}</th>
                <th style={{ padding: '12px 15px' }}>{translate('transactionId')}</th>
                <th style={{ padding: '12px 15px' }}>{translate('type')}</th>
                <th style={{ padding: '12px 15px' }}>{translate('amount')}</th>
                <th style={{ padding: '12px 15px' }}>{translate('method')}</th>
                <th style={{ padding: '12px 15px' }}>{translate('details')}</th>
                <th style={{ padding: '12px 15px' }}>{translate('status')}</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((tx, index) => (
                <tr 
                  key={tx.id} 
                  style={{ 
                    borderTop: '1px solid #445566',
                    backgroundColor: index % 2 === 0 ? '#2c3e50' : '#34495e'
                  }}
                >
                  <td style={{ padding: '12px 15px' }}>
                    {tx.date.toLocaleDateString()}
                    <div style={{ fontSize: '12px', color: '#7f8c8d' }}>
                      {tx.date.toLocaleTimeString()}
                    </div>
                  </td>
                  <td style={{ padding: '12px 15px' }}>{tx.id}</td>
                  <td style={{ padding: '12px 15px' }}>
                    <div style={{ 
                      display: 'inline-block',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      backgroundColor: tx.type === 'deposit' ? '#2980b9' : '#8e44ad',
                      fontSize: '12px'
                    }}>
                      {translate(tx.type)}
                    </div>
                  </td>
                  <td style={{ padding: '12px 15px', fontWeight: 'bold' }}>
                    <span style={{ color: tx.type === 'deposit' ? '#27ae60' : '#e74c3c' }}>
                      {tx.type === 'deposit' ? '+' : '-'}{formatBalance(tx.amount)}
                    </span>
                  </td>
                  <td style={{ padding: '12px 15px' }}>{translate(tx.method)}</td>
                  <td style={{ padding: '12px 15px' }}>
                    {tx.status === 'rejected' && tx.rejectionReason ? (
                      <div>
                        <div>{tx.details}</div>
                        <div style={{ color: '#e74c3c', fontSize: '12px', marginTop: '4px' }}>
                          {translate('rejectionReason')}: {tx.rejectionReason}
                        </div>
                      </div>
                    ) : (
                      tx.details
                    )}
                  </td>
                  <td style={{ padding: '12px 15px' }}>
                    <div style={{ 
                      display: 'inline-block',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      backgroundColor: getStatusColor(tx.status),
                      fontSize: '12px'
                    }}>
                      {translate(tx.status)}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div style={{ 
          backgroundColor: '#2c3e50', 
          padding: '20px', 
          borderRadius: '8px', 
          textAlign: 'center',
          color: '#7f8c8d'
        }}>
          <div style={{ fontSize: '40px', marginBottom: '10px' }}>📋</div>
          <h3>{translate('noTransactionsFound')}</h3>
          <p>{translate('tryChangingFilters')}</p>
        </div>
      )}
    </div>
  );
};

export default PaymentHistory;