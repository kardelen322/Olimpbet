import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const AboutUs: React.FC = () => {
  const { translate, isRTL } = useLanguage();

  return (
    <div style={{ 
      display: 'flex', 
      margin: '0 auto', 
      padding: '20px 20px 20px 10px',
      gap: '20px' 
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />
      
      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <h1 style={{
            fontSize: '36px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 15px 0'
          }}>
            {translate('aboutUsTitle')}
          </h1>
          <p style={{
            fontSize: '18px',
            color: '#666',
            margin: '0',
            lineHeight: '1.6'
          }}>
            {translate('aboutUsSubtitle')}
          </p>
        </div>

        {/* Main Content */}
        {/* Add more sections as needed */}
      </div>
    </div>
  );
};

export default AboutUs; 
