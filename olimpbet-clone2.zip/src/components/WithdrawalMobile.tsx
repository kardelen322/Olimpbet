import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useBalance } from '../contexts/BalanceContext';
import { useWithdrawal } from '../contexts/WithdrawalContext';
import { useAuth } from '../contexts/AuthContext';

const WithdrawalMobile: React.FC = () => {
  const { translate } = useLanguage();
  const { balance, formatBalance } = useBalance();
  const { addWithdrawalRequest } = useWithdrawal();
  const { currentUser } = useAuth();
  
  const [amount, setAmount] = useState<string>('1000');
  const [withdrawalMethod, setWithdrawalMethod] = useState<string>('kaspi');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [showSuccess, setShowSuccess] = useState<boolean>(false);
  const [transactionId, setTransactionId] = useState<string>('');
  const [withdrawalStatus, setWithdrawalStatus] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [rejectionReason, setRejectionReason] = useState<string>('');
  const [showNotification, setShowNotification] = useState<boolean>(false);
  const [notificationMessage, setNotificationMessage] = useState<string>('');
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) {
      setAmount(value);
    }
  };
  
  const handleQuickAmounts = (amount: number) => {
    setAmount(amount.toString());
  };
  
  const handleWithdrawalMethodChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setWithdrawalMethod(e.target.value);
  };
  
  const handleAccountNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAccountNumber(e.target.value);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || parseInt(amount) < 100) {
      alert(translate('minimumWithdrawalAmount'));
      return;
    }
    
    if (parseInt(amount) > balance) {
      alert(translate('insufficientFunds'));
      return;
    }
    
    if (!accountNumber) {
      alert(translate('pleaseEnterAccountNumber'));
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Simulate withdrawal processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate a transaction ID
      const txId = `WD-${Date.now().toString().slice(-6)}`;
      setTransactionId(txId);
      
      // Create withdrawal request instead of directly withdrawing funds
      if (currentUser) {
        await addWithdrawalRequest({
          username: currentUser.username || '',
          amount: parseInt(amount),
          paymentMethod: withdrawalMethod,
          accountNumber: accountNumber
        });
      }
      
      setShowSuccess(true);
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      alert(translate('withdrawalFailed'));
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleNewWithdrawal = () => {
    setShowSuccess(false);
    setAmount('1000');
    setWithdrawalMethod('kaspi');
    setAccountNumber('');
    setWithdrawalStatus('pending');
    setRejectionReason('');
    setShowNotification(false);
    setNotificationMessage('');
  };
  
  // For demo purposes only - to simulate a rejected withdrawal
  const handleSimulateRejection = () => {
    setWithdrawalStatus('rejected');
    const reason = 'Bank account verification failed';
    setRejectionReason(reason);
    
    // Show notification
    setNotificationMessage(`Your withdrawal request for ${parseInt(amount).toLocaleString()} has been rejected. Reason: ${reason}`);
    setShowNotification(true);
    
    // Hide notification after 5 seconds
    setTimeout(() => {
      setShowNotification(false);
    }, 5000);
  };
  
  const handleSimulateApproval = () => {
    setWithdrawalStatus('approved');
    
    // Show notification
    setNotificationMessage(`Your withdrawal request for ${parseInt(amount).toLocaleString()} has been approved and will be processed shortly.`);
    setShowNotification(true);
    
    // Hide notification after 5 seconds
    setTimeout(() => {
      setShowNotification(false);
    }, 5000);
  };
  
  return (
    <div style={{ padding: '15px', position: 'relative' }}>
      {/* Notification Toast */}
      {showNotification && (
        <div style={{
          position: 'fixed',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          backgroundColor: notificationMessage.includes('approved') ? '#27ae60' : '#e74c3c',
          color: 'white',
          padding: '12px 20px',
          borderRadius: '8px',
          zIndex: 1000,
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          maxWidth: '90%',
          textAlign: 'center',
          fontSize: '14px',
          fontWeight: 'bold'
        }}>
          {notificationMessage}
        </div>
      )}
      
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '15px', fontSize: '20px' }}>
        {translate('withdrawal')}
      </h1>
      
      {!showSuccess ? (
        <div>
          <div style={{ 
            backgroundColor: '#2c3e50', 
            padding: '15px', 
            borderRadius: '8px',
            marginBottom: '15px'
          }}>
            <div style={{ fontSize: '14px' }}>
              {translate('currentBalance')}: <span style={{ fontWeight: 'bold' }}>{formatBalance(balance)}</span>
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div style={{ backgroundColor: '#2c3e50', padding: '15px', borderRadius: '8px' }}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
                  {translate('selectWithdrawalMethod')}
                </label>
                <select
                  value={withdrawalMethod}
                  onChange={handleWithdrawalMethodChange}
                  style={{
                    width: '100%',
                    padding: '10px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white',
                    fontSize: '14px'
                  }}
                >
                  <option value="kaspi">{translate('kaspi')}</option>
                  <option value="visa">{translate('visa')}</option>
                  <option value="mastercard">{translate('mastercard')}</option>
                  <option value="qiwi">{translate('qiwi')}</option>
                </select>
              </div>
              
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
                  {translate('enterAmount')}
                </label>
                <input
                  type="text"
                  value={amount}
                  onChange={handleAmountChange}
                  style={{
                    width: '100%',
                    padding: '10px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white',
                    fontSize: '14px'
                  }}
                  placeholder={translate('enterAmount')}
                />
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginTop: '8px' }}>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(1000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    1,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(5000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    5,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(10000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    10,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(50000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    50,000
                  </button>
                </div>
              </div>
              
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
                  {withdrawalMethod === 'kaspi' ? translate('enterPhoneNumber') : 
                   withdrawalMethod === 'qiwi' ? translate('enterQiwiWallet') : 
                   translate('enterCardNumber')}
                </label>
                <input
                  type="text"
                  value={accountNumber}
                  onChange={handleAccountNumberChange}
                  style={{
                    width: '100%',
                    padding: '10px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white',
                    fontSize: '14px'
                  }}
                  placeholder={withdrawalMethod === 'kaspi' ? '+7 XXX XXX XX XX' : 
                              withdrawalMethod === 'qiwi' ? translate('qiwiWalletNumber') : 
                              'XXXX XXXX XXXX XXXX'}
                />
              </div>
              
              <div style={{ marginBottom: '15px' }}>
                <div style={{ 
                  backgroundColor: '#34495e', 
                  padding: '12px', 
                  borderRadius: '4px',
                  fontSize: '13px'
                }}>
                  <div style={{ marginBottom: '8px', fontWeight: 'bold' }}>
                    {translate('withdrawalInformation')}
                  </div>
                  <ul style={{ paddingLeft: '20px', margin: '0' }}>
                    <li style={{ marginBottom: '5px' }}>{translate('minimumWithdrawalIs')} 100 {translate('currency')}</li>
                    <li style={{ marginBottom: '5px' }}>{translate('processingTimeIs')} 1-24 {translate('hours')}</li>
                    <li style={{ marginBottom: '5px' }}>{translate('withdrawalFeesInfo')}</li>
                    <li>{translate('verificationMayBeRequired')}</li>
                  </ul>
                </div>
              </div>
              
              <button
                type="submit"
                disabled={isProcessing}
                style={{
                  width: '100%',
                  padding: '12px',
                  backgroundColor: isProcessing ? '#7f8c8d' : '#27ae60',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: isProcessing ? 'not-allowed' : 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}
              >
                {isProcessing ? translate('processing') : translate('requestWithdrawal')}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div style={{ backgroundColor: '#2c3e50', padding: '15px', borderRadius: '8px', textAlign: 'center' }}>
          <div style={{ 
            backgroundColor: '#27ae60', 
            color: 'white', 
            width: '60px', 
            height: '60px', 
            borderRadius: '50%', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            margin: '0 auto 15px',
            fontSize: '30px'
          }}>
            ✓
          </div>
          
          <h2 style={{ marginBottom: '15px', fontSize: '18px' }}>{translate('withdrawalRequestSubmitted')}</h2>
          
          <div style={{ 
            backgroundColor: '#34495e', 
            padding: '12px', 
            borderRadius: '4px', 
            marginBottom: '15px',
            textAlign: 'left',
            fontSize: '14px'
          }}>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('transactionId')}:</span>
              <span>{transactionId}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('amount')}:</span>
              <span>{formatBalance(parseInt(amount))}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('withdrawalMethod')}:</span>
              <span>{translate(withdrawalMethod)}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('accountNumber')}:</span>
              <span>{accountNumber}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('date')}:</span>
              <span>{new Date().toLocaleString()}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('status')}:</span>
              <span style={{ 
                color: withdrawalStatus === 'pending' ? '#f39c12' : 
                       withdrawalStatus === 'approved' ? '#27ae60' : '#e74c3c' 
              }}>
                {translate(withdrawalStatus)}
              </span>
            </div>
            {withdrawalStatus === 'rejected' && rejectionReason && (
              <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
                <span>{translate('rejectionReason')}:</span>
                <span style={{ color: '#e74c3c' }}>{rejectionReason}</span>
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
              <span>{translate('newBalance')}:</span>
              <span>{formatBalance(balance)}</span>
            </div>
          </div>
          
          <div style={{ 
            backgroundColor: '#34495e', 
            padding: '12px', 
            borderRadius: '4px', 
            marginBottom: '15px',
            textAlign: 'left',
            fontSize: '13px'
          }}>
            <div style={{ marginBottom: '8px', fontWeight: 'bold' }}>
              {translate('nextSteps')}
            </div>
            <ol style={{ paddingLeft: '20px', margin: '0' }}>
              <li style={{ marginBottom: '5px' }}>{translate('withdrawalProcessingInfo')}</li>
              <li style={{ marginBottom: '5px' }}>{translate('checkEmailForUpdates')}</li>
              <li>{translate('contactSupportForQuestions')}</li>
            </ol>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <button
              onClick={handleNewWithdrawal}
              style={{
                width: '100%',
                padding: '12px',
                backgroundColor: '#3498db',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: 'bold'
              }}
            >
              {translate('makeAnotherWithdrawal')}
            </button>
            
            {/* Demo buttons for testing - would be removed in production */}
            {withdrawalStatus === 'pending' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default WithdrawalMobile;