import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const TermsConditions: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeSection, setActiveSection] = useState('general');

  const termsSections = [
    {
      id: 'general',
      title: 'Общие положения',
      icon: '📋',
      content: {
        intro: 'Настоящие Общие условия и положения регулируют использование услуг букмекерской компании OLIMPBET.',
        points: [
          'Настоящие условия являются публичной офертой и вступают в силу с момента регистрации пользователя на сайте.',
          'Компания оставляет за собой право изменять настоящие условия в одностороннем порядке, уведомляя пользователей на сайте.',
          'Пользователь обязуется регулярно знакомиться с актуальной версией настоящих условий.',
          'Использование сайта после внесения изменений означает согласие с новыми условиями.',
          'Споры между сторонами рассматриваются в соответствии с законодательством Республики Казахстан.',
          'Компания имеет право приостановить или прекратить предоставление услуг без предварительного уведомления в случае нарушения пользователем настоящих условий.'
        ]
      }
    },
    {
      id: 'account',
      title: 'Регистрация и управление аккаунтом',
      icon: '👤',
      content: {
        intro: 'Правила создания и управления аккаунтом пользователя на платформе.',
        points: [
          'Для регистрации необходимо достичь совершеннолетия (18 лет) и быть дееспособным лицом.',
          'Пользователь может иметь только один аккаунт. Создание дополнительных аккаунтов запрещено.',
          'При регистрации необходимо указать достоверную информацию. Предоставление ложных данных является основанием для блокировки аккаунта.',
          'Пользователь обязуется сохранять конфиденциальность логина и пароля от своего аккаунта.',
          'Компания не несет ответственности за ущерб, причиненный в результате использования аккаунта третьими лицами.',
          'Верификация аккаунта является обязательной процедурой для вывода средств и может потребовать предоставления документов.',
          'Пользователь имеет право закрыть аккаунт в любое время, обратившись в службу поддержки.',
          'При закрытии аккаунта все бонусы и акционные средства аннулируются.'
        ]
      }
    },
    {
      id: 'betting',
      title: 'Правила приема ставок',
      icon: '🎯',
      content: {
        intro: 'Условия и правила размещения ставок на спортивные события.',
        points: [
          'Ставки принимаются только с игрового счета пользователя при наличии достаточного количества средств.',
          'Минимальная сумма ставки составляет 10 рублей, максимальная определяется для каждого события индивидуально.',
          'Принятые ставки не подлежат отмене или изменению, за исключением технических ошибок.',
          'Коэффициенты могут изменяться до момента начала события. Ставка принимается по коэффициенту, действующему на момент её размещения.',
          'В случае отмены или переноса события ставки возвращаются с коэффициентом 1.0.',
          'Расчет ставок производится на основании официальных результатов соответствующих спортивных организаций.',
          'Компания имеет право ограничить максимальную сумму ставки для отдельных пользователей.',
          'Ставки на события с участием несовершеннолетних спортсменов запрещены.',
          'При технических сбоях все ставки, принятые с некорректными коэффициентами, подлежат пересчету или возврату.'
        ]
      }
    },
    {
      id: 'payments',
      title: 'Финансовые операции',
      icon: '💰',
      content: {
        intro: 'Правила пополнения счета и вывода средств.',
        points: [
          'Пополнение счета производится через доступные платежные системы, указанные на сайте.',
          'Минимальная сумма пополнения составляет 100 рублей, максимальная - 100 000 рублей за одну операцию.',
          'Средства зачисляются на игровой счет в течение 15 минут после подтверждения платежа.',
          'Вывод средств возможен только на те же реквизиты, с которых производилось пополнение.',
          'Минимальная сумма для вывода - 200 рублей, максимальная - 50 000 рублей в сутки.',
          'Первые 5 операций вывода в месяц производятся без комиссии, далее взимается комиссия 3%.',
          'Срок обработки заявки на вывод составляет от 24 часов до 5 рабочих дней в зависимости от способа.',
          'Для вывода средств аккаунт должен быть полностью верифицирован.',
          'Компания имеет право запросить дополнительные документы для подтверждения права на вывод средств.',
          'Бонусные средства подлежат отыгрышу согласно условиям соответствующих акций.'
        ]
      }
    },
    {
      id: 'responsible',
      title: 'Ответственная игра',
      icon: '🛡️',
      content: {
        intro: 'Меры по предотвращению игровой зависимости и защите уязвимых пользователей.',
        points: [
          'Компания поддерживает принципы ответственной игры и заботится о благополучии своих клиентов.',
          'Пользователи могут установить лимиты на депозиты, ставки и время игры в настройках аккаунта.',
          'Доступна функция самоисключения на срок от 24 часов до 6 месяцев.',
          'При признаках игровой зависимости компания рекомендует обратиться к специалистам.',
          'Запрещается играть лицам младше 18 лет. Компания проводит проверки возраста.',
          'Реклама не должна побуждать к чрезмерной игре или представлять игру как способ решения финансовых проблем.',
          'Пользователи могут обратиться в службу поддержки за помощью в вопросах ответственной игры.',
          'Компания сотрудничает с организациями, занимающимися проблемами игровой зависимости.',
          'Информация о ресурсах помощи при игровой зависимости размещена на сайте.',
          'Родители могут обратиться за блокировкой доступа несовершеннолетних к сайту.'
        ]
      }
    },
    {
      id: 'privacy',
      title: 'Конфиденциальность и защита данных',
      icon: '🔒',
      content: {
        intro: 'Политика обработки и защиты персональных данных пользователей.',
        points: [
          'Компания обрабатывает персональные данные в соответствии с законодательством о защите персональных данных.',
          'Собираемые данные используются исключительно для предоставления услуг и выполнения обязательств.',
          'Персональные данные не передаются третьим лицам без согласия пользователя, за исключением случаев, предусмотренных законом.',
          'Компания применяет современные технические и организационные меры для защиты данных.',
          'Пользователь имеет право на доступ к своим данным, их исправление или удаление.',
          'Cookies и аналогичные технологии используются для улучшения работы сайта.',
          'Данные банковских карт обрабатываются с использованием защищенных протоколов и не хранятся на серверах компании.',
          'История ставок и игровых операций хранится в течение 5 лет для выполнения требований регулятора.',
          'При обнаружении утечки данных пользователи уведомляются в течение 72 часов.',
          'Обработка данных несовершеннолетних производится только с согласия родителей или законных представителей.'
        ]
      }
    },
    {
      id: 'liability',
      title: 'Ответственность сторон',
      icon: '⚖️',
      content: {
        intro: 'Ограничения ответственности компании и обязанности пользователей.',
        points: [
          'Компания не несет ответственности за технические сбои, не зависящие от неё.',
          'Ответственность компании ограничивается суммой, находящейся на игровом счете пользователя.',
          'Пользователь несет полную ответственность за соблюдение законодательства своей юрисдикции.',
          'Компания не гарантирует бесперебойную работу сайта и может проводить технические работы.',
          'Форс-мажорные обстоятельства освобождают стороны от ответственности за неисполнение обязательств.',
          'Компания не несет ответственности за решения пользователя по размещению ставок.',
          'Убытки, связанные с игровой деятельностью, возмещению не подлежат.',
          'Пользователь обязуется возместить ущерб, причиненный компании в результате нарушения настоящих условий.',
          'Компания не несет ответственности за действия платёжных систем и банков.',
          'Ответственность за уплату налогов с выигрышей лежит на пользователе в соответствии с законодательством.'
        ]
      }
    },
    {
      id: 'termination',
      title: 'Прекращение соглашения',
      icon: '🚪',
      content: {
        intro: 'Условия расторжения соглашения и закрытия аккаунта.',
        points: [
          'Соглашение может быть расторгнуто любой из сторон с уведомлением за 30 дней.',
          'Компания имеет право немедленно заблокировать аккаунт при нарушении условий.',
          'При закрытии аккаунта остаток средств выплачивается пользователю в полном объеме.',
          'Бонусные средства и акционные предложения аннулируются при закрытии аккаунта.',
          'Неразрешенные споры рассматриваются в течение 30 дней после закрытия аккаунта.',
          'Обязательства сторон, возникшие до расторжения, остаются в силе.',
          'Компания сохраняет право на взыскание задолженности после закрытия аккаунта.',
          'Персональные данные удаляются в соответствии с требованиями законодательства.',
          'История транзакций сохраняется для выполнения требований контролирующих органов.',
          'Восстановление закрытого аккаунта возможно только при согласии обеих сторон.'
        ]
      }
    },
    {
      id: 'bonus',
      title: 'Бонусы и акции',
      icon: '🎁',
      content: {
        intro: 'Правила получения и использования бонусов и участия в акциях.',
        points: [
          'Бонусы предоставляются по усмотрению компании и могут быть изменены или отменены в любое время.',
          'Для получения бонуса необходимо выполнить условия соответствующей акции.',
          'Бонусные средства подлежат отыгрышу с определенным вейджером до возможности вывода.',
          'Срок действия бонуса ограничен и указывается в условиях каждой акции.',
          'Злоупотребление бонусными предложениями является основанием для их аннулирования.',
          'Бонусы не суммируются с другими акциями, если не указано иное.',
          'Компания имеет право исключить пользователя из участия в акциях при подозрении в мошенничестве.',
          'Условия отыгрыша могут различаться для разных видов ставок и событий.',
          'Максимальная сумма выигрыша с бонусных средств может быть ограничена.',
          'При нарушении условий акции все бонусные средства и связанные с ними выигрыши аннулируются.'
        ]
      }
    }
  ];

  return (
    <div style={{ 
      display: 'flex', 
      margin: '0 auto', 
      padding: '20px 20px 20px 10px',
      gap: '20px',
      backgroundColor: '#f5f5f5',
      minHeight: '100vh',
      fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      
      <Sidebar />
      
      <div style={{ flex: 1, maxWidth: '1200px' }}>
        
        {/* Page Header */}
        <div style={{ 
          backgroundColor: 'white', 
          borderRadius: '12px', 
          padding: '40px', 
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: 20, 
            justifyContent: 'center',
            marginBottom: 20
          }}>
            <div style={{ 
              width: 60, 
              height: 60, 
              backgroundColor: '#6b0c17', 
              borderRadius: '50%', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center'
            }}>
              <span style={{ fontSize: 28, color: 'white' }}>📋</span>
            </div>
            <h1 style={{ 
              color: '#6b0c17', 
              fontSize: 36, 
              fontWeight: 'bold', 
              margin: 0
            }}>
              Пользовательское соглашение
            </h1>
          </div>
          <p style={{ 
            color: '#666', 
            fontSize: 18, 
            margin: 0,
            lineHeight: 1.6
          }}>
            Внимательно ознакомьтесь с условиями использования наших услуг
          </p>
          <div style={{
            backgroundColor: '#fee2e2',
            color: '#6b0c17',
            padding: '15px',
            borderRadius: '8px',
            marginTop: '20px',
            fontSize: '14px',
            fontWeight: '500'
          }}>
            <strong>Последнее обновление:</strong> {new Date().toLocaleDateString('ru-RU')} | <strong>Версия:</strong> 2.1
          </div>
        </div>

        <div style={{ display: 'flex', gap: '30px' }}>
          {/* Navigation Sidebar */}
          <div style={{
            width: '300px',
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '20px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
            height: 'fit-content',
            position: 'sticky',
            top: '20px'
          }}>
            <h3 style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '20px',
              textAlign: 'center'
            }}>
              Разделы соглашения
            </h3>
            
            {termsSections.map((section, index) => (
              <div
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 15px',
                  marginBottom: '8px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  backgroundColor: activeSection === section.id ? '#6b0c17' : 'transparent',
                  color: activeSection === section.id ? 'white' : '#333'
                }}
                onMouseEnter={(e) => {
                  if (activeSection !== section.id) {
                    e.currentTarget.style.backgroundColor = '#f8f9fa';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeSection !== section.id) {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }
                }}
              >
                <div style={{
                  fontSize: '18px',
                  minWidth: '20px'
                }}>
                  {section.icon}
                </div>
                <div>
                  <div style={{
                    fontSize: '13px',
                    fontWeight: 'bold',
                    lineHeight: 1.2
                  }}>
                    {section.title}
                  </div>
                  <div style={{
                    fontSize: '11px',
                    opacity: 0.8,
                    marginTop: '2px'
                  }}>
                    Раздел {index + 1}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Content Area */}
          <div style={{ flex: 1 }}>
            {termsSections
              .filter(section => section.id === activeSection)
              .map((section) => (
                <div key={section.id} style={{
                  backgroundColor: 'white',
                  borderRadius: '12px',
                  padding: '40px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }}>
                  {/* Section Header */}
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '15px',
                    marginBottom: '30px',
                    paddingBottom: '20px',
                    borderBottom: '2px solid #f1f5f9'
                  }}>
                    <div style={{
                      width: '50px',
                      height: '50px',
                      backgroundColor: '#6b0c17',
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '24px'
                    }}>
                      {section.icon}
                    </div>
                    <div>
                      <h2 style={{
                        fontSize: '28px',
                        fontWeight: 'bold',
                        color: '#6b0c17',
                        margin: '0 0 5px 0'
                      }}>
                        {section.title}
                      </h2>
                      <div style={{
                        fontSize: '14px',
                        color: '#666'
                      }}>
                        {section.content.intro}
                      </div>
                    </div>
                  </div>

                  {/* Section Content */}
                  <div style={{
                    fontSize: '16px',
                    lineHeight: 1.7,
                    color: '#333'
                  }}>
                    {section.content.points.map((point, pointIndex) => (
                      <div
                        key={pointIndex}
                        style={{
                          display: 'flex',
                          alignItems: 'flex-start',
                          marginBottom: '20px',
                          padding: '15px',
                          backgroundColor: pointIndex % 2 === 0 ? '#f8f9fa' : 'transparent',
                          borderRadius: '8px',
                          border: '1px solid transparent',
                          transition: 'all 0.3s ease'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = '#6b0c17';
                          e.currentTarget.style.backgroundColor = '#fef7f7';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = 'transparent';
                          e.currentTarget.style.backgroundColor = pointIndex % 2 === 0 ? '#f8f9fa' : 'transparent';
                        }}
                      >
                        <div style={{
                          minWidth: '30px',
                          height: '30px',
                          borderRadius: '50%',
                          backgroundColor: '#6b0c17',
                          color: 'white',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '14px',
                          fontWeight: 'bold',
                          marginRight: '15px',
                          marginTop: '2px'
                        }}>
                          {pointIndex + 1}
                        </div>
                        <div style={{
                          flex: 1,
                          fontSize: '15px',
                          lineHeight: 1.6
                        }}>
                          {point}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Section Footer */}
                  <div style={{
                    marginTop: '40px',
                    padding: '20px',
                    backgroundColor: '#f1f5f9',
                    borderRadius: '10px',
                    borderLeft: '4px solid #6b0c17'
                  }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      marginBottom: '10px'
                    }}>
                      <span style={{ fontSize: '20px' }}>ℹ️</span>
                      <strong style={{ color: '#6b0c17' }}>Важная информация</strong>
                    </div>
                    <p style={{
                      fontSize: '14px',
                      color: '#555',
                      margin: 0,
                      lineHeight: 1.5
                    }}>
                      При возникновении вопросов по данному разделу обращайтесь в службу поддержки клиентов. 
                      Все спорные ситуации рассматриваются в индивидуальном порядке с учетом обстоятельств дела.
                    </p>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Agreement Footer */}
        <div style={{
          backgroundColor: '#6b0c17',
          color: 'white',
          borderRadius: '12px',
          padding: '30px',
          marginTop: '30px',
          textAlign: 'center'
        }}>
          <h3 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            marginBottom: '15px'
          }}>
            Согласие с условиями
          </h3>
          <p style={{
            fontSize: '16px',
            marginBottom: '25px',
            opacity: 0.9,
            lineHeight: 1.6
          }}>
            Регистрируясь на сайте или используя наши услуги, вы подтверждаете, что ознакомились 
            с настоящими условиями и согласны их соблюдать.
          </p>
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '20px',
            flexWrap: 'wrap'
          }}>
            <button
              onClick={() => window.open('/support', '_blank')}
              style={{
                backgroundColor: 'white',
                color: '#6b0c17',
                border: 'none',
                padding: '12px 25px',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: 'bold',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(255,255,255,0.3)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              Связаться с поддержкой
            </button>
            <button
              onClick={() => window.print()}
              style={{
                backgroundColor: 'transparent',
                color: 'white',
                border: '2px solid white',
                padding: '12px 25px',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: 'bold',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'white';
                e.currentTarget.style.color = '#6b0c17';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
                e.currentTarget.style.color = 'white';
              }}
            >
              Скачать PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsConditions; 