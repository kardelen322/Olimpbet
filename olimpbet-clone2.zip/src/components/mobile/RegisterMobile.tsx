import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';
import { FaEye, FaEyeSlash, FaLock, FaUser, FaPhone } from 'react-icons/fa';

// Cast icons as React components
const PhoneIcon = FaPhone as React.ComponentType<React.SVGProps<SVGSVGElement>>;
const LockIcon = FaLock as React.ComponentType<React.SVGProps<SVGSVGElement>>;
const UserIcon = FaUser as React.ComponentType<React.SVGProps<SVGSVGElement>>;
const EyeIcon = FaEye as React.ComponentType<React.SVGProps<SVGSVGElement>>;
const EyeSlashIcon = FaEyeSlash as React.ComponentType<React.SVGProps<SVGSVGElement>>;

// Add keyframes for spinner animation
const spinKeyframes = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;

// Add the style to the document
if (typeof document !== 'undefined') {
  const styleElement = document.createElement('style');
  styleElement.innerHTML = spinKeyframes;
  document.head.appendChild(styleElement);
}

interface RegisterMobileProps {
  onLoginClick?: () => void;
}

const RegisterMobile: React.FC<RegisterMobileProps> = ({ onLoginClick }) => {
  const { translate, isRTL } = useLanguage();
  const { register, error, loading } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    phone: '',
    password: '',
    confirmPassword: '',
    username: '',
    agreeToTerms: false
  });
  
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [capsLockOn, setCapsLockOn] = useState(false);

  const handleKeyPress = (e: React.KeyboardEvent) => {
    const capsLockOn = e.getModifierState('CapsLock');
    setCapsLockOn(capsLockOn);
  };
  
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  
  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.phone.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!/^\d{10,15}$/.test(formData.phone.trim())) {
      errors.phone = 'Please enter a valid phone number';
    }
    
    // Email validation removed as requested
    
    if (!formData.password) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }
    
    if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    
    if (!formData.agreeToTerms) {
      errors.agreeToTerms = 'You must agree to the terms and conditions';
    }
    
    return errors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    
    // Clear previous errors
    setFormErrors({});
    
    // Prepare data for registration
    const { confirmPassword, agreeToTerms, ...registrationData } = formData;
    
    // Attempt registration
    const success = await register(registrationData, formData.password);
    if (success) {
      navigate('/');
    }
  };

  const handleLoginClick = () => {
    if (onLoginClick) {
      onLoginClick();
    } else {
      navigate('/login');
    }
  };

  return (
    <div className="register-mobile-container" style={styles.container} dir={isRTL ? 'rtl' : 'ltr'}>
      <h1 style={styles.title}>{translate('register')}</h1>
      
      <form onSubmit={handleSubmit} style={styles.form}>
        {error && (
          <div style={styles.errorMessage}>
            {error}
          </div>
        )}
        
        <div style={styles.welcomeText}>
          <h3 style={styles.welcomeTitle}>{translate('createAccount') || 'Create Your Account'}</h3>
          <p style={styles.welcomeSubtitle}>{translate('joinCommunity') || 'Join our community and start betting today'}</p>
        </div>
        
        <div style={styles.inputGroup}>
          <label htmlFor="phone-mobile" style={styles.label}>
            {translate('phone')} *
          </label>
          <div style={styles.inputWrapper}>
            <span style={styles.inputIcon}>
              <PhoneIcon color="#6b0c17" />
            </span>
            <input
              id="phone-mobile"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleChange}
              placeholder="+1 (123) 456-7890"
              style={formErrors.phone ? {...styles.inputWithIcon, ...styles.inputError} : styles.inputWithIcon}
              disabled={loading}
            />
          </div>
          {formErrors.phone && (
            <div style={styles.fieldError}>{formErrors.phone}</div>
          )}
        </div>
        
        <div style={styles.inputGroup}>
          <label htmlFor="password-mobile" style={styles.label}>
            {translate('password')} *
          </label>
          <div style={styles.inputWrapper}>
            <span style={styles.inputIcon}>
              <LockIcon color="#6b0c17" />
            </span>
            <input
              id="password-mobile"
              name="password"
              type={showPassword ? "text" : "password"}
              value={formData.password}
              onChange={handleChange}
              onKeyDown={handleKeyPress}
              placeholder="••••••••"
              style={formErrors.password ? {...styles.inputWithIcon, ...styles.inputError} : styles.inputWithIcon}
              disabled={loading}
            />
            <button 
              type="button" 
              onClick={togglePasswordVisibility} 
              style={styles.passwordToggle}
              tabIndex={-1}
            >
              {showPassword ? <EyeSlashIcon color="#6b0c17" /> : <EyeIcon color="#6b0c17" />}
            </button>
          </div>
          {capsLockOn && (
            <div style={styles.capsLockWarning}>Caps Lock is ON</div>
          )}
          {formErrors.password && (
            <div style={styles.fieldError}>{formErrors.password}</div>
          )}
          <div style={styles.passwordHint}>
            {translate('passwordRequirements') || 'Password must be at least 6 characters'}
          </div>
        </div>
        
        <div style={styles.inputGroup}>
          <label htmlFor="confirmPassword-mobile" style={styles.label}>
            {translate('confirmPassword') || 'Confirm Password'} *
          </label>
          <div style={styles.inputWrapper}>
            <span style={styles.inputIcon}>
              <LockIcon color="#6b0c17" />
            </span>
            <input
              id="confirmPassword-mobile"
              name="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              value={formData.confirmPassword}
              onChange={handleChange}
              onKeyDown={handleKeyPress}
              placeholder="••••••••"
              style={formErrors.confirmPassword ? {...styles.inputWithIcon, ...styles.inputError} : styles.inputWithIcon}
              disabled={loading}
            />
            <button 
              type="button" 
              onClick={toggleConfirmPasswordVisibility} 
              style={styles.passwordToggle}
              tabIndex={-1}
            >
              {showConfirmPassword ? <EyeSlashIcon color="#6b0c17" /> : <EyeIcon color="#6b0c17" />}
            </button>
          </div>
          {capsLockOn && (
            <div style={styles.capsLockWarning}>Caps Lock is ON</div>
          )}
          {formErrors.confirmPassword && (
            <div style={styles.fieldError}>{formErrors.confirmPassword}</div>
          )}
        </div>
        
        <div style={styles.inputGroup}>
          <label htmlFor="username-mobile" style={styles.label}>
            {translate('username')} ({translate('optional') || 'Optional'})
          </label>
          <div style={styles.inputWrapper}>
            <span style={styles.inputIcon}>
              <UserIcon color="#6b0c17" />
            </span>
            <input
              id="username-mobile"
              name="username"
              type="text"
              value={formData.username}
              onChange={handleChange}
              placeholder="JohnDoe"
              style={formErrors.username ? {...styles.inputWithIcon, ...styles.inputError} : styles.inputWithIcon}
              disabled={loading}
            />
          </div>
          {formErrors.username && (
            <div style={styles.fieldError}>{formErrors.username}</div>
          )}
        </div>
        
        <div style={styles.checkboxGroup}>
          <input
            id="agreeToTerms-mobile"
            name="agreeToTerms"
            type="checkbox"
            checked={formData.agreeToTerms}
            onChange={handleChange}
            disabled={loading}
            style={styles.checkbox}
          />
          <label htmlFor="agreeToTerms-mobile" style={styles.checkboxLabel}>
            {translate('agreeToTerms') || 'I agree to the Terms and Conditions'} *
          </label>
        </div>
        {formErrors.agreeToTerms && (
          <div style={styles.fieldError}>{formErrors.agreeToTerms}</div>
        )}
        
        <button 
          type="submit" 
          style={styles.submitButton}
          disabled={loading}
        >
          {loading ? (
            <span style={styles.loadingSpinner}></span>
          ) : (
            translate('register')
          )}
        </button>
        
        <div style={styles.loginPrompt}>
          <span>{translate('alreadyHaveAccount') || 'Already have an account?'}</span>
          <button 
            type="button" 
            onClick={handleLoginClick}
            style={styles.loginLink}
            disabled={loading}
          >
            {translate('login')}
          </button>
        </div>
      </form>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: '#fff',
    padding: '20px',
    width: '100%',
    boxSizing: 'border-box' as const,
  },
  title: {
    color: '#6b0c17',
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '20px',
    textAlign: 'center' as const,
  },
  form: {
    width: '100%',
  },
  welcomeText: {
    textAlign: 'center' as const,
    marginBottom: '24px',
  },
  welcomeTitle: {
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#333',
    margin: '0 0 8px 0',
  },
  welcomeSubtitle: {
    fontSize: '14px',
    color: '#666',
    margin: 0,
  },
  errorMessage: {
    backgroundColor: '#ffebee',
    color: '#d32f2f',
    padding: '10px',
    borderRadius: '4px',
    marginBottom: '16px',
    fontSize: '14px',
  },
  inputGroup: {
    marginBottom: '16px',
  },
  label: {
    display: 'block',
    marginBottom: '6px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
  },
  inputWrapper: {
    position: 'relative' as const,
    display: 'flex',
    alignItems: 'center',
  },
  inputIcon: {
    position: 'absolute' as const,
    left: '12px',
    top: '50%',
    transform: 'translateY(-50%)',
    color: '#6b0c17',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    width: '100%',
    padding: '12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '16px',
    boxSizing: 'border-box' as const,
  },
  inputWithIcon: {
    width: '100%',
    padding: '14px 12px 14px 40px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '16px',
    boxSizing: 'border-box' as const,
    transition: 'border-color 0.2s',
  },
  inputError: {
    borderColor: '#d32f2f',
  },
  fieldError: {
    color: '#d32f2f',
    fontSize: '12px',
    marginTop: '4px',
  },
  passwordToggle: {
    position: 'absolute' as const,
    right: '12px',
    top: '50%',
    transform: 'translateY(-50%)',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '0',
  },
  capsLockWarning: {
    color: '#ff9800',
    fontSize: '12px',
    marginTop: '4px',
  },
  passwordHint: {
    color: '#666',
    fontSize: '12px',
    marginTop: '4px',
  },
  checkboxGroup: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '16px',
  },
  checkbox: {
    width: '18px',
    height: '18px',
    accentColor: '#6b0c17',
  },
  checkboxLabel: {
    marginLeft: '8px',
    fontSize: '14px',
    color: '#333',
  },
  submitButton: {
    width: '100%',
    padding: '14px',
    backgroundColor: '#6b0c17',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    marginTop: '10px',
    position: 'relative' as const,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingSpinner: {
    width: '20px',
    height: '20px',
    border: '2px solid rgba(255, 255, 255, 0.3)',
    borderRadius: '50%',
    borderTopColor: '#fff',
    animation: 'spin 1s linear infinite',
  },
  loginPrompt: {
    marginTop: '20px',
    textAlign: 'center' as const,
    fontSize: '14px',
    color: '#666',
  },
  loginLink: {
    background: 'none',
    border: 'none',
    color: '#6b0c17',
    fontWeight: 'bold',
    cursor: 'pointer',
    marginLeft: '5px',
    fontSize: '14px',
  },
};

export default RegisterMobile;