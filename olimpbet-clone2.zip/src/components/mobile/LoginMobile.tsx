import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';

interface LoginMobileProps {
  onRegisterClick?: () => void;
}

const LoginMobile: React.FC<LoginMobileProps> = ({ onRegisterClick }) => {
  const { translate, isRTL } = useLanguage();
  const { login, error, loading } = useAuth();
  const navigate = useNavigate();
  
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    
    // Validate form
    if (!phone.trim()) {
      setFormError('Phone number is required');
      return;
    }
    
    // Basic phone number validation
    if (!/^\d{10,15}$/.test(phone.trim())) {
      setFormError('Please enter a valid phone number');
      return;
    }
    
    if (!password) {
      setFormError('Password is required');
      return;
    }
    
    // Attempt login
    const success = await login(phone, password);
    if (success) {
      navigate('/');
    }
  };

  const handleRegisterClick = () => {
    if (onRegisterClick) {
      onRegisterClick();
    } else {
      navigate('/register');
    }
  };

  return (
    <div className="login-mobile-container" style={styles.container} dir={isRTL ? 'rtl' : 'ltr'}>
      <h1 style={styles.title}>{translate('login')}</h1>
      
      <form onSubmit={handleSubmit} style={styles.form}>
        {(formError || error) && (
          <div style={styles.errorMessage}>
            {formError || error}
          </div>
        )}
        
        <div style={styles.inputGroup}>
          <label htmlFor="phone" style={styles.label}>
            {translate('phone')}
          </label>
          <input
            id="phone"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            style={styles.input}
            placeholder={translate('phone')}
            disabled={loading}
          />
        </div>
        
        <div style={styles.inputGroup}>
          <label htmlFor="password-mobile" style={styles.label}>
            {translate('password')}
          </label>
          <input
            id="password-mobile"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={styles.input}
            placeholder={translate('password')}
            disabled={loading}
          />
        </div>
        
        <button 
          type="submit" 
          style={styles.submitButton}
          disabled={loading}
        >
          {loading ? '...' : translate('login')}
        </button>
        
        <div style={styles.registerPrompt}>
          <span>{translate('dontHaveAccount') || "Don't have an account?"}</span>
          <button 
            type="button" 
            onClick={handleRegisterClick}
            style={styles.registerLink}
            disabled={loading}
          >
            {translate('register')}
          </button>
        </div>
      </form>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: '#fff',
    padding: '20px',
    width: '100%',
    boxSizing: 'border-box' as const,
  },
  title: {
    color: '#6b0c17',
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '20px',
    textAlign: 'center' as const,
  },
  form: {
    width: '100%',
  },
  errorMessage: {
    backgroundColor: '#ffebee',
    color: '#d32f2f',
    padding: '10px',
    borderRadius: '4px',
    marginBottom: '16px',
    fontSize: '14px',
  },
  inputGroup: {
    marginBottom: '16px',
  },
  label: {
    display: 'block',
    marginBottom: '6px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
  },
  input: {
    width: '100%',
    padding: '12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '16px',
    boxSizing: 'border-box' as const,
  },
  submitButton: {
    width: '100%',
    padding: '14px',
    backgroundColor: '#6b0c17',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    marginTop: '10px',
  },
  registerPrompt: {
    marginTop: '20px',
    textAlign: 'center' as const,
    fontSize: '14px',
    color: '#666',
  },
  registerLink: {
    background: 'none',
    border: 'none',
    color: '#6b0c17',
    fontWeight: 'bold',
    cursor: 'pointer',
    marginLeft: '5px',
    fontSize: '14px',
  },
};

export default LoginMobile;