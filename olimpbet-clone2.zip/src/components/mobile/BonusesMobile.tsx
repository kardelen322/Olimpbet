import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type BonusCategory = 'all' | 'welcome' | 'deposit' | 'cashback';

type Bonus = {
  title: string;
  description: string;
  category: BonusCategory;
  maxBonus: string;
  validUntil: string;
  promoCode?: string;
  conditions: string[];
};

const BonusesMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<BonusCategory>('all');

  const generateBonuses = (): Bonus[] => {
    // Type-safe bonus generation with fallback
    const activePromotions = (mockData as any).bonuses?.activePromotions || [];
    
    return activePromotions.map((promo: any) => ({
      title: promo.title || 'Unnamed Bonus',
      description: promo.description || '',
      category: promo.category || 'all',
      maxBonus: promo.maxBonus || '0 ₽',
      validUntil: promo.validUntil || 'Не указано',
      promoCode: activePromotions.find((p: any) => p.title === promo.title)?.code || '',
      conditions: promo.conditions || [
        'Минимальный депозит: 500 ₽',
        'Wagering: 35x'
      ]
    }));
  };

  const bonuses = generateBonuses();

  const filterBonusesByCategory = (bonusesToFilter: Bonus[]): Bonus[] => {
    if (activeCategory === 'all') return bonusesToFilter;
    return bonusesToFilter.filter(bonus => bonus.category === activeCategory);
  };

  const filteredBonuses = filterBonusesByCategory(bonuses);

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Page Header */}
      <div style={{
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '12px',
        marginBottom: '15px',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
        textAlign: 'center'
      }}>
        <h1 style={{
          fontSize: '24px',
          fontWeight: 'bold',
          color: '#6b0c17',
          margin: '0 0 10px 0'
        }}>
          {translate('bonuses')}
        </h1>
        <p style={{
          fontSize: '14px',
          color: '#666',
          margin: '0'
        }}>
          Актуальные бонусы и акции
        </p>
      </div>

      {/* Bonus Categories */}
      <div style={{
        backgroundColor: 'white',
        borderRadius: '12px',
        marginBottom: '15px',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
        overflowX: 'auto',
        whiteSpace: 'nowrap',
        padding: '10px 0'
      }}>
        {/* Bonus Categories */}
        {/* VIP Program */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          marginBottom: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '15px'
          }}>
            VIP Программа
          </h2>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '10px'
          }}>
            {mockData.bonuses.vipProgram.levels.map((level, index) => (
              <div 
                key={index}
                style={{
                  backgroundColor: '#f8f9fa',
                  borderRadius: '10px',
                  padding: '15px',
                  textAlign: 'center',
                  border: `2px solid ${
                    level.name === 'Платина' ? '#6b0c17' : 
                    level.name === 'Золото' ? '#FFD700' : 
                    level.name === 'Серебро' ? '#C0C0C0' : 
                    '#CD7F32'
                  }`
                }}
              >
                <div style={{
                  fontSize: '20px',
                  fontWeight: 'bold',
                  color: '#6b0c17',
                  marginBottom: '10px'
                }}>
                  {level.name}
                </div>
                <div style={{
                  fontSize: '14px',
                  color: '#666',
                  marginBottom: '5px'
                }}>
                  Мин. депозит: {level.minDeposit}
                </div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: '#22c55e'
                }}>
                  Кэшбек: {level.cashbackPercent}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bonuses List */}
        <div 
          style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '15px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}
        >
          <h2 
            style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '15px'
            }}
          >
            Доступные бонусы
          </h2>
          
          {filteredBonuses.length === 0 ? (
            <div 
              style={{
                textAlign: 'center',
                color: '#666',
                padding: '20px'
              }}
            >
              Нет доступных бонусов в этой категории
            </div>
          ) : (
            filteredBonuses.map((bonus, index) => (
              <div 
                key={index}
                style={{
                  backgroundColor: '#f9fafb',
                  borderRadius: '8px',
                  padding: '15px',
                  marginBottom: '10px',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
                }}
              >
                <div 
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '10px'
                  }}
                >
                  <h3 
                    style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#6b0c17',
                      margin: 0
                    }}
                  >
                    {bonus.title}
                  </h3>
                  {bonus.promoCode && (
                    <span 
                      style={{
                        backgroundColor: '#e5e7eb',
                        color: '#666',
                        fontSize: '12px',
                        padding: '4px 8px',
                        borderRadius: '4px'
                      }}
                    >
                      {bonus.promoCode}
                    </span>
                  )}
                </div>
                
                <p 
                  style={{
                    fontSize: '14px',
                    color: '#333',
                    marginBottom: '10px'
                  }}
                >
                  {bonus.description}
                </p>
                
                <div 
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <div 
                    style={{
                      fontSize: '14px',
                      color: '#666'
                    }}
                  >
                    Макс. бонус: {bonus.maxBonus}
                  </div>
                  <div 
                    style={{
                      fontSize: '12px',
                      color: '#999'
                    }}
                  >
                    Действителен до: {bonus.validUntil}
                  </div>
                </div>
                
                {bonus.conditions && bonus.conditions.length > 0 && (
                  <div 
                    style={{
                      marginTop: '10px',
                      borderTop: '1px solid #e5e7eb',
                      paddingTop: '10px'
                    }}
                  >
                    <h4 
                      style={{
                        fontSize: '14px',
                        fontWeight: 'bold',
                        color: '#6b0c17',
                        marginBottom: '5px'
                      }}
                    >
                      Условия:
                    </h4>
                    <ul 
                      style={{
                        paddingLeft: '20px',
                        margin: 0,
                        fontSize: '12px',
                        color: '#666'
                      }}
                    >
                      {bonus.conditions.map((condition, condIndex) => (
                        <li key={condIndex}>{condition}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default BonusesMobile; 