import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type SupportCategory = {
  title: string;
  icon: string;
  actions: {
    title: string;
    description: string;
    icon: string;
  }[];
};

type QuickAction = {
  title: string;
  icon: string;
  description: string;
};

const SupportMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const generateSupportCategories = (): SupportCategory[] => {
    // Type-safe support categories generation with fallback
    const supportData = (mockData as any).support || {};
    const categories = supportData.categories || [];

    return categories.map((category: any) => ({
      title: category.title || 'Unnamed Category',
      icon: category.icon || '❓',
      actions: (category.actions || []).map((action: any) => ({
        title: action.title || 'Unnamed Action',
        description: action.description || 'No description available',
        icon: action.icon || '❓'
      }))
    }));
  };

  const generateQuickActions = (): QuickAction[] => {
    // Type-safe quick actions generation with fallback
    const supportData = (mockData as any).support || {};
    const quickActions = supportData.quickActions || [];

    return quickActions.map((action: any) => ({
      title: action.title || 'Unnamed Action',
      icon: action.icon || '❓',
      description: action.description || 'No description available'
    }));
  };

  const supportCategories = generateSupportCategories();
  const quickActions = generateQuickActions();

  const toggleCategory = (title: string) => {
    setActiveCategory(activeCategory === title ? null : title);
  };

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Quick Actions Section */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          marginBottom: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          Быстрые действия
        </h2>
        
        <div 
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '10px',
            justifyContent: 'space-between'
          }}
        >
          {quickActions.map((action, index) => (
            <div 
              key={index}
              style={{
                backgroundColor: '#f9fafb',
                borderRadius: '8px',
                padding: '12px',
                width: 'calc(50% - 5px)',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
              }}
            >
              <div 
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  marginBottom: '10px'
                }}
              >
                <span 
                  style={{ 
                    fontSize: '24px', 
                    marginRight: '10px' 
                  }}
                >
                  {action.icon}
                </span>
                <h3 
                  style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    color: '#6b0c17',
                    margin: 0
                  }}
                >
                  {action.title}
                </h3>
              </div>
              <p 
                style={{
                  fontSize: '14px',
                  color: '#666',
                  margin: 0
                }}
              >
                {action.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Support Categories */}
      {supportCategories.map((category, categoryIndex) => (
        <div 
          key={categoryIndex}
          style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            marginBottom: '15px',
            overflow: 'hidden',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}
        >
          {/* Category Header */}
          <div 
            onClick={() => toggleCategory(category.title)}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '15px',
              backgroundColor: '#f9fafb',
              cursor: 'pointer'
            }}
          >
            <div 
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '15px'
              }}
            >
              <span 
                style={{ 
                  fontSize: '24px' 
                }}
              >
                {category.icon}
              </span>
              <h2 
                style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#6b0c17',
                  margin: 0
                }}
              >
                {category.title}
              </h2>
            </div>
            <span 
              style={{ 
                fontSize: '20px', 
                color: '#6b0c17' 
              }}
            >
              {activeCategory === category.title ? '▼' : '►'}
            </span>
          </div>

          {/* Category Actions */}
          {activeCategory === category.title && (
            <div 
              style={{
                padding: '15px',
                backgroundColor: 'white'
              }}
            >
              {category.actions.map((action, actionIndex) => (
                <div 
                  key={actionIndex}
                  style={{
                    backgroundColor: '#f9fafb',
                    borderRadius: '8px',
                    padding: '12px',
                    marginBottom: '10px'
                  }}
                >
                  <div 
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      marginBottom: '10px'
                    }}
                  >
                    <span 
                      style={{ 
                        fontSize: '24px', 
                        marginRight: '10px' 
                      }}
                    >
                      {action.icon}
                    </span>
                    <h3 
                      style={{
                        fontSize: '16px',
                        fontWeight: 'bold',
                        color: '#6b0c17',
                        margin: 0
                      }}
                    >
                      {action.title}
                    </h3>
                  </div>
                  <p 
                    style={{
                      fontSize: '14px',
                      color: '#666',
                      margin: 0
                    }}
                  >
                    {action.description}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      {/* Contact Information */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          Контактная информация
        </h2>
        
        <div 
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '10px'
          }}
        >
          <div 
            style={{
              backgroundColor: '#f9fafb',
              borderRadius: '8px',
              padding: '12px',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            <span 
              style={{ 
                fontSize: '24px', 
                marginRight: '10px' 
              }}
            >
              📞
            </span>
            <div>
              <h3 
                style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: '#6b0c17',
                  margin: 0
                }}
              >
                Служба поддержки
              </h3>
              <p 
                style={{
                  fontSize: '14px',
                  color: '#666',
                  margin: 0
                }}
              >
                +7 (800) 555-35-35
              </p>
            </div>
          </div>
          
          <div 
            style={{
              backgroundColor: '#f9fafb',
              borderRadius: '8px',
              padding: '12px',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            <span 
              style={{ 
                fontSize: '24px', 
                marginRight: '10px' 
              }}
            >
              ✉️
            </span>
            <div>
              <h3 
                style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: '#6b0c17',
                  margin: 0
                }}
              >
                Электронная почта
              </h3>
              <p 
                style={{
                  fontSize: '14px',
                  color: '#666',
                  margin: 0
                }}
              >
                support@olimpbet.com
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportMobile; 