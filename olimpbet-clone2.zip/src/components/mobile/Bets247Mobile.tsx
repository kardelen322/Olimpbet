import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type BetCategory = 'all' | 'sports' | 'casino' | 'live' | 'virtual';

type BetOdds = {
  home: number;
  away: number;
  draw?: number;
};

type Bet = {
  id: number;
  title: string;
  category: BetCategory;
  description: string;
  minBet: number;
  maxBet: number;
  coefficient: number;
  icon: string;
  color: string;
  details: string[];
  conditions: string[];
  currentOdds?: BetOdds;
};

const Bets247Mobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<BetCategory>('all');

  const generateBets = (category: BetCategory): Bet[] => {
    const betsData: Record<BetCategory, Bet[]> = {
      all: [
        {
          id: 1,
          title: 'Футбол: Зенит - ЦСКА',
          category: 'sports',
          description: 'Матч Российской Премьер-лиги',
          minBet: 10,
          maxBet: 5000,
          coefficient: 1.85,
          icon: '⚽',
          color: '#6b0c17',
          details: ['Исход матча', 'Тоталы', 'Форы'],
          conditions: ['Ставка принимается до начала матча'],
          currentOdds: { home: 2.1, away: 1.9, draw: 3.2 }
        },
        {
          id: 2,
          title: 'Рулетка Х2',
          category: 'casino',
          description: 'Классическая европейская рулетка',
          minBet: 5,
          maxBet: 1000,
          coefficient: 35,
          icon: '🎲',
          color: '#228B22',
          details: ['Ставка на число', 'Ставка на цвет', 'Ставка на группу чисел'],
          conditions: ['Минимальная ставка 5 рублей']
        },
        {
          id: 3,
          title: 'Баскетбол: NBA Live',
          category: 'live',
          description: 'Текущий матч NBA',
          minBet: 20,
          maxBet: 3000,
          coefficient: 1.95,
          icon: '🏀',
          color: '#1E90FF',
          details: ['Исход четверти', 'Тоталы', 'Индивидуальный тотал'],
          conditions: ['Ставки в реальном времени'],
          currentOdds: { home: 1.8, away: 2.1 }
        }
      ],
      sports: [
        {
          id: 4,
          title: 'Теннис: Australian Open',
          category: 'sports',
          description: 'Четвертьфинал мужского турнира',
          minBet: 15,
          maxBet: 2000,
          coefficient: 2.05,
          icon: '🎾',
          color: '#FF4500',
          details: ['Победитель матча', 'Сет-тоталы', 'Гейм-форы'],
          conditions: ['Ставка до начала матча'],
          currentOdds: { home: 1.6, away: 2.4 }
        }
      ],
      casino: [
        {
          id: 5,
          title: 'Блэкджек VIP',
          category: 'casino',
          description: 'Премиум стол для профессионалов',
          minBet: 100,
          maxBet: 10000,
          coefficient: 3,
          icon: '♠️',
          color: '#8B0000',
          details: ['Классический блэкджек', 'Страховка', 'Дабл даун'],
          conditions: ['Высокие ставки, высокий выигрыш']
        }
      ],
      live: [
        {
          id: 6,
          title: 'Хоккей: КХЛ Live',
          category: 'live',
          description: 'Текущий матч Континентальной хоккейной лиги',
          minBet: 25,
          maxBet: 4000,
          coefficient: 1.75,
          icon: '🏒',
          color: '#4169E1',
          details: ['Исход периода', 'Тоталы', 'Форы'],
          conditions: ['Ставки во время матча'],
          currentOdds: { home: 2.0, away: 1.9 }
        }
      ],
      virtual: [
        {
          id: 7,
          title: 'Виртуальный Футбол',
          category: 'virtual',
          description: 'Симуляция футбольного матча',
          minBet: 5,
          maxBet: 500,
          coefficient: 2.2,
          icon: '🤖',
          color: '#32CD32',
          details: ['Исход матча', 'Тоталы', 'Случайный результат'],
          conditions: ['Быстрые виртуальные матчи каждые 3 минуты']
        }
      ]
    };

    return category === 'all' 
      ? betsData[category]
      : betsData[category] || [];
  };

  const bets = generateBets(activeCategory);

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Bet Category Selection */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          marginBottom: '15px',
          backgroundColor: 'white',
          borderRadius: '20px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        {(['all', 'sports', 'casino', 'live', 'virtual'] as BetCategory[]).map(category => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            style={{
              backgroundColor: activeCategory === category ? '#6b0c17' : 'transparent',
              color: activeCategory === category ? 'white' : '#666',
              border: 'none',
              borderRadius: '15px',
              padding: '8px 15px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            {category === 'all' ? 'Все' : 
             category === 'sports' ? 'Спорт' : 
             category === 'casino' ? 'Казино' : 
             category === 'live' ? 'Лайв' : 
             'Виртуал'}
          </button>
        ))}
      </div>

      {/* Bets List */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          {activeCategory === 'all' ? 'Все ставки' : 
           activeCategory === 'sports' ? 'Спортивные ставки' : 
           activeCategory === 'casino' ? 'Казино' : 
           activeCategory === 'live' ? 'Лайв ставки' : 
           'Виртуальные ставки'}
        </h2>

        {bets.length === 0 ? (
          <div 
            style={{
              textAlign: 'center',
              color: '#666',
              padding: '20px'
            }}
          >
            Нет доступных ставок
          </div>
        ) : (
          bets.map((bet, index) => (
            <div 
              key={index}
              style={{
                backgroundColor: '#f9fafb',
                borderRadius: '8px',
                padding: '15px',
                marginBottom: '10px',
                display: 'flex',
                flexDirection: 'column',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
                borderLeft: `5px solid ${bet.color}`
              }}
            >
              {/* Bet Header */}
              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '10px'
                }}
              >
                <div 
                  style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    color: bet.color
                  }}
                >
                  {bet.title}
                </div>
                <div 
                  style={{
                    backgroundColor: '#e5e7eb',
                    color: '#666',
                    padding: '4px 8px',
                    borderRadius: '4px',
                    fontSize: '12px'
                  }}
                >
                  {bet.category.toUpperCase()}
                </div>
              </div>

              {/* Bet Details */}
              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '10px'
                }}
              >
                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px'
                  }}
                >
                  <span 
                    style={{ 
                      fontSize: '24px' 
                    }}
                  >
                    {bet.icon}
                  </span>
                  <div>
                    <div 
                      style={{
                        fontSize: '14px',
                        color: '#666'
                      }}
                    >
                      {bet.description}
                    </div>
                  </div>
                </div>

                <div 
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-end'
                  }}
                >
                  <div 
                    style={{
                      fontSize: '14px',
                      color: '#666'
                    }}
                  >
                    Коэф: {bet.coefficient.toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Bet Conditions */}
              <div 
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '5px',
                  marginBottom: '10px'
                }}
              >
                {bet.details.map((detail, idx) => (
                  <span 
                    key={idx}
                    style={{
                      backgroundColor: '#e5e7eb',
                      color: '#666',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      fontSize: '12px'
                    }}
                  >
                    {detail}
                  </span>
                ))}
              </div>

              {/* Betting Odds */}
              {bet.currentOdds && (
                <div 
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <div 
                    style={{
                      display: 'flex',
                      gap: '10px'
                    }}
                  >
                    <span 
                      style={{
                        backgroundColor: '#e5e7eb',
                        color: '#666',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}
                    >
                      1: {bet.currentOdds.home.toFixed(2)}
                    </span>
                    {bet.currentOdds.draw && (
                      <span 
                        style={{
                          backgroundColor: '#e5e7eb',
                          color: '#666',
                          padding: '4px 8px',
                          borderRadius: '4px',
                          fontSize: '12px'
                        }}
                      >
                        X: {bet.currentOdds.draw.toFixed(2)}
                      </span>
                    )}
                    <span 
                      style={{
                        backgroundColor: '#e5e7eb',
                        color: '#666',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}
                    >
                      2: {bet.currentOdds.away.toFixed(2)}
                    </span>
                  </div>
                  <div 
                    style={{
                      fontSize: '12px',
                      color: '#666'
                    }}
                  >
                    Мин: {bet.minBet} | Макс: {bet.maxBet}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Bets247Mobile; 