import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type EsportsCategory = 'all' | 'csgo' | 'dota2' | 'lol' | 'valorant';

type MatchOdds = {
  team1: number;
  team2: number;
  draw?: number;
};

type BaseMatch = {
  id: number;
  game: string;
  tournament: string;
  team1: string;
  team2: string;
  time: string;
  icon: string;
  viewers?: number;
  odds?: MatchOdds;
};

type LiveMatch = BaseMatch & {
  status: 'live';
  currentMap?: string;
  score1: number;
  score2: number;
  currentRound?: number;
};

type UpcomingMatch = BaseMatch & {
  status: 'upcoming';
  date: string;
};

type EsportsMatch = LiveMatch | UpcomingMatch;

const EsportsMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<EsportsCategory>('all');
  const [activeTab, setActiveTab] = useState<'live' | 'upcoming'>('live');

  const generateEsportsMatches = (category: EsportsCategory, tab: 'live' | 'upcoming'): EsportsMatch[] => {
    const esportsMatchesData: Record<EsportsCategory, { live: LiveMatch[], upcoming: UpcomingMatch[] }> = {
      all: {
        live: [
          {
            id: 1,
            game: 'CS:GO',
            tournament: 'ESL Pro League',
            team1: 'Natus Vincere',
            team2: 'Astralis',
            time: 'Прямой эфир',
            status: 'live',
            icon: '🔫',
            currentMap: 'Mirage',
            score1: 10,
            score2: 8,
            currentRound: 22,
            viewers: 250000,
            odds: { team1: 1.7, team2: 2.2 }
          },
          {
            id: 2,
            game: 'Dota 2',
            tournament: 'The International',
            team1: 'Team Secret',
            team2: 'OG',
            time: 'Прямой эфир',
            status: 'live',
            icon: '🎮',
            currentMap: 'Main Stage',
            score1: 1,
            score2: 0,
            currentRound: 2,
            viewers: 180000,
            odds: { team1: 1.9, team2: 1.8 }
          }
        ],
        upcoming: [
          {
            id: 3,
            game: 'League of Legends',
            tournament: 'LEC Spring Split',
            team1: 'G2 Esports',
            team2: 'Fnatic',
            time: 'Через 2 часа',
            status: 'upcoming',
            icon: '🎲',
            date: '2024-02-15T18:00:00Z',
            odds: { team1: 2.1, team2: 1.6 }
          }
        ]
      },
      csgo: {
        live: [
          {
            id: 4,
            game: 'CS:GO',
            tournament: 'BLAST Premier',
            team1: 'FaZe Clan',
            team2: 'Team Liquid',
            time: 'Прямой эфир',
            status: 'live',
            icon: '🔫',
            currentMap: 'Dust 2',
            score1: 12,
            score2: 10,
            currentRound: 25,
            viewers: 300000,
            odds: { team1: 1.6, team2: 2.3 }
          }
        ],
        upcoming: [
          {
            id: 5,
            game: 'CS:GO',
            tournament: 'IEM Katowice',
            team1: 'ENCE',
            team2: 'Vitality',
            time: 'Завтра',
            status: 'upcoming',
            icon: '🔫',
            date: '2024-02-16T20:00:00Z',
            odds: { team1: 2.0, team2: 1.7 }
          }
        ]
      },
      dota2: {
        live: [
          {
            id: 6,
            game: 'Dota 2',
            tournament: 'DPC Winter Tour',
            team1: 'PSG.LGD',
            team2: 'Team Spirit',
            time: 'Прямой эфир',
            status: 'live',
            icon: '🎮',
            currentMap: 'Main Stage',
            score1: 1,
            score2: 1,
            currentRound: 3,
            viewers: 220000,
            odds: { team1: 1.8, team2: 2.0 }
          }
        ],
        upcoming: [
          {
            id: 7,
            game: 'Dota 2',
            tournament: 'Dreamleague',
            team1: 'Tundra Esports',
            team2: 'Gaimin Gladiators',
            time: 'Через 3 часа',
            status: 'upcoming',
            icon: '🎮',
            date: '2024-02-15T19:30:00Z',
            odds: { team1: 2.2, team2: 1.5 }
          }
        ]
      },
      lol: {
        live: [
          {
            id: 8,
            game: 'League of Legends',
            tournament: 'LCK Spring',
            team1: 'T1',
            team2: 'Gen.G',
            time: 'Прямой эфир',
            status: 'live',
            icon: '🎲',
            currentMap: 'Summoner\'s Rift',
            score1: 2,
            score2: 1,
            currentRound: 3,
            viewers: 350000,
            odds: { team1: 1.7, team2: 2.1 }
          }
        ],
        upcoming: [
          {
            id: 9,
            game: 'League of Legends',
            tournament: 'LEC Spring Split',
            team1: 'Rogue',
            team2: 'MAD Lions',
            time: 'Завтра',
            status: 'upcoming',
            icon: '🎲',
            date: '2024-02-16T17:00:00Z',
            odds: { team1: 1.9, team2: 1.8 }
          }
        ]
      },
      valorant: {
        live: [
          {
            id: 10,
            game: 'Valorant',
            tournament: 'VCT Americas',
            team1: 'Sentinels',
            team2: 'Cloud9',
            time: 'Прямой эфир',
            status: 'live',
            icon: '💥',
            currentMap: 'Ascent',
            score1: 7,
            score2: 5,
            currentRound: 13,
            viewers: 180000,
            odds: { team1: 1.8, team2: 2.0 }
          }
        ],
        upcoming: [
          {
            id: 11,
            game: 'Valorant',
            tournament: 'VCT EMEA',
            team1: 'Fnatic',
            team2: 'Liquid',
            time: 'Через 4 часа',
            status: 'upcoming',
            icon: '💥',
            date: '2024-02-15T21:00:00Z',
            odds: { team1: 2.1, team2: 1.7 }
          }
        ]
      }
    };

    return category === 'all' 
      ? esportsMatchesData[category][tab]
      : esportsMatchesData[category][tab] || [];
  };

  const matches = generateEsportsMatches(activeCategory, activeTab);

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Game Category Selection */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          marginBottom: '15px',
          backgroundColor: 'white',
          borderRadius: '20px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        {(['all', 'csgo', 'dota2', 'lol', 'valorant'] as EsportsCategory[]).map(category => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            style={{
              backgroundColor: activeCategory === category ? '#6b0c17' : 'transparent',
              color: activeCategory === category ? 'white' : '#666',
              border: 'none',
              borderRadius: '15px',
              padding: '8px 15px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            {category === 'all' ? 'Все' : 
             category === 'csgo' ? 'CS:GO' : 
             category === 'dota2' ? 'Dota 2' : 
             category === 'lol' ? 'LoL' : 
             'Valorant'}
          </button>
        ))}
      </div>

      {/* Live/Upcoming Tabs */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'center',
          marginBottom: '15px',
          backgroundColor: 'white',
          borderRadius: '20px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        {(['live', 'upcoming'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              backgroundColor: activeTab === tab ? '#6b0c17' : 'transparent',
              color: activeTab === tab ? 'white' : '#666',
              border: 'none',
              borderRadius: '15px',
              padding: '8px 15px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              marginRight: tab === 'live' ? '10px' : '0'
            }}
          >
            {tab === 'live' ? 'Прямой эфир' : 'Предстоящие'}
          </button>
        ))}
      </div>

      {/* Esports Matches */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          {activeTab === 'live' ? 'Киберспортивные матчи в эфире' : 'Предстоящие матчи'}
        </h2>

        {matches.length === 0 ? (
          <div 
            style={{
              textAlign: 'center',
              color: '#666',
              padding: '20px'
            }}
          >
            Нет доступных матчей
          </div>
        ) : (
          matches.map((match, index) => (
            <div 
              key={index}
              style={{
                backgroundColor: '#f9fafb',
                borderRadius: '8px',
                padding: '15px',
                marginBottom: '10px',
                display: 'flex',
                flexDirection: 'column',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
                borderLeft: `5px solid ${match.status === 'live' ? '#6b0c17' : '#1E90FF'}`
              }}
            >
              {/* Match Header */}
              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '10px'
                }}
              >
                <div 
                  style={{
                    fontSize: '14px',
                    color: '#666'
                  }}
                >
                  {match.tournament}
                </div>
                <div 
                  style={{
                    backgroundColor: match.status === 'live' ? '#e5e7eb' : '#e6f2ff',
                    color: match.status === 'live' ? 'red' : '#1E90FF',
                    padding: '4px 8px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: 'bold'
                  }}
                >
                  {match.status === 'live' ? 'LIVE' : match.time}
                </div>
              </div>

              {/* Match Details */}
              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px'
                  }}
                >
                  <span 
                    style={{ 
                      fontSize: '24px' 
                    }}
                  >
                    {match.icon}
                  </span>
                  <div>
                    <div 
                      style={{
                        fontSize: '16px',
                        fontWeight: 'bold',
                        color: '#6b0c17',
                        marginBottom: '5px'
                      }}
                    >
                      {match.team1} vs {match.team2}
                    </div>
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666'
                      }}
                    >
                      {match.game}
                    </div>
                  </div>
                </div>

                {match.status === 'live' && (
                  <div 
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-end'
                    }}
                  >
                    <div 
                      style={{
                        fontSize: '18px',
                        fontWeight: 'bold',
                        color: '#6b0c17'
                      }}
                    >
                      {match.score1} : {match.score2}
                    </div>
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666'
                      }}
                    >
                      {match.currentMap || 'Текущая карта'}
                    </div>
                  </div>
                )}
              </div>

              {/* Viewers and Odds */}
              <div 
                style={{
                  marginTop: '10px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                {match.viewers && (
                  <div 
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '5px',
                      fontSize: '12px',
                      color: '#666'
                    }}
                  >
                    👀 {match.viewers.toLocaleString()}
                  </div>
                )}

                {match.odds && (
                  <div 
                    style={{
                      display: 'flex',
                      gap: '10px'
                    }}
                  >
                    <span 
                      style={{
                        backgroundColor: '#e5e7eb',
                        color: '#666',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}
                    >
                      {match.team1}: {match.odds.team1.toFixed(2)}
                    </span>
                    <span 
                      style={{
                        backgroundColor: '#e5e7eb',
                        color: '#666',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}
                    >
                      {match.team2}: {match.odds.team2.toFixed(2)}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default EsportsMobile; 