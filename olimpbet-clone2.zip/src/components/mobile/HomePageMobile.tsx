import React, { useState } from 'react';
import SidebarMobile from './SidebarMobile';
import LiveMatchesMobile from './LiveMatchesMobile';

const HomePageMobile: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <>
      {/* Mobile Layout - Stacked Vertically */}
      <div style={{ 
        display: 'flex',
        flexDirection: 'column',
        margin: '0',
        padding: '10px',
        gap: '10px',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh'
      }}>
        
        {/* Mobile Sidebar Toggle Button */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          backgroundColor: 'white',
          padding: '12px 15px',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
          marginBottom: '5px'
        }}>
          <button
            onClick={() => setIsSidebarOpen(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              backgroundColor: '#6b0c17',
              color: 'white',
              border: 'none',
              padding: '10px 15px',
              borderRadius: '6px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}
          >
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}>
              <div style={{ width: '16px', height: '2px', backgroundColor: 'white', borderRadius: '1px' }}></div>
              <div style={{ width: '16px', height: '2px', backgroundColor: 'white', borderRadius: '1px' }}></div>
              <div style={{ width: '16px', height: '2px', backgroundColor: 'white', borderRadius: '1px' }}></div>
            </div>
            Sports & Bets
          </button>
          
          {/* Quick Stats */}
          <div style={{
            display: 'flex',
            gap: '15px',
            fontSize: '12px',
            color: '#666'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontWeight: 'bold', color: '#6b0c17' }}>155</div>
              <div>Live</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontWeight: 'bold', color: '#6b0c17' }}>2679</div>
              <div>Total</div>
            </div>
          </div>
        </div>

        {/* Main Content - LiveMatches Mobile */}
        <div style={{ flex: 1 }}>
          <LiveMatchesMobile />
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      <SidebarMobile 
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(false)}
        showAsOverlay={true}
      />
    </>
  );
};

export default HomePageMobile; 
