import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import SidebarMobile from './SidebarMobile';

const AboutUsMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <>
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        margin: '0',
        padding: '10px',
        gap: '15px',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }} dir={isRTL ? 'rtl' : 'ltr'}>
        
        {/* Mobile Header with Sidebar Toggle */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          backgroundColor: 'white',
          padding: '15px',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}>
          <button
            onClick={() => setIsSidebarOpen(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              backgroundColor: '#6b0c17',
              color: 'white',
              border: 'none',
              padding: '10px 15px',
              borderRadius: '6px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}
          >
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}>
              <div style={{ width: '16px', height: '2px', backgroundColor: 'white', borderRadius: '1px' }}></div>
              <div style={{ width: '16px', height: '2px', backgroundColor: 'white', borderRadius: '1px' }}></div>
              <div style={{ width: '16px', height: '2px', backgroundColor: 'white', borderRadius: '1px' }}></div>
            </div>
            {translate('menu')}
          </button>
          
          <h1 style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0',
            textAlign: 'center'
          }}>
            {translate('aboutUsTitle')}
          </h1>
          
          <div style={{ width: '80px' }}></div> {/* Spacer for balance */}
        </div>

        {/* Hero Card - Mobile */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '25px 20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <div style={{
            width: '60px',
            height: '60px',
            backgroundColor: '#6b0c17',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 15px',
            fontSize: '28px'
          }}>
            🏆
          </div>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 10px 0'
          }}>
            {translate('aboutUsTitle')}
          </h2>
          <p style={{
            fontSize: '16px',
            color: '#666',
            margin: '0',
            lineHeight: '1.6'
          }}>
            {translate('aboutUsSubtitle')}
          </p>
        </div>

        {/* Key Features - Mobile Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '10px'
        }}>
                      {[
              { icon: '🎯', title: translate('bestOdds'), description: translate('bestOddsDescription') },
              { icon: '⚡', title: translate('liveBetting'), description: translate('liveBettingDescription') },
              { icon: '🔒', title: translate('secure'), description: translate('secureDescription') },
              { icon: '📱', title: translate('mobileReady'), description: translate('mobileReadyDescription') }
          ].map((feature, index) => (
            <div key={index} style={{
              backgroundColor: 'white',
              borderRadius: '12px',
              padding: '20px 15px',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
              textAlign: 'center'
            }}>
              <div style={{
                fontSize: '32px',
                marginBottom: '10px'
              }}>
                {feature.icon}
              </div>
              <h3 style={{
                fontSize: '16px',
                fontWeight: 'bold',
                color: '#6b0c17',
                margin: '0 0 8px 0'
              }}>
                {feature.title}
              </h3>
              <p style={{
                fontSize: '12px',
                color: '#666',
                margin: '0',
                lineHeight: '1.4'
              }}>
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Main Content Cards - Mobile */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
          {/* Our Story */}
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '20px',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '15px'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                backgroundColor: '#6b0c17',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px'
              }}>
                📖
              </div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#6b0c17',
                margin: '0'
              }}>
                {translate('ourStoryTitle')}
              </h3>
            </div>
            <p style={{
              fontSize: '14px',
              color: '#374151',
              margin: '0',
              lineHeight: '1.6'
            }}>
                              {translate('aboutUsDescription')}
            </p>
          </div>

          {/* Our Mission */}
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '20px',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '15px'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                backgroundColor: '#6b0c17',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px'
              }}>
                🎯
              </div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#6b0c17',
                margin: '0'
              }}>
                {translate('ourMissionTitle')}
              </h3>
            </div>
            <p style={{
              fontSize: '14px',
              color: '#374151',
              margin: '0',
              lineHeight: '1.6'
            }}>
              To provide the ultimate sports betting experience through cutting-edge technology, 
              fair play, and responsible gaming practices. We are committed to creating a safe 
              and exciting environment for sports enthusiasts worldwide.
            </p>
          </div>

          {/* Why Choose Us */}
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '20px',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '15px'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                backgroundColor: '#6b0c17',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px'
              }}>
                ⭐
              </div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#6b0c17',
                margin: '0'
              }}>
                {translate('whyChooseUsTitle')}
              </h3>
            </div>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '12px'
            }}>
              {[
                translate('licensedAndRegulated'),
                translate('fastAndSecurePayment'),
                translate('twentyFourSevenSupport'),
                translate('wideRangeOfSports'),
                translate('competitiveOdds'),
                translate('mobileOptimizedExperience')
              ].map((point, index) => (
                <div key={index} style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}>
                  <div style={{
                    width: '6px',
                    height: '6px',
                    backgroundColor: '#6b0c17',
                    borderRadius: '50%'
                  }}></div>
                  <span style={{
                    fontSize: '14px',
                    color: '#374151'
                  }}>
                    {point}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Contact Us Card - Mobile */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <div style={{
            fontSize: '32px',
            marginBottom: '15px'
          }}>
            📞
          </div>
          <h3 style={{
            color: '#6b0c17',
            fontSize: '18px',
            fontWeight: 'bold',
            margin: '0 0 10px 0'
          }}>
            {translate('getInTouchTitle')}
          </h3>
          <p style={{
            color: '#666',
            fontSize: '14px',
            margin: '0 0 15px 0',
            lineHeight: '1.5'
          }}>
            {translate('getInTouchSubtitle')}
          </p>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '10px'
          }}>
            <button style={{
              backgroundColor: '#6b0c17',
              color: 'white',
              border: 'none',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}>
              {translate('liveChat')}
            </button>
            <button style={{
              backgroundColor: 'transparent',
              color: '#6b0c17',
              border: '2px solid #6b0c17',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}>
              {translate('emailUs')}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      <SidebarMobile 
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(false)}
        showAsOverlay={true}
      />
    </>
  );
};

export default AboutUsMobile; 
