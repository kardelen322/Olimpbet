import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type SportCategory = 'football' | 'basketball' | 'tennis' | 'hockey' | 'volleyball';

type MatchOdds = {
  home: number;
  away: number;
  draw?: number;
};

type Match = {
  id: number;
  homeTeam: string;
  awayTeam: string;
  league: string;
  date: string;
  time: string;
  odds: MatchOdds;
  icon?: string;
};

type SportData = {
  name: string;
  icon: string;
  popularLeagues: string[];
  topTeams: string[];
  upcomingMatches: Match[];
};

const SportsMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<SportCategory>('football');

  const generateSportData = (category: SportCategory): SportData => {
    const sportData: Record<SportCategory, SportData> = {
      football: {
        name: 'Футбол',
        icon: '⚽',
        popularLeagues: ['Премьер-лига', 'Лига Чемпионов', 'Примера', 'Бундеслига'],
        topTeams: ['Реал Мадрид', 'Барселона', 'Бавария', 'Ливерпуль'],
        upcomingMatches: [
          {
            id: 1,
            homeTeam: 'Реал Мадрид',
            awayTeam: 'Барселона',
            league: 'Примера',
            date: '2024-02-15',
            time: '20:00',
            odds: { home: 2.1, away: 3.5, draw: 3.2 },
            icon: '⚽'
          },
          {
            id: 2,
            homeTeam: 'Бавария',
            awayTeam: 'Боруссия Дортмунд',
            league: 'Бундеслига',
            date: '2024-02-16',
            time: '18:30',
            odds: { home: 1.8, away: 4.2, draw: 3.5 },
            icon: '⚽'
          },
          {
            id: 3,
            homeTeam: 'Ливерпуль',
            awayTeam: 'Манчестер Сити',
            league: 'Премьер-лига',
            date: '2024-02-17',
            time: '19:45',
            odds: { home: 2.3, away: 3.1, draw: 3.0 },
            icon: '⚽'
          }
        ]
      },
      basketball: {
        name: 'Баскетбол',
        icon: '🏀',
        popularLeagues: ['NBA', 'Евролига', 'Единая лига ВТБ'],
        topTeams: ['Лейкерс', 'Голден Стейт', 'ЦСКА', 'Реал Мадрид'],
        upcomingMatches: [
          {
            id: 1,
            homeTeam: 'Лейкерс',
            awayTeam: 'Голден Стейт',
            league: 'NBA',
            date: '2024-02-15',
            time: '22:00',
            odds: { home: 1.9, away: 2.1 },
            icon: '🏀'
          },
          {
            id: 2,
            homeTeam: 'ЦСКА',
            awayTeam: 'Зенит',
            league: 'Единая лига ВТБ',
            date: '2024-02-16',
            time: '19:00',
            odds: { home: 1.7, away: 2.3 },
            icon: '🏀'
          }
        ]
      },
      tennis: {
        name: 'Теннис',
        icon: '🎾',
        popularLeagues: ['ATP', 'WTA', 'Большой шлем'],
        topTeams: ['Новак Джокович', 'Рафаэль Надаль', 'Карлос Алькарас'],
        upcomingMatches: [
          {
            id: 1,
            homeTeam: 'Новак Джокович',
            awayTeam: 'Карлос Алькарас',
            league: 'ATP Турнир',
            date: '2024-02-15',
            time: '15:00',
            odds: { home: 1.6, away: 2.4 },
            icon: '🎾'
          }
        ]
      },
      hockey: {
        name: 'Хоккей',
        icon: '🏒',
        popularLeagues: ['НХЛ', 'КХЛ', 'Чемпионат мира'],
        topTeams: ['Питтсбург', 'Вашингтон', 'СКА', 'ЦСКА'],
        upcomingMatches: [
          {
            id: 1,
            homeTeam: 'Питтсбург',
            awayTeam: 'Вашингтон',
            league: 'НХЛ',
            date: '2024-02-15',
            time: '21:00',
            odds: { home: 2.0, away: 1.9 },
            icon: '🏒'
          }
        ]
      },
      volleyball: {
        name: 'Волейбол',
        icon: '🏐',
        popularLeagues: ['Мировая лига', 'Чемпионат России', 'Лига чемпионов'],
        topTeams: ['Зенит', 'Динамо', 'Кузбасс'],
        upcomingMatches: [
          {
            id: 1,
            homeTeam: 'Зенит',
            awayTeam: 'Динамо',
            league: 'Чемпионат России',
            date: '2024-02-16',
            time: '18:00',
            odds: { home: 1.7, away: 2.3 },
            icon: '🏐'
          }
        ]
      }
    };

    return sportData[category];
  };

  const sportData = generateSportData(activeCategory);

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Sport Category Selection */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          marginBottom: '15px',
          backgroundColor: 'white',
          borderRadius: '20px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        {(['football', 'basketball', 'tennis', 'hockey', 'volleyball'] as SportCategory[]).map(category => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            style={{
              backgroundColor: activeCategory === category ? '#6b0c17' : 'transparent',
              color: activeCategory === category ? 'white' : '#666',
              border: 'none',
              borderRadius: '15px',
              padding: '8px 15px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            {category === 'football' ? 'Футбол' : 
             category === 'basketball' ? 'Баскетбол' : 
             category === 'tennis' ? 'Теннис' : 
             category === 'hockey' ? 'Хоккей' : 
             'Волейбол'}
          </button>
        ))}
      </div>

      {/* Sport Details */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <div 
          style={{
            display: 'flex',
            alignItems: 'center',
            marginBottom: '15px'
          }}
        >
          <span 
            style={{ 
              fontSize: '24px', 
              marginRight: '10px' 
            }}
          >
            {sportData.icon}
          </span>
          <h2 
            style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: '#6b0c17',
              margin: 0
            }}
          >
            {sportData.name}
          </h2>
        </div>

        {/* Popular Leagues */}
        <div 
          style={{
            marginBottom: '15px'
          }}
        >
          <h3 
            style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#6b0c17',
              marginBottom: '10px'
            }}
          >
            Популярные лиги
          </h3>
          <div 
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '10px'
            }}
          >
            {sportData.popularLeagues.map((league, index) => (
              <span 
                key={index}
                style={{
                  backgroundColor: '#f9fafb',
                  color: '#666',
                  padding: '5px 10px',
                  borderRadius: '15px',
                  fontSize: '12px'
                }}
              >
                {league}
              </span>
            ))}
          </div>
        </div>

        {/* Top Teams */}
        <div 
          style={{
            marginBottom: '15px'
          }}
        >
          <h3 
            style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#6b0c17',
              marginBottom: '10px'
            }}
          >
            Топ команд
          </h3>
          <div 
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '10px'
            }}
          >
            {sportData.topTeams.map((team, index) => (
              <span 
                key={index}
                style={{
                  backgroundColor: '#f9fafb',
                  color: '#666',
                  padding: '5px 10px',
                  borderRadius: '15px',
                  fontSize: '12px'
                }}
              >
                {team}
              </span>
            ))}
          </div>
        </div>

        {/* Upcoming Matches */}
        <div>
          <h3 
            style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#6b0c17',
              marginBottom: '10px'
            }}
          >
            Предстоящие матчи
          </h3>
          {sportData.upcomingMatches.map((match, index) => (
            <div 
              key={index}
              style={{
                backgroundColor: '#f9fafb',
                borderRadius: '8px',
                padding: '15px',
                marginBottom: '10px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <div>
                <div 
                  style={{
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#6b0c17',
                    marginBottom: '5px'
                  }}
                >
                  {match.homeTeam} vs {match.awayTeam}
                </div>
                <div 
                  style={{
                    fontSize: '12px',
                    color: '#666'
                  }}
                >
                  {match.league} | {match.date} {match.time}
                </div>
              </div>
              <div 
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'flex-end'
                }}
              >
                <div 
                  style={{
                    fontSize: '12px',
                    color: '#666',
                    marginBottom: '5px'
                  }}
                >
                  Коэффициенты
                </div>
                <div 
                  style={{
                    display: 'flex',
                    gap: '10px'
                  }}
                >
                  <span 
                    style={{
                      backgroundColor: '#e5e7eb',
                      color: '#666',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      fontSize: '12px'
                    }}
                  >
                    1: {match.odds.home.toFixed(2)}
                  </span>
                  {match.odds.draw && (
                    <span 
                      style={{
                        backgroundColor: '#e5e7eb',
                        color: '#666',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}
                    >
                      X: {match.odds.draw.toFixed(2)}
                    </span>
                  )}
                  <span 
                    style={{
                      backgroundColor: '#e5e7eb',
                      color: '#666',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      fontSize: '12px'
                    }}
                  >
                    2: {match.odds.away.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SportsMobile; 