import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type ResultCategory = 'all' | 'football' | 'basketball' | 'tennis';

type Result = {
  sport: string;
  match: string;
  score: string;
  date: string;
  league: string;
  icon: string;
  tournament?: string;
  winner?: string;
};

const ResultsMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<ResultCategory>('all');

  const generateResults = (): Result[] => {
    // Type-safe results generation with fallback
    const recentResults = (mockData as any).results?.recentResults || [];
    const topResults = (mockData as any).results?.topResults || [];

    const processResults = (results: any[]): Result[] => 
      results.map((result: any, index: number) => ({
        sport: result.sport || 'Unknown Sport',
        match: result.match || 'Unknown Match',
        score: result.score || '0:0',
        date: result.date || 'TBA',
        league: result.league || 'Unknown League',
        icon: result.icon || '⚽',
        tournament: result.tournament,
        winner: result.winner
      }));

    const processedRecentResults = processResults(recentResults);
    const processedTopResults = processResults(topResults);

    return [...processedRecentResults, ...processedTopResults];
  };

  const results = generateResults();

  const filterResultsByCategory = (resultsToFilter: Result[]): Result[] => {
    if (activeCategory === 'all') return resultsToFilter;
    return resultsToFilter.filter(result => 
      result.sport.toLowerCase().includes(activeCategory.toLowerCase())
    );
  };

  const filteredResults = filterResultsByCategory(results);

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Category Selection */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          marginBottom: '15px',
          backgroundColor: 'white',
          borderRadius: '20px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        {(['all', 'football', 'basketball', 'tennis'] as ResultCategory[]).map(category => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            style={{
              backgroundColor: activeCategory === category ? '#6b0c17' : 'transparent',
              color: activeCategory === category ? 'white' : '#666',
              border: 'none',
              borderRadius: '15px',
              padding: '8px 15px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            {category === 'all' ? 'Все' : 
             category === 'football' ? 'Футбол' : 
             category === 'basketball' ? 'Баскетбол' : 
             'Теннис'}
          </button>
        ))}
      </div>

      {/* Results List */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          Результаты матчей
        </h2>

        {filteredResults.length === 0 ? (
          <div 
            style={{
              textAlign: 'center',
              color: '#666',
              padding: '20px'
            }}
          >
            Нет доступных результатов
          </div>
        ) : (
          filteredResults.map((result, index) => (
            <div 
              key={index}
              style={{
                backgroundColor: '#f9fafb',
                borderRadius: '8px',
                padding: '15px',
                marginBottom: '10px',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
              }}
            >
              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '10px'
                }}
              >
                <div 
                  style={{
                    fontSize: '14px',
                    color: '#666'
                  }}
                >
                  {result.tournament || result.league}
                </div>
                <div 
                  style={{
                    fontSize: '12px',
                    color: '#999'
                  }}
                >
                  {result.date}
                </div>
              </div>

              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px'
                  }}
                >
                  <span 
                    style={{ 
                      fontSize: '24px' 
                    }}
                  >
                    {result.icon}
                  </span>
                  <div>
                    <div 
                      style={{
                        fontSize: '16px',
                        fontWeight: 'bold',
                        color: '#6b0c17'
                      }}
                    >
                      {result.match}
                    </div>
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666'
                      }}
                    >
                      {result.sport}
                    </div>
                  </div>
                </div>

                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    backgroundColor: '#e5e7eb',
                    padding: '4px 8px',
                    borderRadius: '4px'
                  }}
                >
                  <span 
                    style={{
                      fontSize: '14px',
                      fontWeight: 'bold'
                    }}
                  >
                    {result.score}
                  </span>
                </div>
              </div>

              {result.winner && (
                <div 
                  style={{
                    marginTop: '10px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    fontSize: '12px',
                    color: '#666'
                  }}
                >
                  <span>Победитель: {result.winner}</span>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ResultsMobile; 