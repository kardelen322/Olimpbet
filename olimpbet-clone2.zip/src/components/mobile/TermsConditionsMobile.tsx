import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type TermSection = {
  title: string;
  content: string[];
  subsections?: {
    title: string;
    content: string;
  }[];
};

const TermsConditionsMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const generateTermSections = (): TermSection[] => {
    // Type-safe terms sections generation with fallback
    const termsData = (mockData as any).terms || {};
    const sections = termsData.sections || [];

    return sections.map((section: any) => ({
      title: section.title || 'Unnamed Section',
      content: Array.isArray(section.content) 
        ? section.content 
        : [section.content || 'No content available'],
      subsections: (section.subsections || []).map((subsection: any) => ({
        title: subsection.title || 'Unnamed Subsection',
        content: subsection.content || 'No content available'
      }))
    }));
  };

  const termSections = generateTermSections();

  const toggleSection = (title: string) => {
    setActiveSection(activeSection === title ? null : title);
  };

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {termSections.map((section, sectionIndex) => (
        <div 
          key={sectionIndex}
          style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            marginBottom: '15px',
            overflow: 'hidden',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}
        >
          {/* Section Header */}
          <div 
            onClick={() => toggleSection(section.title)}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '15px',
              backgroundColor: '#f9fafb',
              cursor: 'pointer'
            }}
          >
            <h2 
              style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#6b0c17',
                margin: 0
              }}
            >
              {section.title}
            </h2>
            <span 
              style={{ 
                fontSize: '20px', 
                color: '#6b0c17' 
              }}
            >
              {activeSection === section.title ? '▼' : '►'}
            </span>
          </div>

          {/* Section Content */}
          {activeSection === section.title && (
            <div 
              style={{
                padding: '15px',
                backgroundColor: 'white'
              }}
            >
              {section.content.map((paragraph, paragraphIndex) => (
                <p 
                  key={paragraphIndex}
                  style={{
                    fontSize: '14px',
                    color: '#666',
                    marginBottom: '10px',
                    lineHeight: 1.6
                  }}
                >
                  {paragraph}
                </p>
              ))}

              {section.subsections && section.subsections.length > 0 && (
                <div 
                  style={{
                    marginTop: '15px'
                  }}
                >
                  {section.subsections.map((subsection, subsectionIndex) => (
                    <div 
                      key={subsectionIndex}
                      style={{
                        backgroundColor: '#f9fafb',
                        borderRadius: '8px',
                        padding: '12px',
                        marginBottom: '10px'
                      }}
                    >
                      <h3 
                        style={{
                          fontSize: '16px',
                          fontWeight: 'bold',
                          color: '#6b0c17',
                          marginBottom: '10px'
                        }}
                      >
                        {subsection.title}
                      </h3>
                      <p 
                        style={{
                          fontSize: '14px',
                          color: '#666',
                          margin: 0
                        }}
                      >
                        {subsection.content}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      ))}

      {/* Legal Notice */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          Юридическое уведомление
        </h2>
        
        <p 
          style={{
            fontSize: '14px',
            color: '#666',
            lineHeight: 1.6
          }}
        >
          Все права защищены. Информация на сайте не является публичной офертой. 
          Ставки могут содержать риск финансовых потерь. 
          Точные условия и правила могут различаться, пожалуйста, ознакомьтесь с полными условиями.
        </p>
      </div>

      {/* Contact Information */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          marginTop: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          Контактная информация
        </h2>
        
        <div 
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '10px'
          }}
        >
          <div 
            style={{
              backgroundColor: '#f9fafb',
              borderRadius: '8px',
              padding: '12px',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            <span 
              style={{ 
                fontSize: '24px', 
                marginRight: '10px' 
              }}
            >
              📞
            </span>
            <div>
              <h3 
                style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: '#6b0c17',
                  margin: 0
                }}
              >
                Служба поддержки
              </h3>
              <p 
                style={{
                  fontSize: '14px',
                  color: '#666',
                  margin: 0
                }}
              >
                +7 (800) 555-35-35
              </p>
            </div>
          </div>
          
          <div 
            style={{
              backgroundColor: '#f9fafb',
              borderRadius: '8px',
              padding: '12px',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            <span 
              style={{ 
                fontSize: '24px', 
                marginRight: '10px' 
              }}
            >
              ✉️
            </span>
            <div>
              <h3 
                style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: '#6b0c17',
                  margin: 0
                }}
              >
                Электронная почта
              </h3>
              <p 
                style={{
                  fontSize: '14px',
                  color: '#666',
                  margin: 0
                }}
              >
                support@olimpbet.com
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsConditionsMobile; 