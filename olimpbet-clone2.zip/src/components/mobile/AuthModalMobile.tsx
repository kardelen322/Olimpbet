import React, { useState } from 'react';
import LoginMobile from './LoginMobile';
import RegisterMobile from './RegisterMobile';

interface AuthModalMobileProps {
  initialView?: 'login' | 'register';
  onClose?: () => void;
}

const AuthModalMobile: React.FC<AuthModalMobileProps> = ({ 
  initialView = 'login',
  onClose 
}) => {
  const [currentView, setCurrentView] = useState<'login' | 'register'>(initialView);

  const handleSwitchToLogin = () => {
    setCurrentView('login');
  };

  const handleSwitchToRegister = () => {
    setCurrentView('register');
  };

  return (
    <div style={styles.modalContainer}>
      <div style={styles.modalContent}>
        {onClose && (
          <button 
            onClick={onClose} 
            style={styles.closeButton}
            aria-label="Close"
          >
            ×
          </button>
        )}
        
        {currentView === 'login' ? (
          <LoginMobile onRegisterClick={handleSwitchToRegister} />
        ) : (
          <RegisterMobile onLoginClick={handleSwitchToLogin} />
        )}
      </div>
    </div>
  );
};

const styles = {
  modalContainer: {
    position: 'fixed' as const,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContent: {
    position: 'relative' as const,
    backgroundColor: '#fff',
    borderRadius: '8px',
    width: '100%',
    height: '100%',
    maxWidth: '100%',
    maxHeight: '100%',
    overflow: 'auto',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
  },
  closeButton: {
    position: 'absolute' as const,
    top: '10px',
    right: '10px',
    background: 'none',
    border: 'none',
    fontSize: '24px',
    fontWeight: 'bold',
    cursor: 'pointer',
    color: '#333',
    zIndex: 1,
  },
};

export default AuthModalMobile;