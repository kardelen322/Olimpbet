import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type LiveCategory = 'football' | 'basketball' | 'tennis' | 'hockey' | 'esports';

type LiveEventOdds = {
  home: number;
  away: number;
  draw?: number;
};

type LiveEvent = {
  id: number;
  sport: string;
  tournament: string;
  homeTeam: string;
  awayTeam: string;
  currentScore: string;
  time: string;
  status: 'live';
  icon: string;
  odds: LiveEventOdds;
  period?: string;
  minuteOfGame?: number;
};

const LiveMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<LiveCategory>('football');

  const generateLiveEvents = (category: LiveCategory): LiveEvent[] => {
    const liveEventsData: Record<LiveCategory, LiveEvent[]> = {
      football: [
        {
          id: 1,
          sport: 'Футбол',
          tournament: 'Премьер-лига',
          homeTeam: 'Зенит',
          awayTeam: 'ЦСКА',
          currentScore: '1:1',
          time: 'Прямой эфир',
          status: 'live',
          icon: '⚽',
          odds: { home: 2.1, away: 1.9, draw: 3.2 },
          period: 'Второй тайм',
          minuteOfGame: 65
        },
        {
          id: 2,
          sport: 'Футбол',
          tournament: 'Лига Чемпионов',
          homeTeam: 'Реал Мадрид',
          awayTeam: 'Манчестер Сити',
          currentScore: '0:2',
          time: 'Прямой эфир',
          status: 'live',
          icon: '⚽',
          odds: { home: 3.5, away: 1.5, draw: 4.0 },
          period: 'Второй тайм',
          minuteOfGame: 72
        }
      ],
      basketball: [
        {
          id: 3,
          sport: 'Баскетбол',
          tournament: 'NBA',
          homeTeam: 'Лейкерс',
          awayTeam: 'Голден Стейт',
          currentScore: '85:82',
          time: 'Прямой эфир',
          status: 'live',
          icon: '🏀',
          odds: { home: 1.8, away: 2.1 },
          period: '4 четверть',
          minuteOfGame: 8
        }
      ],
      tennis: [
        {
          id: 4,
          sport: 'Теннис',
          tournament: 'ATP Турнир',
          homeTeam: 'Новак Джокович',
          awayTeam: 'Карлос Алькарас',
          currentScore: '2:1',
          time: 'Прямой эфир',
          status: 'live',
          icon: '🎾',
          odds: { home: 1.6, away: 2.4 },
          period: 'Третий сет'
        }
      ],
      hockey: [
        {
          id: 5,
          sport: 'Хоккей',
          tournament: 'КХЛ',
          homeTeam: 'СКА',
          awayTeam: 'ЦСКА',
          currentScore: '2:1',
          time: 'Прямой эфир',
          status: 'live',
          icon: '🏒',
          odds: { home: 2.0, away: 1.9 },
          period: '3 период',
          minuteOfGame: 15
        }
      ],
      esports: [
        {
          id: 6,
          sport: 'Киберспорт',
          tournament: 'CS:GO Турнир',
          homeTeam: 'Team Liquid',
          awayTeam: 'Fnatic',
          currentScore: '10:8',
          time: 'Прямой эфир',
          status: 'live',
          icon: '🎮',
          odds: { home: 1.7, away: 2.2 },
          period: 'Карта 2'
        }
      ]
    };

    return liveEventsData[category];
  };

  const liveEvents = generateLiveEvents(activeCategory);

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Live Category Selection */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          marginBottom: '15px',
          backgroundColor: 'white',
          borderRadius: '20px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        {(['football', 'basketball', 'tennis', 'hockey', 'esports'] as LiveCategory[]).map(category => (
          <button
            key={`live-category-${category}`}
            onClick={() => setActiveCategory(category)}
            style={{
              backgroundColor: activeCategory === category ? '#6b0c17' : 'transparent',
              color: activeCategory === category ? 'white' : '#666',
              border: 'none',
              borderRadius: '15px',
              padding: '8px 15px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            {category === 'football' ? 'Футбол' : 
             category === 'basketball' ? 'Баскетбол' : 
             category === 'tennis' ? 'Теннис' : 
             category === 'hockey' ? 'Хоккей' : 
             'Киберспорт'}
          </button>
        ))}
      </div>

      {/* Live Events */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          {activeCategory === 'football' ? 'Футбольные матчи' : 
           activeCategory === 'basketball' ? 'Баскетбольные игры' : 
           activeCategory === 'tennis' ? 'Теннисные матчи' : 
           activeCategory === 'hockey' ? 'Хоккейные матчи' : 
           'Киберспортивные матчи'}
        </h2>

        {liveEvents.length === 0 ? (
          <div 
            style={{
              textAlign: 'center',
              color: '#666',
              padding: '20px'
            }}
          >
            Нет активных событий
          </div>
        ) : (
          liveEvents.map((event, index) => (
            <div 
              key={`live-event-${index}`}
              style={{
                backgroundColor: '#f9fafb',
                borderRadius: '8px',
                padding: '15px',
                marginBottom: '10px',
                display: 'flex',
                flexDirection: 'column',
                boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
              }}
            >
              {/* Event Header */}
              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '10px'
                }}
              >
                <div 
                  style={{
                    fontSize: '14px',
                    color: '#666'
                  }}
                >
                  {event.tournament}
                </div>
                <div 
                  style={{
                    backgroundColor: '#e5e7eb',
                    color: 'red',
                    padding: '4px 8px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: 'bold'
                  }}
                >
                  LIVE
                </div>
              </div>

              {/* Match Details */}
              <div 
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px'
                  }}
                >
                  <span 
                    style={{ 
                      fontSize: '24px' 
                    }}
                  >
                    {event.icon}
                  </span>
                  <div>
                    <div 
                      style={{
                        fontSize: '16px',
                        fontWeight: 'bold',
                        color: '#6b0c17'
                      }}
                    >
                      {event.homeTeam} vs {event.awayTeam}
                    </div>
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666'
                      }}
                    >
                      {event.period || 'Текущий период'}
                    </div>
                  </div>
                </div>

                <div 
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-end'
                  }}
                >
                  <div 
                    style={{
                      fontSize: '18px',
                      fontWeight: 'bold',
                      color: '#6b0c17'
                    }}
                  >
                    {event.currentScore}
                  </div>
                  {event.minuteOfGame && (
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666'
                      }}
                    >
                      {event.minuteOfGame}' минута
                    </div>
                  )}
                </div>
              </div>

              {/* Betting Odds */}
              <div 
                style={{
                  marginTop: '10px',
                  display: 'flex',
                  justifyContent: 'space-between'
                }}
              >
                <div 
                  style={{
                    display: 'flex',
                    gap: '10px'
                  }}
                >
                  <span 
                    style={{
                      backgroundColor: '#e5e7eb',
                      color: '#666',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      fontSize: '12px'
                    }}
                  >
                    1: {event.odds.home.toFixed(2)}
                  </span>
                  {event.odds.draw && (
                    <span 
                      style={{
                        backgroundColor: '#e5e7eb',
                        color: '#666',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}
                    >
                      X: {event.odds.draw.toFixed(2)}
                    </span>
                  )}
                  <span 
                    style={{
                      backgroundColor: '#e5e7eb',
                      color: '#666',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      fontSize: '12px'
                    }}
                  >
                    2: {event.odds.away.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default LiveMobile;