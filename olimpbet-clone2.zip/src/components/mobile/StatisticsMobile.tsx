import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type StatisticsTab = 'all' | 'football' | 'tennis' | 'basketball' | 'esports';

type SportStatistic = {
  name: string;
  icon: string;
  wins: number;
  losses: number;
  draws: number;
  winRate: number;
  rank?: number;
  totalPoints?: number;
};

type AnalyticsStat = {
  title: string;
  value: number;
  trend: 'up' | 'down' | 'neutral';
  subtext?: string;
};

type SportStatisticsData = {
  [key in StatisticsTab]?: {
    sports?: SportStatistic[];
    analyticsStats?: AnalyticsStat[];
  };
};

const StatisticsMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState<StatisticsTab>('all');

  const generateSportStatistics = (tab: StatisticsTab): SportStatistic[] => {
    const footballSports: SportStatistic[] = [
      {
        name: 'Реал Мадрид',
        icon: '⚽',
        wins: 18,
        losses: 5,
        draws: 3,
        winRate: 72.5,
        rank: 1,
        totalPoints: 57
      },
      {
        name: 'Барселона',
        icon: '⚽',
        wins: 16,
        losses: 7,
        draws: 4,
        winRate: 65.3,
        rank: 2,
        totalPoints: 52
      },
      {
        name: 'Атлетико Мадрид',
        icon: '⚽',
        wins: 15,
        losses: 8,
        draws: 4,
        winRate: 62.1,
        rank: 3,
        totalPoints: 49
      },
      {
        name: 'Севилья',
        icon: '⚽',
        wins: 14,
        losses: 9,
        draws: 4,
        winRate: 60.0,
        rank: 4,
        totalPoints: 46
      },
      {
        name: 'Реал Сосьедад',
        icon: '⚽',
        wins: 13,
        losses: 10,
        draws: 4,
        winRate: 57.5,
        rank: 5,
        totalPoints: 43
      }
    ];

    const tennisSports: SportStatistic[] = [
      {
        name: 'Новак Джокович',
        icon: '🎾',
        wins: 22,
        losses: 3,
        draws: 0,
        winRate: 88.0,
        rank: 1,
        totalPoints: 12000
      },
      {
        name: 'Рафаэль Надаль',
        icon: '🎾',
        wins: 20,
        losses: 5,
        draws: 0,
        winRate: 80.0,
        rank: 2,
        totalPoints: 11500
      },
      {
        name: 'Карлос Алькарас',
        icon: '🎾',
        wins: 18,
        losses: 6,
        draws: 0,
        winRate: 75.0,
        rank: 3,
        totalPoints: 10800
      },
      {
        name: 'Даниил Медведев',
        icon: '🎾',
        wins: 16,
        losses: 8,
        draws: 0,
        winRate: 66.7,
        rank: 4,
        totalPoints: 10200
      },
      {
        name: 'Стефанос Циципас',
        icon: '🎾',
        wins: 15,
        losses: 9,
        draws: 0,
        winRate: 62.5,
        rank: 5,
        totalPoints: 9800
      }
    ];

    const basketballSports: SportStatistic[] = [
      {
        name: 'Лейкерс',
        icon: '🏀',
        wins: 15,
        losses: 10,
        draws: 0,
        winRate: 60.0,
        rank: 1,
        totalPoints: 30
      },
      {
        name: 'Голден Стейт Уорриорз',
        icon: '🏀',
        wins: 17,
        losses: 8,
        draws: 0,
        winRate: 68.0,
        rank: 2,
        totalPoints: 34
      },
      {
        name: 'Бостон Селтикс',
        icon: '🏀',
        wins: 16,
        losses: 9,
        draws: 0,
        winRate: 64.0,
        rank: 3,
        totalPoints: 32
      },
      {
        name: 'Милуоки Бакс',
        icon: '🏀',
        wins: 14,
        losses: 11,
        draws: 0,
        winRate: 56.0,
        rank: 4,
        totalPoints: 28
      },
      {
        name: 'Финикс Санс',
        icon: '🏀',
        wins: 13,
        losses: 12,
        draws: 0,
        winRate: 52.0,
        rank: 5,
        totalPoints: 26
      }
    ];

    const esportsSports: SportStatistic[] = [
      {
        name: 'Team Liquid',
        icon: '🎮',
        wins: 25,
        losses: 5,
        draws: 0,
        winRate: 83.3,
        rank: 1,
        totalPoints: 500
      },
      {
        name: 'Fnatic',
        icon: '🎮',
        wins: 22,
        losses: 8,
        draws: 0,
        winRate: 73.3,
        rank: 2,
        totalPoints: 440
      },
      {
        name: 'G2 Esports',
        icon: '🎮',
        wins: 20,
        losses: 10,
        draws: 0,
        winRate: 66.7,
        rank: 3,
        totalPoints: 400
      },
      {
        name: 'Cloud9',
        icon: '🎮',
        wins: 18,
        losses: 12,
        draws: 0,
        winRate: 60.0,
        rank: 4,
        totalPoints: 360
      },
      {
        name: 'FaZe Clan',
        icon: '🎮',
        wins: 16,
        losses: 14,
        draws: 0,
        winRate: 53.3,
        rank: 5,
        totalPoints: 320
      }
    ];

    const sportsByTab: Record<StatisticsTab, SportStatistic[]> = {
      all: [
        ...footballSports, 
        ...tennisSports, 
        ...basketballSports, 
        ...esportsSports
      ],
      football: footballSports,
      tennis: tennisSports,
      basketball: basketballSports,
      esports: esportsSports
    };

    return sportsByTab[tab];
  };

  const generateAnalyticsStats = (tab: StatisticsTab): AnalyticsStat[] => {
    const tabAnalytics: Record<StatisticsTab, AnalyticsStat[]> = {
      all: [
        {
          title: 'Общие матчи',
          value: 5678,
          trend: 'up',
          subtext: 'За последний месяц'
        },
        {
          title: 'Сумма ставок',
          value: 15200000,
          trend: 'up',
          subtext: 'В евро'
        }
      ],
      football: [
        {
          title: 'Матчи в Лиге',
          value: 380,
          trend: 'up',
          subtext: 'В текущем сезоне'
        },
        {
          title: 'Голы',
          value: 1245,
          trend: 'neutral',
          subtext: 'Средний показатель'
        }
      ],
      tennis: [
        {
          title: 'Турниры',
          value: 45,
          trend: 'up',
          subtext: 'Grand Slam и ATP'
        },
        {
          title: 'Призовой фонд',
          value: 25000000,
          trend: 'up',
          subtext: 'В долларах США'
        }
      ],
      basketball: [
        {
          title: 'Игры NBA',
          value: 1230,
          trend: 'up',
          subtext: 'За сезон'
        },
        {
          title: 'Очки в среднем',
          value: 112,
          trend: 'neutral',
          subtext: 'За игру'
        }
      ],
      esports: [
        {
          title: 'Киберспортивные турниры',
          value: 250,
          trend: 'up',
          subtext: 'Международные и локальные'
        },
        {
          title: 'Призовой фонд',
          value: 35000000,
          trend: 'up',
          subtext: 'В долларах США'
        }
      ]
    };

    return tabAnalytics[tab];
  };

  const sports = generateSportStatistics(activeTab);
  const analyticsStats = generateAnalyticsStats(activeTab);

  // Rest of the component remains the same as in the previous implementation
  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Tab Selection */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          marginBottom: '15px',
          backgroundColor: 'white',
          borderRadius: '20px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        {(['all', 'football', 'tennis', 'basketball', 'esports'] as StatisticsTab[]).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              backgroundColor: activeTab === tab ? '#6b0c17' : 'transparent',
              color: activeTab === tab ? 'white' : '#666',
              border: 'none',
              borderRadius: '15px',
              padding: '8px 15px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            {tab === 'all' ? 'Все' : 
             tab === 'football' ? 'Футбол' : 
             tab === 'tennis' ? 'Теннис' : 
             tab === 'basketball' ? 'Баскетбол' : 
             'Киберспорт'}
          </button>
        ))}
      </div>

      {/* Statistics Content */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px'
          }}
        >
          {activeTab === 'all' ? 'Все виды спорта' : 
           activeTab === 'football' ? 'Футбольная статистика' : 
           activeTab === 'tennis' ? 'Теннисные результаты' : 
           activeTab === 'basketball' ? 'Баскетбольные показатели' : 
           'Киберспортивная статистика'}
        </h2>

        {sports.length === 0 ? (
          <div 
            style={{
              textAlign: 'center',
              color: '#666',
              padding: '20px'
            }}
          >
            Нет доступных статистических данных
          </div>
        ) : (
          <>
            {/* Sports Statistics */}
            {sports.map((sport, index) => (
              <div 
                key={index}
                style={{
                  backgroundColor: '#f9fafb',
                  borderRadius: '8px',
                  padding: '15px',
                  marginBottom: '10px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
                }}
              >
                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '15px'
                  }}
                >
                  <span 
                    style={{ 
                      fontSize: '24px' 
                    }}
                  >
                    {sport.icon}
                  </span>
                  <div>
                    <div 
                      style={{
                        fontSize: '16px',
                        fontWeight: 'bold',
                        color: '#6b0c17'
                      }}
                    >
                      {sport.name}
                    </div>
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666'
                      }}
                    >
                      Wins: {sport.wins} | Losses: {sport.losses} | Draws: {sport.draws}
                    </div>
                  </div>
                </div>
                <div>
                  <div 
                    style={{
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: sport.winRate > 50 ? '#10b981' : '#ef4444',
                      textAlign: 'right'
                    }}
                  >
                    Win Rate: {sport.winRate.toFixed(1)}%
                  </div>
                  {sport.rank && (
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666',
                        textAlign: 'right'
                      }}
                    >
                      Rank: {sport.rank}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Analytics Stats */}
            {analyticsStats.map((stat, index) => (
              <div 
                key={index}
                style={{
                  backgroundColor: '#f9fafb',
                  borderRadius: '8px',
                  padding: '15px',
                  marginBottom: '10px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
                }}
              >
                <div>
                  <div 
                    style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#6b0c17'
                    }}
                  >
                    {stat.title}
                  </div>
                  {stat.subtext && (
                    <div 
                      style={{
                        fontSize: '12px',
                        color: '#666',
                        marginTop: '5px'
                      }}
                    >
                      {stat.subtext}
                    </div>
                  )}
                </div>
                <div 
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px'
                  }}
                >
                  <div 
                    style={{
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: stat.trend === 'up' ? '#10b981' : 
                             stat.trend === 'down' ? '#ef4444' : '#6b0c17'
                    }}
                  >
                    {stat.value.toLocaleString()}
                  </div>
                  <div 
                    style={{
                      fontSize: '20px',
                      color: stat.trend === 'up' ? '#10b981' : 
                             stat.trend === 'down' ? '#ef4444' : '#6b0c17'
                    }}
                  >
                    {stat.trend === 'up' ? '▲' : stat.trend === 'down' ? '▼' : '—'}
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
};

export default StatisticsMobile; 