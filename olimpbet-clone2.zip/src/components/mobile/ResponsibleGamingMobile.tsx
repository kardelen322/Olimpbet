import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type WarningSigns = {
  title: string;
  signs: string[];
};

type RiskFactor = {
  title: string;
  description: string;
  risks: string[];
};

type HelpResource = {
  name: string;
  phone?: string;
  contact?: string;
  description: string;
};

type ResponsibleGamingSection = {
  title: string;
  description: string;
  warningSigns?: WarningSigns[];
  risks?: RiskFactor[];
  helpResources?: HelpResource[];
};

const ResponsibleGamingMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();

  const generateResponsibleGamingSections = (): ResponsibleGamingSection[] => {
    // Type-safe responsible gaming sections generation with fallback
    const responsibleGaming = (mockData as any).responsibleGaming || {};

    return [
      {
        title: 'Предупреждение о рисках',
        description: 'Важно понимать потенциальные риски азартных игр и уметь их контролировать.',
        warningSigns: (responsibleGaming.warningSigns || []).map((sign: any) => ({
          title: sign.title || 'Unnamed Warning',
          signs: sign.signs || []
        }))
      },
      {
        title: 'Признаки зависимости',
        description: 'Будьте внимательны к следующим признакам проблемного поведения:',
        risks: (responsibleGaming.riskFactors || []).map((factor: any) => ({
          title: factor.title || 'Unnamed Risk',
          description: factor.description || '',
          risks: factor.risks || []
        }))
      },
      {
        title: 'Ресурсы помощи',
        description: 'Если вы чувствуете, что контроль над игрой теряется, обратитесь за профессиональной поддержкой:',
        helpResources: (responsibleGaming.helpResources || []).map((resource: any) => ({
          name: resource.name || 'Unnamed Resource',
          phone: resource.phone,
          contact: resource.contact,
          description: resource.description || 'Дополнительная информация недоступна'
        }))
      }
    ];
  };

  const responsibleGamingSections = generateResponsibleGamingSections();

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Page Header */}
      <div 
        style={{
          backgroundColor: 'white',
          padding: '20px',
          borderRadius: '12px',
          marginBottom: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}
      >
        <h1 
          style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 10px 0'
          }}
        >
          {translate('responsibleGaming')}
        </h1>
        <p 
          style={{
            fontSize: '14px',
            color: '#666',
            margin: '0'
          }}
        >
          Безопасность и контроль в игре
        </p>
      </div>

      {/* Responsible Gaming Sections */}
      {responsibleGamingSections.map((section, sectionIndex) => (
        <div 
          key={sectionIndex}
          style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '15px',
            marginBottom: '15px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}
        >
          <h2 
            style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: '#6b0c17',
              marginBottom: '10px'
            }}
          >
            {section.title}
          </h2>
          
          <p 
            style={{
              fontSize: '14px',
              color: '#666',
              marginBottom: '15px'
            }}
          >
            {section.description}
          </p>

          {section.warningSigns && section.warningSigns.length > 0 && (
            <div>
              {section.warningSigns.map((warning, warningIndex) => (
                <div 
                  key={warningIndex}
                  style={{
                    backgroundColor: '#f9fafb',
                    borderRadius: '8px',
                    padding: '12px',
                    marginBottom: '10px'
                  }}
                >
                  <h3 
                    style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#6b0c17',
                      marginBottom: '10px'
                    }}
                  >
                    {warning.title}
                  </h3>
                  <ul 
                    style={{
                      paddingLeft: '20px',
                      margin: 0,
                      fontSize: '14px',
                      color: '#333'
                    }}
                  >
                    {warning.signs.map((sign, signIndex) => (
                      <li key={signIndex}>{sign}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {section.risks && section.risks.length > 0 && (
            <div>
              {section.risks.map((risk, riskIndex) => (
                <div 
                  key={riskIndex}
                  style={{
                    backgroundColor: '#f9fafb',
                    borderRadius: '8px',
                    padding: '12px',
                    marginBottom: '10px'
                  }}
                >
                  <h3 
                    style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#6b0c17',
                      marginBottom: '10px'
                    }}
                  >
                    {risk.title}
                  </h3>
                  <p 
                    style={{
                      fontSize: '14px',
                      color: '#666',
                      marginBottom: '10px'
                    }}
                  >
                    {risk.description}
                  </p>
                  <ul 
                    style={{
                      paddingLeft: '20px',
                      margin: 0,
                      fontSize: '14px',
                      color: '#333'
                    }}
                  >
                    {risk.risks.map((riskItem, riskItemIndex) => (
                      <li key={riskItemIndex}>{riskItem}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {section.helpResources && section.helpResources.length > 0 && (
            <div>
              {section.helpResources.map((resource, resourceIndex) => (
                <div 
                  key={resourceIndex}
                  style={{
                    backgroundColor: '#f9fafb',
                    borderRadius: '8px',
                    padding: '12px',
                    marginBottom: '10px',
                    display: 'flex',
                    flexDirection: 'column'
                  }}
                >
                  <h3 
                    style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#6b0c17',
                      marginBottom: '10px'
                    }}
                  >
                    {resource.name}
                  </h3>
                  <p 
                    style={{
                      fontSize: '14px',
                      color: '#666',
                      marginBottom: '10px'
                    }}
                  >
                    {resource.description}
                  </p>
                  {resource.phone && (
                    <div 
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        marginBottom: '5px'
                      }}
                    >
                      <span 
                        style={{
                          marginRight: '10px',
                          color: '#6b0c17',
                          fontWeight: 'bold'
                        }}
                      >
                        Телефон:
                      </span>
                      <a 
                        href={`tel:${resource.phone}`}
                        style={{
                          color: '#333',
                          textDecoration: 'none'
                        }}
                      >
                        {resource.phone}
                      </a>
                    </div>
                  )}
                  {resource.contact && (
                    <div 
                      style={{
                        display: 'flex',
                        alignItems: 'center'
                      }}
                    >
                      <span 
                        style={{
                          marginRight: '10px',
                          color: '#6b0c17',
                          fontWeight: 'bold'
                        }}
                      >
                        Контакт:
                      </span>
                      <a 
                        href={`mailto:${resource.contact}`}
                        style={{
                          color: '#333',
                          textDecoration: 'none'
                        }}
                      >
                        {resource.contact}
                      </a>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      {/* Self-Exclusion and Limit Setting */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}
        >
          🛑 Самоограничение
        </h2>
        <p 
          style={{
            fontSize: '14px',
            color: '#333',
            marginBottom: '15px'
          }}
        >
          Вы можете установить личные ограничения для контроля своей игровой активности:
        </p>
        <div 
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '10px'
          }}
        >
          {[
            'Лимит депозита',
            'Лимит времени игры',
            'Период самоисключения',
            'Полная блокировка аккаунта'
          ].map((limit, limitIndex) => (
            <div 
              key={limitIndex}
              style={{
                backgroundColor: '#f3f4f6',
                padding: '12px',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <span 
                style={{ 
                  fontSize: '14px', 
                  color: '#333', 
                  fontWeight: 'bold' 
                }}
              >
                {limit}
              </span>
              <span 
                style={{ 
                  fontSize: '20px', 
                  color: '#6b0c17' 
                }}
              >
                🔒
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Emergency Contact */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}
        >
          📞 Экстренная поддержка
        </h2>
        <div 
          style={{
            backgroundColor: '#f0f9ff',
            padding: '15px',
            borderRadius: '12px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            textAlign: 'center'
          }}
        >
          <p 
            style={{
              fontSize: '14px',
              color: '#333',
              marginBottom: '15px'
            }}
          >
            Если вам нужна немедленная помощь, свяжитесь с нашей круглосуточной службой поддержки:
          </p>
          <div 
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '10px',
              width: '100%'
            }}
          >
            <div 
              style={{
                backgroundColor: 'white',
                padding: '12px',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <span 
                style={{ 
                  fontSize: '14px', 
                  color: '#333', 
                  fontWeight: 'bold' 
                }}
              >
                Телефон поддержки
              </span>
              <a 
                href="tel:+78005553535" 
                style={{ 
                  fontSize: '16px', 
                  color: '#6b0c17', 
                  textDecoration: 'none' 
                }}
              >
                8 (800) 555-35-35
              </a>
            </div>
            <div 
              style={{
                backgroundColor: 'white',
                padding: '12px',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <span 
                style={{ 
                  fontSize: '14px', 
                  color: '#333', 
                  fontWeight: 'bold' 
                }}
              >
                Электронная почта
              </span>
              <a 
                href="mailto:support@olimpbet.com" 
                style={{ 
                  fontSize: '16px', 
                  color: '#6b0c17', 
                  textDecoration: 'none' 
                }}
              >
                support@olimpbet.com
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResponsibleGamingMobile; 