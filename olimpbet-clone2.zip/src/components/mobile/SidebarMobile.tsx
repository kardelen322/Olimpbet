import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

interface SidebarMobileProps {
  isOpen?: boolean;
  onToggle?: () => void;
  showAsOverlay?: boolean;
}

const SidebarMobile: React.FC<SidebarMobileProps> = ({ 
  isOpen = true, 
  onToggle, 
  showAsOverlay = false 
}) => {
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['live']);
  const [checkedSports, setCheckedSports] = useState<string[]>([]);
  const { translate, isRTL } = useLanguage();

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const toggleSportCheck = (sportId: string) => {
    setCheckedSports(prev => 
      prev.includes(sportId) 
        ? prev.filter(id => id !== sportId)
        : [...prev, sportId]
    );
  };

  const sidebarContent = (
    <div 
      style={{
        width: showAsOverlay ? '300px' : '100%',
        backgroundColor: '#f8f9fa',
        minHeight: showAsOverlay ? '100vh' : '400px',
        overflow: 'auto',
        border: showAsOverlay ? 'none' : '1px solid #e5e7eb',
        borderRadius: showAsOverlay ? '0' : '8px',
        fontFamily: 'Tahoma, Verdana, Arial, Helvetica, sans-serif',
        fontSize: '14px',
        padding: '0',
        boxShadow: showAsOverlay ? 'none' : '0 2px 8px rgba(0, 0, 0, 0.1)',
        position: 'relative',
        verticalAlign: 'top'
      }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Mobile Header for Overlay */}
      {showAsOverlay && (
        <div style={{
          padding: '15px',
          backgroundColor: '#6b0c17',
          color: 'white',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid rgba(255,255,255,0.2)'
        }}>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 'bold' }}>
            Sports & Betting
          </h3>
          {onToggle && (
            <button 
              onClick={onToggle}
              style={{
                background: 'none',
                border: 'none',
                color: 'white',
                fontSize: '20px',
                cursor: 'pointer',
                padding: '5px'
              }}
            >
              ×
            </button>
          )}
        </div>
      )}

      {/* Search Bar */}
      <div style={{ padding: '15px' }}>
        <div style={{ 
          position: 'relative',
          display: 'flex',
          alignItems: 'stretch',
          border: '2px solid #6B0C17',
          borderRadius: '6px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
          overflow: 'hidden'
        }}>
          <input 
            type="text" 
            name="search"
            id="search_text"
            placeholder="Поиск событий/команд"
            style={{
              flex: '1',
              padding: '12px',
              border: 'none',
              borderRadius: '0',
              fontSize: '14px',
              outline: 'none',
              backgroundColor: 'white',
              fontFamily: 'Tahoma, Verdana, Arial, Helvetica, sans-serif',
              textAlign: isRTL ? 'right' : 'left'
            }}
          />
          <button 
            type="button"
            id="search_button"
            style={{
              backgroundColor: '#6B0C17',
              color: 'white',
              border: 'none',
              padding: '12px 16px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              minWidth: '50px'
            }}
          >
            🔍
          </button>
        </div>
      </div>

      {/* Sports Categories - Mobile Optimized */}
      <div style={{ paddingBottom: '20px' }}>
        
        {/* Live Betting Header */}
        <div style={{
          backgroundColor: '#6B0C17',
          color: 'white',
          padding: '12px 15px',
          fontWeight: 'bold',
          fontSize: '16px',
          borderBottom: '1px solid #f3f4f6'
        }}>
          <div style={{ marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '10px',
              height: '10px',
              borderRadius: '50%',
              backgroundColor: '#ef4444',
              animation: 'pulse 2s infinite'
            }}></div>
            <span style={{ fontWeight: 'bold' }}>Ставки Лайв</span> 
            <span style={{ color: 'white', fontWeight: 'bold', marginLeft: '5px' }}>(155)</span>
          </div>
        </div>
        
        {/* Live Schedule */}
        <div style={{ 
          padding: '15px',
          borderBottom: '1px solid #f3f4f6',
          backgroundColor: 'white'
        }}>
          <div style={{ 
            marginBottom: '12px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <div style={{
              width: '16px',
              height: '16px',
              backgroundColor: '#6B0C17',
              borderRadius: '2px',
              position: 'relative'
            }}>
              <div style={{
                position: 'absolute',
                bottom: '1px',
                right: '1px',
                width: '8px',
                height: '8px',
                backgroundColor: 'white',
                borderRadius: '1px'
              }}></div>
            </div>
            <a href="/live" style={{ 
              color: '#6B0C17', 
              textDecoration: 'none',
              fontSize: '14px'
            }}>
              Расписание Лайв
            </a>
          </div>
          
          <div style={{ marginBottom: '12px' }}>
            <a href="/bets247" style={{ 
              color: 'black', 
              textDecoration: 'none',
              fontWeight: 'bold',
              fontSize: '14px'
            }}>
              <span style={{ fontWeight: 'bold' }}>Ставки 24/7</span>
            </a>
          </div>
          
          <div style={{ marginBottom: '12px' }}>
            <a href="/bonuses" style={{ 
              color: 'black', 
              textDecoration: 'none',
              fontWeight: 'bold',
              fontSize: '14px'
            }}>
              <span style={{ fontWeight: 'bold' }}>Специальные предложения</span>
            </a>
          </div>
          
          <div style={{ marginBottom: '12px' }}>
            <a href="/esports" style={{ 
              color: 'black', 
              textDecoration: 'none',
              fontWeight: 'bold',
              fontSize: '14px'
            }}>
              <span style={{ fontWeight: 'bold' }}>Киберспорт</span>
            </a>
          </div>
        </div>

        {/* Sports List - Mobile Optimized */}
        <div style={{ 
          backgroundColor: 'white',
          borderBottom: '1px solid #f3f4f6'
        }}>
          {[
            { id: '1', name: 'Футбол', count: 1160, icon: '⚽', href: '/sports', popular: true },
            { id: '3', name: 'Теннис', count: 321, icon: '🎾', href: '/sports', popular: true },
            { id: '2', name: 'Хоккей', count: 46, icon: '🏒', href: '/sports', popular: true },
            { id: '5', name: 'Баскетбол', count: 43, icon: '🏀', href: '/sports', popular: true },
            { id: '112', name: 'Киберспорт', count: 263, icon: '🎮', href: '/esports', popular: true },
            { id: '40', name: 'Настольный теннис', count: 266, icon: '🏓', href: '/sports', popular: false },
            { id: '143', name: 'Кулачные бои', count: 26, icon: '🥊', href: '/sports', popular: false },
            { id: '12', name: 'Бокс', count: 24, icon: '🥊', href: '/sports', popular: false },
            { id: '96', name: 'Смешанные единоборства', count: 77, icon: '🥋', href: '/sports', popular: false },
            { id: '10', name: 'Волейбол', count: 20, icon: '🏐', href: '/sports', popular: false },
            { id: '92', name: 'Дартс', count: 34, icon: '🎯', href: '/sports', popular: false },
            { id: '97', name: 'Гольф', count: 110, icon: '⛳', href: '/sports', popular: false },
            { id: '11', name: 'Американский футбол', count: 16, icon: '🏈', href: '/sports', popular: false },
            { id: '85', name: 'Бейсбол', count: 10, icon: '⚾', href: '/sports', popular: false },
            { id: '89', name: 'Крикет', count: 27, icon: '🏏', href: '/sports', popular: false },
            { id: '91', name: 'Велоспорт', count: 22, icon: '🚴', href: '/sports', popular: false },
            { id: '94', name: 'Формула 1', count: 29, icon: '🏎️', href: '/sports', popular: false },
            { id: '104', name: 'Регби', count: 37, icon: '🏉', href: '/sports', popular: false }
          ].map((sport, index) => (
            <div key={sport.id} style={{
              display: 'flex',
              alignItems: 'center',
              padding: '12px 15px',
              borderBottom: '1px solid #f9f9f9',
              fontSize: '14px',
              gap: '12px',
              backgroundColor: sport.popular ? '#f8fafe' : 'white',
              borderLeft: sport.popular ? '4px solid #6B0C17' : 'none'
            }}>
              {/* Checkbox */}
              <input
                type="checkbox"
                id={`sport_${sport.id}`}
                checked={checkedSports.includes(sport.id)}
                onChange={() => toggleSportCheck(sport.id)}
                style={{
                  width: '18px',
                  height: '18px',
                  cursor: 'pointer',
                  accentColor: '#6B0C17'
                }}
              />
              
              {/* Sport Icon */}
              <span style={{ fontSize: '18px' }}>{sport.icon}</span>
              
              {/* Sport Info */}
              <div style={{ flex: 1 }}>
                <a href={sport.href} style={{
                  color: sport.popular ? '#6B0C17' : '#374151',
                  textDecoration: 'none',
                  fontWeight: sport.popular ? 'bold' : '500',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  width: '100%'
                }}>
                  <span>{sport.name}</span>
                  <span style={{
                    backgroundColor: '#6B0C17',
                    color: 'white',
                    padding: '2px 8px',
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: 'bold',
                    minWidth: '35px',
                    textAlign: 'center'
                  }}>
                    {sport.count}
                  </span>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div style={{ padding: '15px', backgroundColor: 'white' }}>
          {/* Outrights */}
          <div style={{ marginBottom: '15px', textAlign: 'center' }}>
            <a href="/sports" style={{ 
              color: '#374151', 
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: 'bold'
            }}>
              <b>Фьючерсы</b>
            </a>
          </div>

          {/* Select All */}
          <div style={{ marginBottom: '15px', textAlign: 'center' }}>
            <a href="javascript:selall();" style={{ 
              color: '#6B0C17', 
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500'
            }}>
              Выбрать все виды спорта (2531)
            </a>
          </div>

          {/* Show Button - Mobile Optimized */}
          <button style={{
            backgroundColor: '#6b0c17',
            color: 'white',
            border: 'none',
            padding: '15px 20px',
            borderRadius: '8px',
            fontSize: '16px',
            cursor: 'pointer',
            fontWeight: 'bold',
            width: '100%',
            textTransform: 'uppercase',
            letterSpacing: '0.5px'
          }}>
            ПОКАЗАТЬ
          </button>
          
          {/* Add CSS for pulse animation */}
          <style>{`
            @keyframes pulse {
              0% { opacity: 1; }
              50% { opacity: 0.5; }
              100% { opacity: 1; }
            }
          `}</style>
        </div>
      </div>
    </div>
  );

  // If showAsOverlay, wrap in overlay container
  if (showAsOverlay && isOpen) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100vh',
        backgroundColor: 'rgba(0,0,0,0.5)',
        zIndex: 9998,
        display: 'flex'
      }}>
        {sidebarContent}
        {/* Overlay area - clicking closes sidebar */}
        <div 
          style={{ flex: 1 }}
          onClick={onToggle}
        />
      </div>
    );
  }

  // Regular inline display
  if (!showAsOverlay || isOpen) {
    return sidebarContent;
  }

  // Hidden state for inline display
  return null;
};

export default SidebarMobile; 