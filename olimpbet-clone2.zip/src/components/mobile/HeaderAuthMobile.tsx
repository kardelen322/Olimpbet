import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useAuth } from '../../contexts/AuthContext';
import AuthModalMobile from './AuthModalMobile';
import UserSidebarMobile from './UserSidebarMobile';

const HeaderAuthMobile: React.FC = () => {
  const { translate } = useLanguage();
  const { currentUser } = useAuth();
  
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authModalView, setAuthModalView] = useState<'login' | 'register'>('login');
  const [showUserSidebar, setShowUserSidebar] = useState(false);

  const handleLogin = () => {
    setAuthModalView('login');
    setShowAuthModal(true);
  };

  const handleRegister = () => {
    setAuthModalView('register');
    setShowAuthModal(true);
  };

  const handleCloseAuthModal = () => {
    setShowAuthModal(false);
  };

  // We're now using the UserSidebarMobile for logout functionality
  // const handleLogout = () => {
  //   logout();
  // };

  const toggleUserSidebar = () => {
    setShowUserSidebar(prev => !prev);
  };

  const closeUserSidebar = () => {
    setShowUserSidebar(false);
  };

  if (currentUser) {
    return (
      <div style={styles.authContainer}>
        <span style={styles.welcomeText}>
          {translate('welcome')}, {currentUser.username || currentUser.phone}!
        </span>

        {/* User Profile Picture */}
        <div 
          onClick={toggleUserSidebar}
          style={styles.profilePicture}
        >
          <img
            src="/app-banner-logo.png"
            alt={translate('user')}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain'
            }}
          />
        </div>

        {/* User Sidebar */}
        <UserSidebarMobile isOpen={showUserSidebar} onClose={closeUserSidebar} />
      </div>
    );
  }

  return (
    <>
      <div style={styles.authContainer}>
        <button 
          onClick={handleLogin}
          style={styles.authButton}
        >
          {translate('login')}
        </button>
        <button 
          onClick={handleRegister}
          style={styles.registerButton}
        >
          {translate('joinNow')}
        </button>
      </div>

      {showAuthModal && (
        <AuthModalMobile 
          initialView={authModalView} 
          onClose={handleCloseAuthModal} 
        />
      )}
    </>
  );
};

const styles = {
  authContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '10px 15px',
    backgroundColor: '#6b0c17',
    gap: 10,
  },
  welcomeText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold' as const,
    flex: 1,
    textAlign: 'center' as const,
  },
  profilePicture: {
    width: '36px',
    height: '36px',
    backgroundColor: 'white',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    cursor: 'pointer',
    border: '2px solid #FFD700'
  },
  authButton: {
    backgroundColor: 'white',
    color: '#6b0c17',
    border: 'none',
    borderRadius: '4px',
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    flex: 1,
  },
  registerButton: {
    backgroundColor: '#FFD700',
    color: '#6b0c17',
    border: 'none',
    borderRadius: '4px',
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    flex: 1,
    textTransform: 'uppercase' as const,
  }
};

export default HeaderAuthMobile;