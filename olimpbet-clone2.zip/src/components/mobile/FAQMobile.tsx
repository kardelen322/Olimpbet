import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import mockData from '../../mockData';

type FAQCategory = {
  title: string;
  icon: string;
  questions: {
    question: string;
    answer: string;
    tags?: string[];
  }[];
};

const FAQMobile: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const generateFAQCategories = (): FAQCategory[] => {
    // Type-safe FAQ generation with fallback
    const faqCategories = (mockData as any).faq?.categories || [];
    
    return faqCategories.map((category: any) => ({
      title: category.title || 'Unnamed Category',
      icon: category.icon || '❓',
      questions: (category.questions || []).map((q: any) => ({
        question: q.question || 'Unnamed Question',
        answer: q.answer || 'No answer available',
        tags: q.tags || []
      }))
    }));
  };

  const faqCategories = generateFAQCategories();

  const toggleCategory = (title: string) => {
    setActiveCategory(activeCategory === title ? null : title);
  };

  return (
    <div 
      style={{ 
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        backgroundColor: '#f5f5f5',
        minHeight: '100vh',
        padding: '15px'
      }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Page Header */}
      <div 
        style={{
          backgroundColor: 'white',
          padding: '20px',
          borderRadius: '12px',
          marginBottom: '15px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}
      >
        <h1 
          style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 10px 0'
          }}
        >
          {translate('faq')}
        </h1>
        <p 
          style={{
            fontSize: '14px',
            color: '#666',
            margin: '0'
          }}
        >
          Часто задаваемые вопросы
        </p>
      </div>

      {/* Search Bar */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          marginBottom: '15px',
          padding: '10px',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
        }}
      >
        <div 
          style={{
            display: 'flex',
            alignItems: 'center',
            backgroundColor: '#f9fafb',
          borderRadius: '8px',
            padding: '10px'
          }}
        >
          <span 
            style={{ 
              fontSize: '20px', 
              marginRight: '10px', 
              color: '#6b0c17' 
            }}
          >
            🔍
          </span>
          <input 
            type="text"
            placeholder="Поиск вопросов..."
            style={{
              flex: 1,
              border: 'none',
              backgroundColor: 'transparent',
              fontSize: '14px',
              outline: 'none'
            }}
          />
        </div>
      </div>

      {/* FAQ Categories */}
      {faqCategories.map((category, categoryIndex) => (
        <div 
          key={categoryIndex}
          style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            marginBottom: '15px',
            overflow: 'hidden',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}
        >
          {/* Category Header */}
          <div 
            onClick={() => toggleCategory(category.title)}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '15px',
              backgroundColor: '#f9fafb',
              cursor: 'pointer'
            }}
          >
            <div 
              style={{
              display: 'flex',
                alignItems: 'center',
                gap: '15px'
              }}
            >
              <span 
                style={{ 
                  fontSize: '24px' 
                }}
              >
                {category.icon}
              </span>
              <h2 
                style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#6b0c17',
                  margin: 0
                }}
              >
                {category.title}
              </h2>
            </div>
            <span 
              style={{ 
                fontSize: '20px', 
                color: '#6b0c17' 
              }}
            >
              {activeCategory === category.title ? '▼' : '►'}
            </span>
                </div>
                
          {/* Category Questions */}
          {activeCategory === category.title && (
            <div 
              style={{
                padding: '15px',
                backgroundColor: 'white'
              }}
            >
              {category.questions.map((faq, faqIndex) => (
                <div 
                  key={faqIndex}
                  style={{
                    backgroundColor: '#f9fafb',
                    borderRadius: '8px',
                    padding: '12px',
                    marginBottom: '10px'
                  }}
                >
                  <div 
                    style={{
                  display: 'flex',
                      justifyContent: 'space-between',
                  alignItems: 'center',
                      marginBottom: '10px'
                    }}
                  >
                    <h3 
                      style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                        color: '#6b0c17',
                        margin: 0,
                        flex: 1
                      }}
                    >
                      {faq.question}
                    </h3>
              </div>

                  <div 
                    style={{
                      fontSize: '14px',
                      color: '#333',
                      lineHeight: 1.6
                    }}
                  >
                    {faq.answer}
                  </div>

                  {faq.tags && faq.tags.length > 0 && (
                    <div 
                      style={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        gap: '5px',
                        marginTop: '10px'
                      }}
                    >
                      {faq.tags.map((tag, tagIndex) => (
                        <span 
                          key={tagIndex}
                          style={{
                            backgroundColor: '#e5e7eb',
                            color: '#666',
                          fontSize: '12px',
                            padding: '4px 8px',
                            borderRadius: '12px'
                          }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      {/* Quick Help Section */}
      <div 
        style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        <h2 
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            marginBottom: '15px',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}
        >
          📞 Нужна дополнительная помощь?
        </h2>
        <div 
          style={{
            backgroundColor: '#f0f9ff',
            padding: '15px',
            borderRadius: '12px',
            display: 'flex',
            flexDirection: 'column',
            gap: '10px'
          }}
        >
          <div 
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}
          >
            <span 
              style={{ 
                fontSize: '14px', 
                color: '#333', 
                fontWeight: 'bold' 
              }}
            >
              Телефон поддержки
            </span>
            <a 
              href="tel:+78005553535" 
              style={{ 
                fontSize: '14px', 
                color: '#6b0c17', 
                textDecoration: 'none' 
              }}
            >
              8 (800) 555-35-35
            </a>
          </div>
          <div 
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}
          >
            <span 
              style={{ 
            fontSize: '14px',
                color: '#333', 
                fontWeight: 'bold' 
              }}
            >
              Электронная почта
            </span>
            <a 
              href="mailto:support@olimpbet.com" 
              style={{ 
            fontSize: '14px',
                color: '#6b0c17', 
                textDecoration: 'none' 
              }}
            >
              support@olimpbet.com
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQMobile; 