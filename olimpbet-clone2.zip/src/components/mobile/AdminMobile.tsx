import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { usePayment } from '../../contexts/PaymentContext';
import { useNavigate } from 'react-router-dom';
import { getAllUsers, getAllFailedLoginAttempts, deleteUser } from '../../database';

interface User {
  id?: number;
  phone: string;
  username?: string;
  created_at?: string;
}

const AdminMobile: React.FC = () => {
  const { isAuthenticated, currentUser, logout } = useAuth();
  const { translate, currentLanguage, setLanguage } = useLanguage();
  const { depositRequests, approveDepositRequest, rejectDepositRequest } = usePayment();
  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [failedAttempts, setFailedAttempts] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'users' | 'attempts' | 'deposit-requests'>('users');
  const [adminPassword, setAdminPassword] = useState<string>('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState<boolean>(false);
  const [sessionTimeout, setSessionTimeout] = useState<NodeJS.Timeout | null>(null);
  const [lastActivity, setLastActivity] = useState<number>(Date.now());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  // Session timeout management
  const resetSessionTimeout = useCallback(() => {
    if (sessionTimeout) {
      clearTimeout(sessionTimeout);
    }
    
    const timeout = setTimeout(() => {
      alert(translate('admin_session_expired'));
      logout();
      navigate('/');
    }, 10 * 60 * 1000); // 10 minutes timeout
    
    setSessionTimeout(timeout);
    setLastActivity(Date.now());
  }, [sessionTimeout, logout, navigate, translate]);

  // Track user activity
  const handleActivity = useCallback(() => {
    setLastActivity(Date.now());
    resetSessionTimeout();
  }, [resetSessionTimeout]);

  // Load users and failed attempts from database
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        
        // Load users
        const usersData = await getAllUsers();
        setUsers(usersData);
        
        // Load failed login attempts
        const attemptsData = await getAllFailedLoginAttempts();
        setFailedAttempts(attemptsData);
        
        setLoading(false);
        resetSessionTimeout(); // Start session timeout
      } catch (err) {
        console.error('Failed to load data:', err);
        setError('Failed to load data');
        setLoading(false);
      }
    };
    
    loadData();
  }, [resetSessionTimeout]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (sessionTimeout) {
        clearTimeout(sessionTimeout);
      }
    };
  }, [sessionTimeout]);

  // Add activity listeners
  useEffect(() => {
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    
    events.forEach(event => {
      document.addEventListener(event, handleActivity, true);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, handleActivity, true);
      });
    };
  }, [handleActivity]);

  // Check if user is admin (simplified for demo - any authenticated user can access admin)
  const isAdmin = () => {
    return isAuthenticated && currentUser;
  };

  // Verify admin password for sensitive operations
  const verifyAdminPassword = async (password: string): Promise<boolean> => {
    try {
      const storedUsers = localStorage.getItem('db_users');
      if (storedUsers && currentUser) {
        const parsedUsers = JSON.parse(storedUsers);
        const adminUser = parsedUsers.find((user: any) => user.phone === currentUser.phone);
        if (adminUser) {
          // For demo purposes, we'll use a simple comparison
          // In a real app, you would use proper password hashing verification
          return password === 'admin123'; // Simple demo password
        }
      }
    } catch (error) {
      console.error('Error verifying admin password:', error);
    }
    return false;
  };

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
        <div className="bg-white p-6 rounded-lg shadow-md w-full">
          <h1 className="text-xl font-bold text-center text-red-600 mb-3">
            {translate('access_denied')}
          </h1>
          <p className="text-center text-gray-700 text-sm">
            {translate('login_required')}
          </p>
        </div>
      </div>
    );
  }

  if (!isAdmin()) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
        <div className="bg-white p-6 rounded-lg shadow-md w-full">
          <h1 className="text-xl font-bold text-center text-red-600 mb-3">
            {translate('admin_access_denied')}
          </h1>
          <p className="text-center text-gray-700 text-sm">
            {translate('admin_required')}
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
        <div className="bg-white p-6 rounded-lg shadow-md w-full">
          <h1 className="text-xl font-bold text-center text-red-600 mb-3">
            {translate('errorMessage')}
          </h1>
          <p className="text-center text-gray-700 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  const handleDeleteUser = (phone: string) => {
    setShowDeleteConfirm(phone);
  };

  const confirmDeleteUser = async () => {
    if (!showDeleteConfirm) return;
    
    setShowPasswordPrompt(true);
  };

  const executeDeleteUser = async () => {
    if (!showDeleteConfirm || !adminPassword) return;
    
    const isPasswordValid = await verifyAdminPassword(adminPassword);
    if (!isPasswordValid) {
      setError(translate('invalid_admin_password'));
      setAdminPassword('');
      return;
    }
    
    try {
      // Find the user to delete by phone
      const userToDelete = users.find(user => user.phone === showDeleteConfirm);
      if (userToDelete && userToDelete.id) {
        await deleteUser(userToDelete.id);
        
        // Refresh the users list
        const updatedUsers = await getAllUsers();
        setUsers(updatedUsers);
      }
      
      setShowDeleteConfirm(null);
      setShowPasswordPrompt(false);
      setAdminPassword('');
      handleActivity(); // Reset session timeout
    } catch (err) {
      console.error('Failed to delete user:', err);
      setError('Failed to delete user');
    }
  };

  const cancelDelete = () => {
    setShowDeleteConfirm(null);
    setShowPasswordPrompt(false);
    setAdminPassword('');
  };

  const handleClearAttempts = async () => {
    try {
      // For localStorage fallback, clear the attempts
      if (typeof Storage !== 'undefined') {
        localStorage.setItem('db_failed_login_attempts', JSON.stringify([]));
      }
      setFailedAttempts([]);
    } catch (err) {
      console.error('Failed to clear attempts:', err);
      setError('Failed to clear attempts');
    }
  };

  return (
    <div className="container mx-auto px-3 py-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">{translate('admin_dashboard')}</h1>
        
        {/* Language Selector */}
        <select
          value={currentLanguage}
          onChange={(e) => setLanguage(e.target.value as any)}
          className="px-2 py-1 border border-gray-300 rounded-md text-sm"
        >
          <option value="en">🇺🇸 English</option>
          <option value="tr">🇹🇷 Türkçe</option>
        </select>
      </div>
      
      {/* Session Activity Indicator */}
      {lastActivity && (
        <div className="mb-4 text-sm text-gray-500">
          {translate('last_activity')}: {new Date(lastActivity).toLocaleTimeString()}
        </div>
      )}
      
      {/* Password Confirmation Dialog */}
      {showPasswordPrompt && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-80 shadow-lg rounded-md bg-white">
            <div className="mt-3 text-center">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {translate('confirm_admin_password')}
              </h3>
              <input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder={translate('enter_password')}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                onKeyPress={(e) => e.key === 'Enter' && executeDeleteUser()}
                autoFocus
              />
              <div className="flex justify-center space-x-4">
                <button
                  onClick={executeDeleteUser}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {translate('confirm')}
                </button>
                <button
                  onClick={cancelDelete}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500"
                >
                  {translate('cancel')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Dialog */}
      {showDeleteConfirm && !showPasswordPrompt && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-80 shadow-lg rounded-md bg-white">
            <div className="mt-3 text-center">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {translate('confirm_delete_user')}
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                {translate('delete_user_warning')} {showDeleteConfirm}
              </p>
              <div className="flex justify-center space-x-4">
                <button
                  onClick={confirmDeleteUser}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {translate('delete')}
                </button>
                <button
                  onClick={cancelDelete}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500"
                >
                  {translate('cancel')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Tabs */}
      <div className="flex mb-4 border-b overflow-x-auto">
        <button
          className={`py-2 px-3 text-sm ${activeTab === 'users' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
          onClick={() => setActiveTab('users')}
        >
          {translate('users')}
        </button>
        <button
          className={`py-2 px-3 text-sm ${activeTab === 'attempts' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
          onClick={() => setActiveTab('attempts')}
        >
          {translate('failed_login_attempts')}
        </button>
        <button
          className={`py-2 px-3 text-sm ${activeTab === 'deposit-requests' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
          onClick={() => setActiveTab('deposit-requests')}
        >
          {translate('requests')}
        </button>
      </div>
      
      {/* Users Tab */}
      {activeTab === 'users' && (
        <div>
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-semibold">{translate('user_management')}</h2>
            <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-0.5 rounded">
              {users.length} {translate('users')}
            </span>
          </div>
          
          <div className="overflow-x-auto -mx-3">
            <div className="inline-block min-w-full align-middle">
              <div className="overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('phoneNumber')}
                      </th>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('username')}
                      </th>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('actions')}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {users.map((user) => (
                      <tr key={user.id}>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">
                          {user.phone}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                          {user.username || '-'}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm">
                          <button
                            onClick={() => handleDeleteUser(user.phone)}
                            className="text-red-600 hover:text-red-900 text-xs"
                          >
                            {translate('deleteItem')}
                          </button>
                        </td>
                      </tr>
                    ))}
                    {users.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-3 py-4 text-center text-sm text-gray-500">
                          {translate('no_users_found')}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Deposit Requests Tab */}
      {activeTab === 'deposit-requests' && (
        <div>
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-semibold">{translate('depositRequests')}</h2>
            <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-0.5 rounded">
              {depositRequests.length} {translate('requests')}
            </span>
          </div>
          
          <div className="overflow-x-auto -mx-3">
            <div className="inline-block min-w-full align-middle">
              <div className="overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('id')}
                      </th>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('username')}
                      </th>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('amount')}
                      </th>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('status')}
                      </th>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('actions')}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {depositRequests.length > 0 ? (
                      depositRequests.map((request) => (
                        <tr key={request.id}>
                          <td className="px-3 py-2 whitespace-nowrap text-xs text-gray-900">
                            {request.id}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-xs text-gray-900">
                            {request.username}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-xs text-gray-900">
                            {request.amount.toLocaleString()}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                              request.status === 'approved' ? 'bg-green-100 text-green-800' : 
                              'bg-red-600 text-white'
                            }`}>
                              {translate(request.status)}
                            </span>
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-xs">
                            {request.status === 'pending' && (
                              <div className="flex space-x-2">
                                <button
                                  onClick={async () => await approveDepositRequest(request.id)}
                                  className="bg-green-500 hover:bg-green-600 text-white px-2 py-1 rounded text-xs"
                                >
                                  {translate('approve')}
                                </button>
                                <button
                                  onClick={async () => {
                                    const reason = prompt(translate('enterRejectionReason'));
                                    if (reason) {
                                      await rejectDepositRequest(request.id, reason);
                                    }
                                  }}
                                  className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded text-xs"
                                >
                                  {translate('reject')}
                                </button>
                              </div>
                            )}
                            {request.status === 'rejected' && request.rejectionReason && (
                              <div className="text-xs text-gray-500">
                                <span className="font-medium">{translate('rejectionReason')}:</span> {request.rejectionReason}
                              </div>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-3 py-4 text-center text-sm text-gray-500">
                          {translate('no_deposit_requests_found')}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Failed Login Attempts Tab */}
      {activeTab === 'attempts' && (
        <div>
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-semibold">{translate('failed_login_attempts')}</h2>
            <div>
              <button
                onClick={handleClearAttempts}
                className="text-xs bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded"
                disabled={failedAttempts.length === 0}
              >
                {translate('clear_all')}
              </button>
            </div>
          </div>
          
          <div className="overflow-x-auto -mx-3">
            <div className="inline-block min-w-full align-middle">
              <div className="overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('phoneNumber')}
                      </th>
                      <th scope="col" className="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider text-left">
                        {translate('attempt_time')}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {failedAttempts.map((attempt) => (
                      <tr key={attempt.id}>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">
                          {attempt.phone}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                          {new Date(attempt.attempt_time).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                    {failedAttempts.length === 0 && (
                      <tr>
                        <td colSpan={2} className="px-3 py-4 text-center text-sm text-gray-500">
                          {translate('no_attempts_found')}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminMobile;