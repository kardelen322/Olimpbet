import React, { useState, useMemo } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { CSSProperties } from 'react';
import { TranslationKey } from '../../translations';
import HeaderAuthMobile from './HeaderAuthMobile';
import PaymentButton from '../PaymentButton';

// Icons (using Unicode/emoji for simplicity, but recommend using SVG icons in production)
const ICONS = {
  sports: '⚽',
  live: '🔴',
  bets247: '💰',
  esports: '🎮',
  bonuses: '🎁',
  results: '📊',
  statistics: '📈',
  support: '❓',
  faq: '💬',
  about: 'ℹ️'
};

// Fallback translation function
const defaultTranslate = (key: string): string => {
  // Simple capitalization fallback
  return key
    .replace(/([A-Z])/g, ' $1') // Insert space before capital letters
    .replace(/^./, str => str.toUpperCase()) // Capitalize first letter
    .trim();
};

const HeaderMobile: React.FC = () => {
  const location = useLocation();
  const [activeSection, setActiveSection] = useState(location.pathname.slice(1) || 'sports');

  // Use the language context hook
    const languageContext = useLanguage();

  // Memoized translate function with robust fallback
  const translate = useMemo(() => {
    // Prioritize context translate, fall back to default
    return typeof languageContext?.translate === 'function' 
      ? languageContext.translate 
      : defaultTranslate;
  }, [languageContext]);

  // Memoized RTL state
  const isRTL = useMemo(() => 
    languageContext?.isRTL ?? false, 
    [languageContext]
  );

  // Navigation sections with translation keys
  const sections = [
    { path: '/sports', key: 'sports' },
    { path: '/live', key: 'live' },
    { path: '/bets247', key: 'bets247' },
    { path: '/esports', key: 'esports' },
    { path: '/bonuses', key: 'bonuses' },
    { path: '/results', key: 'results' },
    { path: '/statistics', key: 'statistics' },
    { path: '/support', key: 'support' },
    { path: '/faq', key: 'faq' },
    { path: '/about', key: 'about' }
  ];

  // Styles
  const toolbarStyle: CSSProperties = {
    backgroundColor: '#6b0c17',
    overflowX: 'auto',
    whiteSpace: 'nowrap',
    WebkitOverflowScrolling: 'touch', // Smooth scrolling on iOS
    scrollbarWidth: 'none', // Hide scrollbar for Firefox
    msOverflowStyle: 'none', // Hide scrollbar for Internet Explorer and Edge
  };

  const navStyle: CSSProperties = {
    display: 'flex',
    padding: '10px 0',
    gap: 15, // Increased gap for more spacing
    overflowX: 'scroll',
    scrollbarWidth: 'none'
  };

  return (
    <header style={{ fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif' }} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Top Red Bar - Mobile */}
      <div style={{ 
        backgroundColor: '#6b0c17',
        color: 'white', 
        padding: '0', 
        borderBottom: '1px solid #eee'
      }}>
        <div style={{ 
          maxWidth: '100%', 
          margin: '0 auto', 
          padding: '0 15px', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between', 
          height: 50,
          position: 'relative'
        }}>
          {/* Logo */}
          <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 8, textDecoration: 'none' }}>
            <div style={{ 
              width: 28, 
              height: 28, 
              backgroundColor: 'white', 
              borderRadius: '50%', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              overflow: 'hidden'
            }}>
              <img 
                src="/app-banner-logo.png" 
                alt="OLIMPBET Logo" 
                style={{ 
                  width: '100%', 
                  height: '100%', 
                  objectFit: 'contain'
                }} 
              />
            </div>
            <h1 style={{ 
              fontSize: 18, 
              fontWeight: 'bold', 
              color: 'white', 
              margin: 0,
              marginLeft: 10 // Added margin to separate logo and text
            }}>OLIMPBET</h1>
          </Link>
        </div>

        {/* Mobile Navigation Toolbar */}
        <div style={toolbarStyle}>
          <nav style={navStyle}>
            {sections.map(({ path, key }) => (
              <Link 
                key={key} 
                to={path} 
                onClick={() => setActiveSection(key)}
                style={{ 
              display: 'flex', 
              flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  textDecoration: 'none',
                  padding: '0 15px', // Increased padding
                  color: activeSection === key.replace('/', '') ? '#FFD700' : 'white',
                  transition: 'color 0.3s ease',
                  minWidth: 80, // Increased minimum width
                  textAlign: 'center'
                }}
              >
                <span style={{ 
                  fontSize: 24, 
                  marginBottom: 5,
                  opacity: activeSection === key.replace('/', '') ? 1 : 0.7
                }}>
                  {ICONS[key as keyof typeof ICONS]}
                </span>
                <span style={{ 
                  fontSize: 10, 
                  textTransform: 'uppercase',
                fontWeight: 'bold',
                  whiteSpace: 'nowrap', // Prevent text wrapping
                  overflow: 'hidden',
                  textOverflow: 'ellipsis' // Add ellipsis if text is too long
                }}>
                  {translate(key as TranslationKey)}
                </span>
              </Link>
            ))}
            </nav>
          </div>
      </div>
      
      {/* Auth Section */}
      <HeaderAuthMobile />
    </header>
  );
};

export default HeaderMobile;