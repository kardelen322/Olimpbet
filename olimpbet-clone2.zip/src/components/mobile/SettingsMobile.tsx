import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useAuth } from '../../contexts/AuthContext';
import { useBalance } from '../../contexts/BalanceContext';

const SettingsMobile: React.FC = () => {
  const { translate, setLanguage, currentLanguage } = useLanguage();
  const { currentUser } = useAuth();
  const { currency, updateBalance } = useBalance();
  
  const [activeTab, setActiveTab] = useState<'account' | 'preferences' | 'security'>('account');
  const [formData, setFormData] = useState({
    username: currentUser?.username || '',
    phone: currentUser?.phone || '',
    notificationsEnabled: true,
    marketingEnabled: false,
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  // For backward compatibility with the UI that expects name and email
  const formDataWithLegacyFields = {
    ...formData,
    name: formData.username,
    email: formData.phone + '@example.com' // Using phone as a placeholder for email
  }
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };
  
  const handleAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUser) {
      // In a real app, you would update the user info
      // For now, just show an alert
      alert(translate('settingsSaved'));
    }
  };
  
  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.newPassword !== formData.confirmPassword) {
      alert(translate('passwordsDoNotMatch'));
      return;
    }
    // In a real app, you would validate the current password and update it
    alert(translate('passwordChanged'));
    setFormData({
      ...formData,
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };
  
  const handlePreferencesSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(translate('preferencesSaved'));
  };
  
  return (
    <div style={{ padding: '15px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '15px', fontSize: '20px' }}>
        {translate('settings')}
      </h1>
      
      <div style={{ display: 'flex', marginBottom: '15px', overflowX: 'auto' }}>
        <button 
          onClick={() => setActiveTab('account')}
          style={{
            padding: '8px 15px',
            backgroundColor: activeTab === 'account' ? '#2c3e50' : '#34495e',
            color: 'white',
            border: 'none',
            borderRadius: '4px 0 0 4px',
            cursor: 'pointer',
            fontSize: '14px',
            whiteSpace: 'nowrap'
          }}
        >
          {translate('account')}
        </button>
        <button 
          onClick={() => setActiveTab('preferences')}
          style={{
            padding: '8px 15px',
            backgroundColor: activeTab === 'preferences' ? '#2c3e50' : '#34495e',
            color: 'white',
            border: 'none',
            cursor: 'pointer',
            fontSize: '14px',
            whiteSpace: 'nowrap'
          }}
        >
          {translate('preferences')}
        </button>
        <button 
          onClick={() => setActiveTab('security')}
          style={{
            padding: '8px 15px',
            backgroundColor: activeTab === 'security' ? '#2c3e50' : '#34495e',
            color: 'white',
            border: 'none',
            borderRadius: '0 4px 4px 0',
            cursor: 'pointer',
            fontSize: '14px',
            whiteSpace: 'nowrap'
          }}
        >
          {translate('security')}
        </button>
      </div>
      
      <div style={{ backgroundColor: '#2c3e50', padding: '15px', borderRadius: '8px' }}>
        {activeTab === 'account' && (
          <form onSubmit={handleAccountSubmit}>
            <h2 style={{ marginBottom: '15px', fontSize: '18px' }}>{translate('accountSettings')}</h2>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('name')}</label>
              <input
                type="text"
                name="name"
                value={formDataWithLegacyFields.name}
                onChange={handleInputChange}
                style={{
                  width: '100%',
                  padding: '8px',
                  backgroundColor: '#34495e',
                  border: '1px solid #445566',
                  borderRadius: '4px',
                  color: 'white',
                  fontSize: '14px'
                }}
              />
            </div>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('email')}</label>
              <input
                type="email"
                name="email"
                value={formDataWithLegacyFields.email}
                onChange={handleInputChange}
                style={{
                  width: '100%',
                  padding: '8px',
                  backgroundColor: '#34495e',
                  border: '1px solid #445566',
                  borderRadius: '4px',
                  color: 'white',
                  fontSize: '14px'
                }}
              />
            </div>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('phone')}</label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                disabled
                style={{
                  width: '100%',
                  padding: '8px',
                  backgroundColor: '#445566',
                  border: '1px solid #445566',
                  borderRadius: '4px',
                  color: '#aaa',
                  fontSize: '14px'
                }}
              />
              <small style={{ color: '#bdc3c7', fontSize: '12px' }}>{translate('phoneCannotBeChanged')}</small>
            </div>
            
            <button
              type="submit"
              style={{
                padding: '8px 15px',
                backgroundColor: '#3498db',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                marginTop: '10px',
                fontSize: '14px',
                width: '100%'
              }}
            >
              {translate('saveChanges')}
            </button>
          </form>
        )}
        
        {activeTab === 'preferences' && (
          <form onSubmit={handlePreferencesSubmit}>
            <h2 style={{ marginBottom: '15px', fontSize: '18px' }}>{translate('preferences')}</h2>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('language')}</label>
              <select
                value={currentLanguage}
                onChange={(e) => setLanguage(e.target.value as "ru" | "en" | "tr")}
                style={{
                  width: '100%',
                  padding: '8px',
                  backgroundColor: '#34495e',
                  border: '1px solid #445566',
                  borderRadius: '4px',
                  color: 'white',
                  fontSize: '14px'
                }}
              >
                <option value="en">{translate('languageEnglish')}</option>
                <option value="ru">{translate('languageRussian')}</option>
                <option value="tr">{translate('languageTurkish')}</option>
              </select>
            </div>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', fontSize: '14px' }}>
                <input
                  type="checkbox"
                  name="notificationsEnabled"
                  checked={formData.notificationsEnabled}
                  onChange={handleInputChange}
                  style={{ marginRight: '10px' }}
                />
                {translate('enableNotifications')}
              </label>
            </div>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', fontSize: '14px' }}>
                <input
                  type="checkbox"
                  name="marketingEnabled"
                  checked={formData.marketingEnabled}
                  onChange={handleInputChange}
                  style={{ marginRight: '10px' }}
                />
                {translate('receiveMarketingEmails')}
              </label>
            </div>
            
            <button
              type="submit"
              style={{
                padding: '8px 15px',
                backgroundColor: '#3498db',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                marginTop: '10px',
                fontSize: '14px',
                width: '100%'
              }}
            >
              {translate('saveChanges')}
            </button>
          </form>
        )}
        
        {activeTab === 'security' && (
          <form onSubmit={handlePasswordSubmit}>
            <h2 style={{ marginBottom: '15px', fontSize: '18px' }}>{translate('security')}</h2>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('currentPassword')}</label>
              <input
                type="password"
                name="currentPassword"
                value={formData.currentPassword}
                onChange={handleInputChange}
                style={{
                  width: '100%',
                  padding: '8px',
                  backgroundColor: '#34495e',
                  border: '1px solid #445566',
                  borderRadius: '4px',
                  color: 'white',
                  fontSize: '14px'
                }}
              />
            </div>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('newPassword')}</label>
              <input
                type="password"
                name="newPassword"
                value={formData.newPassword}
                onChange={handleInputChange}
                style={{
                  width: '100%',
                  padding: '8px',
                  backgroundColor: '#34495e',
                  border: '1px solid #445566',
                  borderRadius: '4px',
                  color: 'white',
                  fontSize: '14px'
                }}
              />
            </div>
            
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('confirmPassword')}</label>
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                style={{
                  width: '100%',
                  padding: '8px',
                  backgroundColor: '#34495e',
                  border: '1px solid #445566',
                  borderRadius: '4px',
                  color: 'white',
                  fontSize: '14px'
                }}
              />
            </div>
            
            <button
              type="submit"
              style={{
                padding: '8px 15px',
                backgroundColor: '#3498db',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                marginTop: '10px',
                fontSize: '14px',
                width: '100%'
              }}
            >
              {translate('changePassword')}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default SettingsMobile;