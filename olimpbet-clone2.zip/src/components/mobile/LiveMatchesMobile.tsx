import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import ImageCarouselMobile from './ImageCarouselMobile';

const LiveMatchesMobile: React.FC = () => {
  const [activeTab, setActiveTab] = useState('live');
  const [expandedSections, setExpandedSections] = useState<string[]>(['football', 'tennis']);
  const { translate, isRTL } = useLanguage();

  // Promotional banner images
  const promotionalImages = [
    '/image1.png',
    '/image2.png', 
    '/image3.png',
    '/image4.png',
    '/image5.png',
    '/image6.png'
  ];

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => 
      prev.includes(sectionId) 
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  return (
    <div style={{
      backgroundColor: '#f8f9fa',
      fontFamily: 'Tahoma, Verdana, Arial, Helvetica, sans-serif',
      fontSize: '14px',
      width: '100%'
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      
      {/* Mobile Image Carousel */}
      <div style={{ marginBottom: '15px' }}>
        <ImageCarouselMobile images={promotionalImages} />
      </div>

      {/* Mobile Tabs */}
      <div style={{
        display: 'flex',
        backgroundColor: 'white',
        borderRadius: '8px',
        marginBottom: '15px',
        overflow: 'hidden',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
      }}>
        {[
          { id: 'live', label: translate('live'), count: 155 },
          { id: 'upcoming', label: translate('upcoming'), count: 892 },
          { id: 'finished', label: translate('finished'), count: 45 }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              flex: 1,
              padding: '15px 10px',
              backgroundColor: activeTab === tab.id ? '#6B0C17' : 'white',
              color: activeTab === tab.id ? 'white' : '#374151',
              border: 'none',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold',
              textAlign: 'center',
              borderRight: tab.id !== 'finished' ? '1px solid #f0f0f0' : 'none'
            }}
          >
            <div>{tab.label}</div>
            <div style={{ 
              fontSize: '12px', 
              opacity: 0.8,
              marginTop: '3px'
            }}>
              ({tab.count})
            </div>
          </button>
        ))}
      </div>

      {/* Mobile Sports Sections */}
      
      {/* Football Section */}
      <div style={{ marginBottom: '15px' }}>
        <div 
          onClick={() => toggleSection('football')}
          style={{
            backgroundColor: '#6B0C17',
            color: 'white',
            padding: '15px 20px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            cursor: 'pointer',
            borderRadius: expandedSections.includes('football') ? '8px 8px 0 0' : '8px',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ fontSize: '20px' }}>⚽</span>
            <span style={{ fontWeight: 'bold', fontSize: '16px' }}>{translate('football')}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ 
              backgroundColor: 'rgba(255,255,255,0.2)', 
              padding: '4px 8px', 
              borderRadius: '12px', 
              fontSize: '12px',
              fontWeight: 'bold'
            }}>
              24 {translate('matches')}
            </span>
            <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
              {expandedSections.includes('football') ? '−' : '+'}
            </span>
          </div>
        </div>

        {expandedSections.includes('football') && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '0 0 8px 8px',
            overflow: 'hidden',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
          }}>
            {/* Football matches - Mobile optimized */}
            {[1, 2, 3, 4, 5].map((match) => (
              <div key={`football-match-${match}`} style={{
                padding: '15px',
                borderBottom: match !== 5 ? '1px solid #f0f0f0' : 'none',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px'
              }}>
                {/* Match Header */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontSize: '12px',
                  color: '#666'
                }}>
                  <span>Premier League</span>
                  <span>{new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                
                {/* Teams */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                    flex: 1
                  }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontSize: '14px',
                      fontWeight: '500'
                    }}>
                      <span>🏴󠁧󠁢󠁥󠁮󠁧󠁿</span>
                      <span>{translate('team')} {match}A</span>
                    </div>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontSize: '14px',
                      fontWeight: '500'
                    }}>
                      <span>🏴󠁧󠁢󠁥󠁮󠁧󠁿</span>
                      <span>{translate('team')} {match}B</span>
                    </div>
                  </div>
                  
                  {/* Score (if live) */}
                  <div style={{
                    textAlign: 'center',
                    fontSize: '18px',
                    fontWeight: 'bold',
                    color: '#6B0C17',
                    marginRight: '15px'
                  }}>
                    {activeTab === 'live' ? `${match}-${match-1}` : translate('versus')}
                  </div>
                </div>

                {/* Betting Odds - Mobile Layout */}
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr 1fr',
                  gap: '8px',
                  marginTop: '5px'
                }}>
                  {[
                    { label: '1', value: (1.85 + match * 0.1).toFixed(2) },
                    { label: 'X', value: (3.20 + match * 0.05).toFixed(2) },
                    { label: '2', value: (4.50 - match * 0.1).toFixed(2) }
                  ].map((odd, index) => (
                    <button key={`football-odd-${match}-${index}`} style={{
                      padding: '10px 8px',
                      backgroundColor: '#f8f9fa',
                      border: '1px solid #e0e0e0',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '12px',
                      fontWeight: 'bold',
                      textAlign: 'center',
                      transition: 'all 0.2s ease'
                    }}>
                      <div style={{ color: '#666', marginBottom: '2px' }}>{odd.label}</div>
                      <div style={{ color: '#22c55e' }}>{odd.value}</div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tennis Section */}
      <div style={{ marginBottom: '15px' }}>
        <div 
          onClick={() => toggleSection('tennis')}
          style={{
            backgroundColor: '#6B0C17',
            color: 'white',
            padding: '15px 20px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            cursor: 'pointer',
            borderRadius: expandedSections.includes('tennis') ? '8px 8px 0 0' : '8px',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ fontSize: '20px' }}>🎾</span>
            <span style={{ fontWeight: 'bold', fontSize: '16px' }}>{translate('tennis')}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ 
              backgroundColor: 'rgba(255,255,255,0.2)', 
              padding: '4px 8px', 
              borderRadius: '12px', 
              fontSize: '12px',
              fontWeight: 'bold'
            }}>
              12 {translate('matches')}
            </span>
            <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
              {expandedSections.includes('tennis') ? '−' : '+'}
            </span>
          </div>
        </div>

        {expandedSections.includes('tennis') && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '0 0 8px 8px',
            overflow: 'hidden',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
          }}>
            {/* Tennis matches - Mobile optimized */}
            {[1, 2, 3].map((match) => (
              <div key={`tennis-match-${match}`} style={{
                padding: '15px',
                borderBottom: match !== 3 ? '1px solid #f0f0f0' : 'none',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px'
              }}>
                {/* Match Header */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontSize: '12px',
                  color: '#666'
                }}>
                  <span>ATP 500. Washington</span>
                  <span>{new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                
                {/* Players */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                    flex: 1
                  }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontSize: '14px',
                      fontWeight: '500'
                    }}>
                      <span>🇺🇸</span>
                      <span>Player {match}A</span>
                    </div>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontSize: '14px',
                      fontWeight: '500'
                    }}>
                      <span>🇪🇸</span>
                      <span>Player {match}B</span>
                    </div>
                  </div>
                  
                  {/* Set Score (if live) */}
                  <div style={{
                    textAlign: 'center',
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#6B0C17',
                    marginRight: '15px'
                  }}>
                    {activeTab === 'live' ? (
                      <div>
                        <div>6-4, 3-2</div>
                        <div style={{ fontSize: '12px', color: '#666' }}>Set 2</div>
                      </div>
                    ) : translate('versus')}
                  </div>
                </div>

                {/* Betting Odds - Mobile Layout */}
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '8px',
                  marginTop: '5px'
                }}>
                  {[
                    { label: 'Player A', value: (1.65 + match * 0.1).toFixed(2) },
                    { label: 'Player B', value: (2.20 - match * 0.05).toFixed(2) }
                  ].map((odd, index) => (
                    <button key={`tennis-odd-${match}-${index}`} style={{
                      padding: '10px 8px',
                      backgroundColor: '#f8f9fa',
                      border: '1px solid #e0e0e0',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '12px',
                      fontWeight: 'bold',
                      textAlign: 'center',
                      transition: 'all 0.2s ease'
                    }}>
                      <div style={{ color: '#666', marginBottom: '2px' }}>{odd.label}</div>
                      <div style={{ color: '#22c55e' }}>{odd.value}</div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Featured Match Card - Mobile */}
      <div style={{
        backgroundColor: 'white',
        borderRadius: '12px',
        overflow: 'hidden',
        boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
        marginBottom: '15px'
      }}>
        {/* Header */}
        <div style={{
          backgroundColor: '#374151',
          color: 'white',
          padding: '15px',
          fontWeight: 'bold',
          fontSize: '16px',
          textAlign: 'center'
        }}>
          ⭐ FEATURED MATCH
        </div>
        
        {/* Match Content */}
        <div style={{ padding: '20px' }}>
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '15px',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '14px', color: '#666' }}>
              Champions League Final
            </div>
            
            <div style={{
              display: 'flex',
              justifyContent: 'space-around',
              alignItems: 'center'
            }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', marginBottom: '5px' }}>🔴</div>
                <div style={{ fontWeight: 'bold', fontSize: '14px' }}>Liverpool</div>
              </div>
              
              <div style={{
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#6B0C17'
              }}>
    {translate('versus').toUpperCase()}
              </div>
              
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', marginBottom: '5px' }}>⚪</div>
                <div style={{ fontWeight: 'bold', fontSize: '14px' }}>Real Madrid</div>
              </div>
            </div>
            
            {/* Betting Options */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr 1fr',
              gap: '10px',
              marginTop: '10px'
            }}>
              {[
                { label: 'Liverpool', value: '2.10' },
                { label: 'Draw', value: '3.40' },
                { label: 'Real Madrid', value: '3.20' }
              ].map((odd, index) => (
                <button key={`featured-odd-${index}`} style={{
                  padding: '12px 8px',
                  backgroundColor: '#6B0C17',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  textAlign: 'center'
                }}>
                  <div style={{ marginBottom: '3px' }}>{odd.label}</div>
                  <div style={{ fontSize: '14px' }}>{odd.value}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveMatchesMobile;
