import React from 'react';
import { usePayment } from '../contexts/PaymentContext';
import { useLanguage } from '../contexts/LanguageContext';

interface PaymentButtonProps {
  variant?: 'primary' | 'secondary' | 'small' | 'large' | 'header' | 'homepage' | 'mobile-header' | 'sidebar' | 'sports';
  className?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
  onMouseEnter?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  onMouseLeave?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}

const PaymentButton: React.FC<PaymentButtonProps> = ({ 
  variant = 'primary', 
  className = '', 
  children,
  style,
  onMouseEnter,
  onMouseLeave 
}) => {
  const { paymentLink } = usePayment();
  const { translate } = useLanguage();

  const handlePayment = () => {
    window.open(paymentLink, '_blank', 'noopener,noreferrer');
  };

  const getButtonStyles = (): React.CSSProperties => {
    const baseStyles: React.CSSProperties = {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: '500',
      borderRadius: '6px',
      transition: 'all 0.2s ease-in-out',
      border: 'none',
      cursor: 'pointer',
      textDecoration: 'none',
      outline: 'none'
    };
    
    switch (variant) {
      case 'primary':
        return {
          ...baseStyles,
          backgroundColor: '#2563eb',
          color: 'white',
          padding: '12px 24px',
          fontSize: '16px'
        };
      case 'secondary':
        return {
          ...baseStyles,
          backgroundColor: '#e5e7eb',
          color: '#111827',
          padding: '12px 24px',
          fontSize: '16px'
        };
      case 'small':
        return {
          ...baseStyles,
          backgroundColor: '#2563eb',
          color: 'white',
          padding: '8px 12px',
          fontSize: '14px'
        };
      case 'large':
        return {
          ...baseStyles,
          backgroundColor: '#2563eb',
          color: 'white',
          padding: '16px 32px',
          fontSize: '18px'
        };
      default:
        return {
          ...baseStyles,
          backgroundColor: '#2563eb',
          color: 'white',
          padding: '12px 24px',
          fontSize: '16px'
        };
    }
  };

  const buttonStyles = {
    ...getButtonStyles(),
    ...style
  };

  return (
    <button
      onClick={handlePayment}
      className={className}
      style={buttonStyles}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      type="button"
    >
      {children || (
        <>
          <svg 
            style={{
              width: '20px',
              height: '20px',
              marginRight: '8px'
            }}
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" 
            />
          </svg>
          {translate('pay_with_kaspi') || 'Оплатить через Kaspi'}
        </>
      )}
    </button>
  );
};

export default PaymentButton;