import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { isUserBlacklisted } from '../database';

interface BlacklistCheckerProps {
  children: React.ReactNode;
}

const BlacklistChecker: React.FC<BlacklistCheckerProps> = ({ children }) => {
  const { currentUser, logout } = useAuth();
  const [isChecking, setIsChecking] = useState<boolean>(true);
  const [isBlocked, setIsBlocked] = useState<boolean>(false);

  useEffect(() => {
    const checkBlacklist = async () => {
      if (currentUser?.phone) {
        try {
          console.log('Checking if user is blacklisted:', currentUser.phone);
          const blacklisted = await isUserBlacklisted(
            currentUser.phone,
            currentUser.username
          );
          
          if (blacklisted) {
            console.log('User is blacklisted, logging out');
            setIsBlocked(true);
            // Force logout
            logout();
          } else {
            setIsBlocked(false);
          }
        } catch (error) {
          console.error('Error checking blacklist status:', error);
        } finally {
          setIsChecking(false);
        }
      } else {
        setIsChecking(false);
      }
    };

    // Initial check
    checkBlacklist();
    
    // Set up periodic checks every 60 seconds
    const intervalId = setInterval(() => {
      if (currentUser?.phone) {
        console.log('Performing periodic blacklist check');
        checkBlacklist();
      }
    }, 60000); // Check every minute
    
    // Clean up interval on unmount
    return () => clearInterval(intervalId);
  }, [currentUser, logout]);

  if (isBlocked) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0, 0, 0, 0.9)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 9999,
        color: 'white',
        padding: '20px',
        textAlign: 'center'
      }}>
        <div style={{
          backgroundColor: '#d32f2f',
          borderRadius: '8px',
          padding: '30px',
          maxWidth: '500px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.5)'
        }}>
          <h2 style={{ fontSize: '24px', marginBottom: '20px' }}>⚠️ Account Blocked</h2>
          <p style={{ fontSize: '16px', lineHeight: 1.6, marginBottom: '20px' }}>
            Your account has been blacklisted and you no longer have access to this platform.
          </p>
          <p style={{ fontSize: '16px', lineHeight: 1.6 }}>
            If you believe this is an error, please contact customer support.
          </p>
        </div>
      </div>
    );
  }

  // While checking, we could show a loading indicator, but for better UX,
  // we'll just render the children to avoid unnecessary flashing
  return <>{children}</>;
};

export default BlacklistChecker;