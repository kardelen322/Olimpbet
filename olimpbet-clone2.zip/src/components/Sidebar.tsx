import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

const Sidebar: React.FC = () => {
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['live']);
  const [checkedSports, setCheckedSports] = useState<string[]>([]);
  const { translate, isRTL } = useLanguage();

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const toggleSportCheck = (sportId: string) => {
    setCheckedSports(prev => 
      prev.includes(sportId) 
        ? prev.filter(id => id !== sportId)
        : [...prev, sportId]
    );
  };

  return (
    <div 
      style={{
        width: '195px',
        backgroundColor: '#f8f9fa',
        minHeight: '600px',
        overflow: 'auto',
        border: '1px solid #e5e7eb',
        borderRadius: '8px',
        fontFamily: 'Tahoma, Verdana, Arial, Helvetica, sans-serif',
        fontSize: '13px',
        padding: '0',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
        position: 'static',
        verticalAlign: 'top'
      }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Search Bar */}
      <div style={{ padding: '15px' }}>
        <div style={{ 
          position: 'relative',
          display: 'flex',
          alignItems: 'stretch',
          border: '1px solid #d1d5db',
          borderRadius: '2px',
          boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
          overflow: 'hidden'
        }}>
          <input 
            type="text" 
            name="search"
            id="search_text"
            placeholder="Поиск событий/команд"
            style={{
              flex: '1',
              padding: '1px',
              border: '1px solid #6B0C17',
              borderRight: 'none',
              borderRadius: '0',
              fontSize: '11px',
              outline: 'none',
              backgroundColor: 'white',
              fontFamily: 'Tahoma, Verdana, Arial, Helvetica, sans-serif',
              textAlign: 'center'
            }}
          />
          <a 
            type="button"
            id="search_button"
            href="#popup1"
            style={{
              backgroundColor: '#6B0C17',
              border: '1px solid #6B0C17',
              borderLeft: 'none',
              borderRadius: '0',
              padding: '1px',
              cursor: 'pointer',
              color: 'white',
              fontSize: '11px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              minWidth: '30px',
              textDecoration: 'none',
              fontFamily: 'Tahoma, Verdana, Arial, Helvetica, sans-serif'
            }}
          >
            <div style={{
              width: '16px',
              height: '16px',
              backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'white\'%3E%3Cpath d=\'M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z\'/%3E%3C/svg%3E")',
              backgroundSize: 'contain',
              backgroundRepeat: 'no-repeat',
              backgroundPosition: 'center'
            }}></div>
          </a>
        </div>
      </div>

      {/* BET NOW Header */}
      <div style={{ 
        backgroundColor: '#4a5568',
        padding: '8px 15px',
        textAlign: 'center',
        borderTop: '1px solid #e5e7eb'
      }}>
        <span style={{ 
          color: 'white', 
          fontWeight: 'bold',
          fontSize: '13px',
          textTransform: 'uppercase'
        }}>
          BET NOW
        </span>
      </div>

      {/* Content Section */}
      <div style={{ 
        backgroundColor: '#f9fafb',
        padding: '10px 15px'
      }}>
        <div style={{ marginBottom: '8px' }}>
          <a href="/live" style={{ 
            color: 'black', 
            textDecoration: 'none',
            fontWeight: 'bold',
            fontSize: '13px',
            display: 'flex',
            alignItems: 'center',
            gap: '5px'
          }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: '#ef4444',
              animation: 'pulse 2s infinite'
            }}></div>
            <b>Ставки Лайв</b> <span style={{ color: '#6B0C17', fontWeight: 'bold' }}>(155)</span>
          </a>
        </div>
        
        <div style={{ 
          marginBottom: '8px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <div style={{
            width: '16px',
            height: '16px',
            backgroundColor: '#6B0C17',
            borderRadius: '2px',
            position: 'relative'
          }}>
            <div style={{
              position: 'absolute',
              bottom: '1px',
              right: '1px',
              width: '8px',
              height: '8px',
              backgroundColor: 'white',
              borderRadius: '1px'
            }}></div>
          </div>
          <a href="/live" style={{ 
            color: '#6B0C17', 
            textDecoration: 'none',
            fontSize: '13px'
          }}>
            Расписание Лайв
          </a>
        </div>
        
        <div style={{ marginBottom: '8px' }}>
          <a href="/bets247" style={{ 
            color: 'black', 
            textDecoration: 'none',
            fontWeight: 'bold',
            fontSize: '13px'
          }}>
            <b>Ставки 24/7</b>
          </a>
        </div>
        
        <div style={{ marginBottom: '8px' }}>
          <a href="/bonuses" style={{ 
            color: 'black', 
            textDecoration: 'none',
            fontWeight: 'bold',
            fontSize: '13px'
          }}>
            <b>Специальные предложения</b>
          </a>
        </div>
        
        <div style={{ marginBottom: '8px' }}>
          <a href="/esports" style={{ 
            color: 'black', 
            textDecoration: 'none',
            fontWeight: 'bold',
            fontSize: '13px'
          }}>
            <b>Киберспорт</b>
          </a>
        </div>
        
        <div style={{ 
          borderBottom: '1px solid #6B0C17',
          margin: '10px 0'
        }}></div>
      </div>

      {/* Sports List */}
      <div style={{ backgroundColor: '#fff', borderTop: '1px solid #e5e7eb' }}>
        {[
          { id: '1', name: 'Футбол', count: 1160, href: '/sports', icon: '⚽', popular: true },
          { id: '3', name: 'Теннис', count: 321, href: '/sports', icon: '🎾', popular: true },
          { id: '2', name: 'Хоккей', count: 46, href: '/sports', icon: '🏒', popular: true },
          { id: '5', name: 'Баскетбол', count: 43, href: '/sports', icon: '🏀', popular: true },
          { id: '112', name: 'Киберспорт', count: 263, href: '/esports', icon: '🎮', popular: true },
          { id: '40', name: 'Настольный теннис', count: 266, href: '/sports', icon: '🏓', popular: false },
          { id: '143', name: 'Кулачные бои', count: 26, href: '/sports', icon: '🥊', popular: false },
          { id: '12', name: 'Бокс', count: 24, href: '/sports', icon: '🥊', popular: false },
          { id: '96', name: 'Смешанные единоборства', count: 77, href: '/sports', icon: '🥋', popular: false },
          { id: '10', name: 'Волейбол', count: 20, href: '/sports', icon: '🏐', popular: false },
          { id: '92', name: 'Дартс', count: 34, href: '/sports', icon: '🎯', popular: false },
          { id: '97', name: 'Гольф', count: 110, href: '/sports', icon: '⛳', popular: false },
          { id: '11', name: 'Американский футбол', count: 16, href: '/sports', icon: '🏈', popular: false },
          { id: '85', name: 'Бейсбол', count: 10, href: '/sports', icon: '⚾', popular: false },
          { id: '89', name: 'Крикет', count: 27, href: '/sports', icon: '🏏', popular: false },
          { id: '91', name: 'Велоспорт', count: 22, href: '/sports', icon: '🚴', popular: false },
          { id: '94', name: 'Формула 1', count: 29, href: '/sports', icon: '🏎️', popular: false },
          { id: '104', name: 'Регби', count: 37, href: '/sports', icon: '🏉', popular: false }
        ].map((sport, index) => (
          <div 
            key={`popular-${sport.id}-${index}`} 
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '8px 15px',
              borderBottom: index < 17 ? '1px solid #f3f4f6' : 'none',
              backgroundColor: sport.popular ? '#f8fafe' : 'white',
              borderLeft: sport.popular ? '3px solid #6B0C17' : 'none',
              transition: 'background-color 0.2s ease',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = sport.popular ? '#f0f7ff' : '#f9fafb';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = sport.popular ? '#f8fafe' : 'white';
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: '1' }}>
              <input
                type="checkbox"
                id={`c${index}`}
                name="sel[]"
                value={sport.id}
                checked={checkedSports.includes(sport.id)}
                onChange={() => toggleSportCheck(sport.id)}
                style={{
                  width: '14px',
                  height: '14px',
                  cursor: 'pointer'
                }}
              />
              <span style={{ fontSize: '14px', marginRight: '5px' }}>
                {sport.icon}
              </span>
              <a href={sport.href} style={{ 
                color: sport.popular ? '#6B0C17' : '#000', 
                textDecoration: 'none',
                fontSize: '13px',
                fontWeight: sport.popular ? 'bold' : 'normal',
                flex: 1,
                transition: 'color 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = '#6B0C17';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = sport.popular ? '#6B0C17' : '#000';
              }}>
                {sport.name} ({sport.count})
              </a>
            </div>
          </div>
        ))}

        <div style={{ 
          borderBottom: '1px solid #e5e7eb',
          margin: '0 15px'
        }}></div>

        {[
          { id: '75', name: 'Alpine Skiing', count: 1, href: '/betting/mountain-skiing' },
          { id: '6', name: 'American Football', count: 16, href: '/betting/american-football' },
          { id: '91', name: 'Australian Rules', count: 9, href: '/betting/australian-football' },
          { id: '117', name: 'Auto/motosport', count: 16, href: '/index.php?page=line&action=1&sel[]=117' },
          { id: '51', name: 'Badminton', count: 11, href: '/betting/badminton' },
          { id: '29', name: 'Baseball', count: 10, href: '/betting/baseball' },
          { id: '35', name: 'Beach Soccer', count: 5, href: '/index.php?page=line&action=1&sel[]=35' },
          { id: '7', name: 'Biathlon', count: 5, href: '/betting/biathlon' },
          { id: '4', name: 'Billiard', count: 7, href: '/betting/snooker' },
          { id: '73', name: 'Cricket', count: 27, href: '/betting/cricket' },
          { id: '38', name: 'Cross Country skiing', count: 4, href: '/betting/skiing' },
          { id: '44', name: 'Cycling', count: 22, href: '/betting/cycle-racing' },
          { id: '47', name: 'Darts', count: 34, href: '/betting/darts' },
          { id: '67', name: 'Field Hockey', count: 2, href: '/index.php?page=line&action=1&sel[]=67' },
          { id: '33', name: 'Formula 1', count: 29, href: '/betting/formula1' },
          { id: '11', name: 'Futsal', count: 4, href: '/betting/futsal' },
          { id: '90', name: 'Golf', count: 110, href: '/betting/golf' },
          { id: '49', name: 'Handball', count: 5, href: '/betting/handball' },
          { id: '49', name: 'Horse Racing', count: 7, href: '/index.php?page=line&action=1&sel[]=49' },
          { id: '72', name: 'Lacrosse', count: 29, href: '/index.php?page=line&action=1&sel[]=72' },
          { id: '13', name: 'Olympics', count: 5, href: '/index.php?page=line&action=1&sel[]=13' },
          { id: '115', name: 'Pesapallo', count: 5, href: '/index.php?page=line&action=1&sel[]=115' },
          { id: '149', name: 'Pickleball', count: 27, href: '/index.php?page=line&action=1&sel[]=149' },
          { id: '85', name: 'Rugby League', count: 26, href: '/betting/rugby-league' },
          { id: '46', name: 'Rugby Union', count: 11, href: '/betting/rugby-union' },
          { id: '39', name: 'Ski Jumping', count: 1, href: '/betting/ski-jumping' },
          { id: '41', name: 'Water Polo', count: 5, href: '/betting/water-polo' }
        ].map((sport, index) => (
          <div 
            key={`other-${sport.id}-${index}`} 
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '8px 15px',
              borderBottom: index < 25 ? '1px solid #f3f4f6' : 'none',
              backgroundColor: 'white'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: '1' }}>
              <input
                type="checkbox"
                id={`c${index + 10}`}
                name="sel[]"
                value={sport.id}
                checked={checkedSports.includes(sport.id)}
                onChange={() => toggleSportCheck(sport.id)}
                style={{
                  width: '14px',
                  height: '14px',
                  cursor: 'pointer'
                }}
              />
              <a href={sport.href} style={{ 
                color: '#000', 
                textDecoration: 'none',
                fontSize: '13px',
                fontWeight: 'bold'
              }}>
                {sport.name} ({sport.count})
              </a>
            </div>
          </div>
        ))}

        {/* Outrights */}
        <div style={{ marginBottom: '10px', textAlign: 'center' }}>
          <a href="/sports" style={{ 
            color: '#374151', 
            textDecoration: 'none',
            fontSize: '13px',
            fontWeight: 'bold'
          }}>
            <b>Фьючерсы</b>
          </a>
        </div>

        {/* Select All */}
        <div style={{ marginBottom: '10px', textAlign: 'center' }}>
          <a href="javascript:selall();" style={{ 
            color: '#6B0C17', 
            textDecoration: 'none',
            fontSize: '13px',
            fontWeight: '500'
          }}>
            Выбрать все виды спорта (2531)
          </a>
        </div>

        {/* Show Button */}
        <button style={{
          backgroundColor: '#6b0c17',
          color: 'white',
          border: 'none',
          padding: '12px 20px',
          borderRadius: '6px',
          fontSize: '14px',
          cursor: 'pointer',
          fontWeight: 'bold',
          width: '90%',
          margin: '0 auto',
          display: 'block',
          textTransform: 'uppercase'
        }}>
          ПОКАЗАТЬ
        </button>
        
        {/* Add CSS for pulse animation */}
        <style>{`
          @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
          }
        `}</style>
      </div>
    </div>
  );
};

export default Sidebar;