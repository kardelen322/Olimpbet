import React, { useState } from 'react';
import Login from './Login';
import Register from './Register';

type AuthModalType = 'login' | 'register';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialView?: AuthModalType;
}

const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen, 
  onClose, 
  initialView = 'login' 
}) => {
  const [currentView, setCurrentView] = useState<AuthModalType>(initialView);

  if (!isOpen) return null;

  const handleSwitchToLogin = () => setCurrentView('login');
  const handleSwitchToRegister = () => setCurrentView('register');

  return (
    <div style={styles.overlay} onClick={onClose}>
      <div style={styles.modalContainer} onClick={(e) => e.stopPropagation()}>
        {currentView === 'login' ? (
          <Login 
            onClose={onClose} 
            onRegisterClick={handleSwitchToRegister} 
          />
        ) : (
          <Register 
            onClose={onClose} 
            onLoginClick={handleSwitchToLogin} 
          />
        )}
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    position: 'fixed' as const,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContainer: {
    position: 'relative' as const,
    maxHeight: '90vh',
    overflowY: 'auto' as const,
    borderRadius: '8px',
    animation: 'fadeIn 0.3s',
  },
};

export default AuthModal;