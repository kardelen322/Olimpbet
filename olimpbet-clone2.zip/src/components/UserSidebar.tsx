import React, { useRef, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useNotifications } from '../contexts/NotificationContext';
import { useBalance } from '../contexts/BalanceContext';

interface UserSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const UserSidebar: React.FC<UserSidebarProps> = ({ isOpen, onClose }) => {
  const { translate } = useLanguage();
  const { currentUser, logout } = useAuth();
  const { unreadCount } = useNotifications();
  const { balance, formatBalance } = useBalance();
  const navigate = useNavigate();
  const sidebarRef = useRef<HTMLDivElement>(null);
  
  // State for collapsible sections
  const [expandedSections, setExpandedSections] = useState<string[]>(['options', 'myBets', 'fundsManagement']);
  
  // Toggle section expansion
  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => 
      prev.includes(sectionId) 
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  // Close sidebar when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  // Handle navigation
  const handleNavigation = (path: string) => {
    navigate(path);
    onClose();
  };

  // Handle logout
  const handleLogout = () => {
    logout();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      ref={sidebarRef}
      style={{
        position: 'fixed',
        top: 0,
        right: 0,
        width: '250px',
        height: '100vh',
        backgroundColor: '#333',
        color: 'white',
        zIndex: 1000,
        boxShadow: '-2px 0 5px rgba(0, 0, 0, 0.3)',
        transition: 'transform 0.3s ease',
        transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Header */}
      <div style={{
        backgroundColor: '#6b0c17',
        padding: '15px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '36px',
            height: '36px',
            backgroundColor: 'white',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden'
          }}>
            <img
              src="/app-banner-logo.png"
              alt={translate('user')}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'contain'
              }}
            />
          </div>
          <div>
            <div style={{ fontWeight: 'bold' }}>{currentUser?.username || currentUser?.phone}</div>
            <div style={{ fontSize: '12px' }}>{translate('id')}: {currentUser?.phone}</div>
            <div style={{ fontSize: '14px', marginTop: '5px', color: '#4caf50' }}>
              {translate('accountBalance')}: {formatBalance(balance)}
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          style={{
            background: 'none',
            border: 'none',
            color: 'white',
            fontSize: '20px',
            cursor: 'pointer'
          }}
        >
          ×
        </button>
      </div>

      {/* Menu Items */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '10px 0', borderBottom: '1px solid #444' }}>
          <MenuHeader 
            sectionId="options" 
            isExpanded={expandedSections.includes('options')} 
            onToggle={toggleSection}
          >
            {translate('options')}
          </MenuHeader>
          
          {expandedSections.includes('options') && (
            <div style={{ 
              maxHeight: expandedSections.includes('options') ? '500px' : '0',
              overflow: 'hidden',
              transition: 'max-height 0.3s ease-in-out'
            }}>
              <MenuItem onClick={() => handleNavigation('/notifications')} icon="🔔" badge={unreadCount > 0 ? unreadCount : undefined}>
                {translate('notifications')}
              </MenuItem>
              <MenuItem onClick={() => handleNavigation('/settings')} icon="⚙️">
                {translate('userSettings')}
              </MenuItem>
              <MenuItem onClick={() => handleNavigation('/quick-bet')} icon="⚡">
                {translate('quickBet')}
              </MenuItem>
            </div>
          )}
        </div>

        <div style={{ padding: '10px 0', borderBottom: '1px solid #444' }}>
          <MenuHeader 
            sectionId="myBets" 
            isExpanded={expandedSections.includes('myBets')} 
            onToggle={toggleSection}
          >
            {translate('myBets')}
          </MenuHeader>
          
          {expandedSections.includes('myBets') && (
            <div style={{ 
              maxHeight: expandedSections.includes('myBets') ? '500px' : '0',
              overflow: 'hidden',
              transition: 'max-height 0.3s ease-in-out'
            }}>
              <MenuItem onClick={() => handleNavigation('/my-bets')} icon="📝">
                {translate('userBets')}
              </MenuItem>
              <MenuItem onClick={() => handleNavigation('/cash-out')} icon="💰">
                {translate('betsForCashOut')}
              </MenuItem>
            </div>
          )}
        </div>

        <div style={{ padding: '10px 0', borderBottom: '1px solid #444' }}>
          <MenuHeader 
            sectionId="fundsManagement" 
            isExpanded={expandedSections.includes('fundsManagement')} 
            onToggle={toggleSection}
          >
            {translate('fundsManagement')}
          </MenuHeader>
          
          {expandedSections.includes('fundsManagement') && (
            <div style={{ 
              maxHeight: expandedSections.includes('fundsManagement') ? '500px' : '0',
              overflow: 'hidden',
              transition: 'max-height 0.3s ease-in-out'
            }}>
              <MenuItem onClick={() => handleNavigation('/deposit')} icon="💳">
                {translate('deposit')}
              </MenuItem>
              <MenuItem onClick={() => handleNavigation('/withdrawal')} icon="💸">
                {translate('withdrawal')}
              </MenuItem>
              <MenuItem onClick={() => handleNavigation('/payment-history')} icon="📊">
                {translate('paymentHistory')}
              </MenuItem>
            </div>
          )}
        </div>

        <div style={{ padding: '10px 0', borderBottom: '1px solid #444' }}>
          <MenuItem onClick={() => handleNavigation('/terms')} icon="📄">
            {translate('userTermsConditions')}
          </MenuItem>
          <MenuItem onClick={() => handleNavigation('/faq')} icon="❓">
            {translate('faq')}
          </MenuItem>
        </div>
      </div>

      {/* Logout Button */}
      <div style={{ padding: '15px', borderTop: '1px solid #444' }}>
        <button
          onClick={handleLogout}
          style={{
            width: '100%',
            padding: '10px',
            backgroundColor: '#6b0c17',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontWeight: 'bold',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px'
          }}
        >
          <span>🚪</span>
          {translate('exit')}
        </button>
      </div>
    </div>
  );
};

// Helper components
interface MenuHeaderProps {
  children: React.ReactNode;
  sectionId: string;
  isExpanded: boolean;
  onToggle: (sectionId: string) => void;
}

const MenuHeader: React.FC<MenuHeaderProps> = ({ children, sectionId, isExpanded, onToggle }) => (
  <div 
    onClick={() => onToggle(sectionId)}
    style={{
      padding: '5px 15px',
      fontSize: '12px',
      color: '#aaa',
      textTransform: 'uppercase',
      fontWeight: 'bold',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      cursor: 'pointer'
    }}
  >
    <span>{children}</span>
    <span style={{
      fontSize: '12px',
      transition: 'transform 0.3s',
      transform: isExpanded ? 'rotate(0deg)' : 'rotate(-90deg)'
    }}>
      ▼
    </span>
  </div>
);

interface MenuItemProps {
  icon: string;
  children: React.ReactNode;
  onClick: () => void;
  badge?: number;
}

const MenuItem: React.FC<MenuItemProps> = ({ icon, children, onClick, badge }) => {
  
  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        padding: '10px 15px',
        width: '100%',
        backgroundColor: 'transparent',
        border: 'none',
        color: 'white',
        textAlign: 'left',
        cursor: 'pointer',
        transition: 'background-color 0.2s',
        fontSize: '14px',
        position: 'relative'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = '#444';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = 'transparent';
      }}
    >
      <span style={{ width: '20px', textAlign: 'center' }}>{icon}</span>
      {children}
      {badge !== undefined && badge > 0 && (
        <span style={{
          position: 'absolute',
          right: '15px',
          backgroundColor: '#e74c3c',
          color: 'white',
          borderRadius: '10px',
          padding: '2px 6px',
          fontSize: '10px',
          fontWeight: 'bold',
          minWidth: '20px',
          textAlign: 'center'
        }}>
          {badge > 99 ? '99+' : badge}
        </span>
      )}
    </button>
  );
};

export default UserSidebar;