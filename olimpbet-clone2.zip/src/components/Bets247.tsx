import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const Bets247: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState('virtual');
  const [selectedGame, setSelectedGame] = useState('football');

  const categories = [
    {
      id: 'virtual',
      name: 'Виртуальные виды спорта',
      icon: '🎮',
      description: 'Ставки на виртуальные матчи 24/7',
      color: '#06b6d4'
    },
    {
      id: 'numbers',
      name: 'Числовые игры',
      icon: '🎯',
      description: 'Лотереи и розыгрыши каждые 5 минут',
      color: '#8b5cf6'
    },
    {
      id: 'instant',
      name: 'Мгновенные игры',
      icon: '⚡',
      description: 'Быстрые ставки с моментальными результатами',
      color: '#f59e0b'
    },
    {
      id: 'specials',
      name: 'Специальные ставки',
      icon: '🌟',
      description: 'Политика, погода, события',
      color: '#ef4444'
    }
  ];

  const virtualSports = [
    {
      id: 'football',
      name: 'Виртуальный футбол',
      icon: '⚽',
      interval: '2 минуты',
      nextMatch: '1:34',
      teams: ['Барселона Виртуал', 'Реал Виртуал'],
      odds: { home: '2.15', draw: '3.20', away: '2.95' },
      viewers: 8420
    },
    {
      id: 'horse',
      name: 'Скачки',
      icon: '🐎',
      interval: '3 минуты',
      nextMatch: '2:45',
      participants: ['Thunder Bolt', 'Speed Star', 'Lightning'],
      odds: { first: '3.50', second: '4.20', third: '2.80' },
      viewers: 5670
    },
    {
      id: 'tennis',
      name: 'Виртуальный теннис',
      icon: '🎾',
      interval: '4 минуты',
      nextMatch: '0:58',
      players: ['Роджер Вирт', 'Рафа Виртуал'],
      odds: { player1: '1.85', player2: '1.95' },
      viewers: 3420
    },
    {
      id: 'racing',
      name: 'Автогонки',
      icon: '🏎️',
      interval: '5 минут',
      nextMatch: '3:12',
      drivers: ['Speed Racer', 'Turbo Max', 'Fast Lane'],
      odds: { first: '2.90', second: '3.40', third: '4.10' },
      viewers: 6230
    }
  ];

  const numberGames = [
    {
      id: 'keno',
      name: 'Кено',
      icon: '🎱',
      description: 'Выберите от 1 до 20 чисел из 80',
      nextDraw: '4:23',
      jackpot: '127,500 ₽',
      lastNumbers: [12, 23, 34, 45, 56, 67, 78, 89]
    },
    {
      id: 'lucky6',
      name: 'Счастливая шестерка',
      icon: '🍀',
      description: 'Угадайте 6 чисел из 48',
      nextDraw: '2:17',
      jackpot: '89,300 ₽',
      lastNumbers: [7, 14, 21, 28, 35, 42]
    },
    {
      id: 'wheel',
      name: 'Колесо фортуны',
      icon: '🎡',
      description: 'Делайте ставки на цвета и числа',
      nextSpin: '1:05',
      multipliers: ['x2', 'x5', 'x10', 'x25'],
      lastResult: 'Красное 7'
    }
  ];

  const instantGames = [
    {
      id: 'dice',
      name: 'Виртуальные кости',
      icon: '🎲',
      description: 'Предскажите сумму двух костей',
      minBet: '10 ₽',
      maxBet: '10,000 ₽',
      payout: 'до x36'
    },
    {
      id: 'coins',
      name: 'Орел или решка',
      icon: '🪙',
      description: 'Самая простая ставка 50/50',
      minBet: '5 ₽',
      maxBet: '25,000 ₽',
      payout: 'x1.95'
    },
    {
      id: 'cards',
      name: 'Угадай карту',
      icon: '🃏',
      description: 'Выберите масть или достоинство',
      minBet: '20 ₽',
      maxBet: '5,000 ₽',
      payout: 'до x13'
    }
  ];

  const specialBets = [
    {
      id: 'politics',
      name: 'Политические события',
      icon: '🏛️',
      events: [
        { event: 'Выборы президента США 2024', odds: '1.75 / 2.10' },
        { event: 'Следующий глава ЦБ РФ', odds: '2.50 / 1.65' }
      ]
    },
    {
      id: 'weather',
      name: 'Погодные ставки',
      icon: '🌤️',
      events: [
        { event: 'Снег в Москве 31 декабря', odds: '1.45 / 2.75' },
        { event: 'Температура в НГ выше 0°C', odds: '3.20 / 1.35' }
      ]
    },
    {
      id: 'entertainment',
      name: 'Развлечения',
      icon: '🎭',
      events: [
        { event: 'Победитель Евровидения 2024', odds: '4.50 / 3.20 / 2.10' },
        { event: 'Лучший фильм Оскар 2024', odds: '2.30 / 3.80 / 4.60' }
      ]
    }
  ];

  const getNextEventTime = () => {
    const now = new Date();
    const nextEvent = new Date(now.getTime() + 2 * 60 * 1000); // +2 minutes
    return nextEvent.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div style={{
      display: 'flex',
      margin: '0 auto',
      padding: '20px 20px 20px 10px',
      gap: '20px'
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />

      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          background: 'linear-gradient(135deg, #6b0c17 0%, #8b1a1a 100%)',
          color: 'white'
        }}>
          <h1 style={{
            fontSize: '36px',
            fontWeight: 'bold',
            margin: '0 0 10px 0'
          }}>
            🎰 СТАВКИ 24/7
          </h1>
          <p style={{
            fontSize: '18px',
            margin: '0 0 15px 0',
            opacity: 0.9
          }}>
            Круглосуточные развлечения и возможности для ставок
          </p>
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '30px',
            fontSize: '14px',
            fontWeight: 'bold'
          }}>
            <div>⏰ Работаем 24/7</div>
            <div>🎮 Виртуальный спорт</div>
            <div>⚡ Мгновенные результаты</div>
            <div>🎯 Розыгрыши каждые 2 мин</div>
          </div>
        </div>

        {/* Category Tabs */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '15px'
          }}>
            {categories.map(category => (
              <div
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                style={{
                  padding: '20px',
                  borderRadius: '12px',
                  border: selectedCategory === category.id ? `3px solid ${category.color}` : '2px solid #e5e7eb',
                  backgroundColor: selectedCategory === category.id ? `${category.color}15` : 'white',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  textAlign: 'center',
                  boxShadow: selectedCategory === category.id ? `0 8px 25px ${category.color}40` : '0 2px 8px rgba(0,0,0,0.1)'
                }}
              >
                <div style={{
                  fontSize: '36px',
                  marginBottom: '10px'
                }}>
                  {category.icon}
                </div>
                <h3 style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: selectedCategory === category.id ? category.color : '#333',
                  margin: '0 0 8px 0'
                }}>
                  {category.name}
                </h3>
                <p style={{
                  fontSize: '12px',
                  color: '#666',
                  margin: '0'
                }}>
                  {category.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Content Based on Selected Category */}
        {selectedCategory === 'virtual' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '25px',
            marginBottom: '20px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#06b6d4',
              margin: '0 0 20px 0',
              textAlign: 'center'
            }}>
              🎮 Виртуальные виды спорта
            </h2>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
              gap: '20px'
            }}>
              {virtualSports.map(sport => (
                <div
                  key={sport.id}
                  style={{
                    padding: '20px',
                    borderRadius: '12px',
                    border: '2px solid #e5e7eb',
                    backgroundColor: '#fafbfc',
                    transition: 'all 0.3s ease'
                  }}
                >
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    marginBottom: '15px'
                  }}>
                    <div style={{
                      fontSize: '32px',
                      width: '50px',
                      height: '50px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: '#06b6d4',
                      borderRadius: '10px',
                      color: 'white'
                    }}>
                      {sport.icon}
                    </div>
                    <div>
                      <h3 style={{
                        fontSize: '16px',
                        fontWeight: 'bold',
                        color: '#333',
                        margin: '0 0 5px 0'
                      }}>
                        {sport.name}
                      </h3>
                      <p style={{
                        fontSize: '12px',
                        color: '#666',
                        margin: '0'
                      }}>
                        Каждые {sport.interval} • 👥 {sport.viewers}
                      </p>
                    </div>
                  </div>

                  <div style={{
                    backgroundColor: '#06b6d4',
                    color: 'white',
                    padding: '10px',
                    borderRadius: '8px',
                    textAlign: 'center',
                    marginBottom: '15px',
                    fontWeight: 'bold'
                  }}>
                    Следующий матч через: {sport.nextMatch}
                  </div>

                  <div style={{
                    marginBottom: '15px'
                  }}>
                    <div style={{
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: '#333',
                      marginBottom: '8px'
                    }}>
                      {sport.teams ? sport.teams.join(' vs ') : 
                       sport.players ? sport.players.join(' vs ') :
                       sport.participants ? sport.participants.slice(0, 2).join(' vs ') + '...' :
                       sport.drivers ? sport.drivers.slice(0, 2).join(' vs ') + '...' : ''}
                    </div>
                  </div>

                  <div style={{
                    display: 'flex',
                    gap: '8px',
                    justifyContent: 'center'
                  }}>
                    {Object.entries(sport.odds).map(([key, value]) => (
                      <button
                        key={key}
                        style={{
                          padding: '8px 12px',
                          borderRadius: '6px',
                          border: 'none',
                          backgroundColor: key === 'home' || key === 'player1' || key === 'first' ? '#22c55e' :
                                           key === 'draw' ? '#f59e0b' : '#ef4444',
                          color: 'white',
                          cursor: 'pointer',
                          fontSize: '12px',
                          fontWeight: 'bold',
                          flex: 1
                        }}
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {selectedCategory === 'numbers' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '25px',
            marginBottom: '20px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#8b5cf6',
              margin: '0 0 20px 0',
              textAlign: 'center'
            }}>
              🎯 Числовые игры
            </h2>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
              gap: '20px'
            }}>
              {numberGames.map(game => (
                <div
                  key={game.id}
                  style={{
                    padding: '25px',
                    borderRadius: '12px',
                    border: '2px solid #8b5cf6',
                    backgroundColor: '#8b5cf615',
                    position: 'relative'
                  }}
                >
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '15px',
                    marginBottom: '15px'
                  }}>
                    <div style={{
                      fontSize: '40px'
                    }}>
                      {game.icon}
                    </div>
                    <div>
                      <h3 style={{
                        fontSize: '18px',
                        fontWeight: 'bold',
                        color: '#8b5cf6',
                        margin: '0 0 5px 0'
                      }}>
                        {game.name}
                      </h3>
                      <p style={{
                        fontSize: '13px',
                        color: '#666',
                        margin: '0'
                      }}>
                        {game.description}
                      </p>
                    </div>
                  </div>

                  <div style={{
                    backgroundColor: '#8b5cf6',
                    color: 'white',
                    padding: '15px',
                    borderRadius: '10px',
                    marginBottom: '15px'
                  }}>
                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginBottom: '10px'
                    }}>
                      <span style={{ fontWeight: 'bold' }}>
                        {game.nextDraw ? `Следующий розыгрыш: ${game.nextDraw}` : `Следующий спин: ${game.nextSpin}`}
                      </span>
                    </div>
                    <div style={{
                      fontSize: '20px',
                      fontWeight: 'bold',
                      textAlign: 'center'
                    }}>
                      {game.jackpot ? `💰 ${game.jackpot}` : `🎡 ${game.lastResult}`}
                    </div>
                  </div>

                  <div style={{ marginBottom: '15px' }}>
                    <div style={{
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: '#333',
                      marginBottom: '10px'
                    }}>
                      {game.lastNumbers ? 'Последние числа:' : 
                       game.multipliers ? 'Доступные множители:' : ''}
                    </div>
                    <div style={{
                      display: 'flex',
                      flexWrap: 'wrap',
                      gap: '8px'
                    }}>
                      {(game.lastNumbers || game.multipliers || []).map((item, index) => (
                        <span
                          key={`${game.id}-item-${index}`}
                          style={{
                            padding: '5px 10px',
                            backgroundColor: '#f3f4f6',
                            borderRadius: '15px',
                            fontSize: '12px',
                            fontWeight: 'bold',
                            color: '#333'
                          }}
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>

                  <button style={{
                    width: '100%',
                    padding: '12px',
                    borderRadius: '8px',
                    border: 'none',
                    backgroundColor: '#8b5cf6',
                    color: 'white',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}>
                    Играть сейчас
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {selectedCategory === 'instant' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '25px',
            marginBottom: '20px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#f59e0b',
              margin: '0 0 20px 0',
              textAlign: 'center'
            }}>
              ⚡ Мгновенные игры
            </h2>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '20px'
            }}>
              {instantGames.map(game => (
                <div
                  key={game.id}
                  style={{
                    padding: '25px',
                    borderRadius: '12px',
                    border: '2px solid #f59e0b',
                    backgroundColor: '#f59e0b15',
                    textAlign: 'center'
                  }}
                >
                  <div style={{
                    fontSize: '60px',
                    marginBottom: '15px'
                  }}>
                    {game.icon}
                  </div>
                  
                  <h3 style={{
                    fontSize: '18px',
                    fontWeight: 'bold',
                    color: '#f59e0b',
                    margin: '0 0 10px 0'
                  }}>
                    {game.name}
                  </h3>
                  
                  <p style={{
                    fontSize: '14px',
                    color: '#666',
                    margin: '0 0 20px 0'
                  }}>
                    {game.description}
                  </p>

                  <div style={{
                    backgroundColor: '#f59e0b',
                    color: 'white',
                    padding: '15px',
                    borderRadius: '10px',
                    marginBottom: '20px'
                  }}>
                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      marginBottom: '8px',
                      fontSize: '13px'
                    }}>
                      <span>Мин. ставка:</span>
                      <span style={{ fontWeight: 'bold' }}>{game.minBet}</span>
                    </div>
                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      marginBottom: '8px',
                      fontSize: '13px'
                    }}>
                      <span>Макс. ставка:</span>
                      <span style={{ fontWeight: 'bold' }}>{game.maxBet}</span>
                    </div>
                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      fontSize: '13px'
                    }}>
                      <span>Выплата:</span>
                      <span style={{ fontWeight: 'bold' }}>{game.payout}</span>
                    </div>
                  </div>

                  <button style={{
                    width: '100%',
                    padding: '12px',
                    borderRadius: '8px',
                    border: 'none',
                    backgroundColor: '#f59e0b',
                    color: 'white',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}>
                    Играть ⚡
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {selectedCategory === 'specials' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '25px',
            marginBottom: '20px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#ef4444',
              margin: '0 0 20px 0',
              textAlign: 'center'
            }}>
              🌟 Специальные ставки
            </h2>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
              gap: '20px'
            }}>
              {specialBets.map(category => (
                <div
                  key={category.id}
                  style={{
                    padding: '25px',
                    borderRadius: '12px',
                    border: '2px solid #ef4444',
                    backgroundColor: '#ef444415'
                  }}
                >
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '15px',
                    marginBottom: '20px'
                  }}>
                    <div style={{
                      fontSize: '40px'
                    }}>
                      {category.icon}
                    </div>
                    <h3 style={{
                      fontSize: '18px',
                      fontWeight: 'bold',
                      color: '#ef4444',
                      margin: '0'
                    }}>
                      {category.name}
                    </h3>
                  </div>

                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '15px'
                  }}>
                    {category.events.map((event, index) => (
                      <div
                        key={`${category.id}-event-${index}`}
                        style={{
                          padding: '15px',
                          backgroundColor: 'white',
                          borderRadius: '10px',
                          border: '1px solid #f3f4f6'
                        }}
                      >
                        <div style={{
                          fontSize: '14px',
                          fontWeight: 'bold',
                          color: '#333',
                          marginBottom: '8px'
                        }}>
                          {event.event}
                        </div>
                        <div style={{
                          display: 'flex',
                          gap: '8px'
                        }}>
                          {event.odds.split(' / ').map((odd, oddIndex) => (
                            <button
                              key={oddIndex}
                              style={{
                                padding: '8px 12px',
                                borderRadius: '6px',
                                border: 'none',
                                backgroundColor: oddIndex === 0 ? '#22c55e' : 
                                                oddIndex === 1 ? '#f59e0b' : '#ef4444',
                                color: 'white',
                                cursor: 'pointer',
                                fontSize: '12px',
                                fontWeight: 'bold',
                                flex: 1
                              }}
                            >
                              {odd}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bottom Info */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <h3 style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 15px 0'
          }}>
            ⏰ Почему выбирают СТАВКИ 24/7?
          </h3>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '20px',
            marginTop: '20px'
          }}>
            <div>
              <div style={{ fontSize: '30px', marginBottom: '10px' }}>🔄</div>
              <strong>Круглосуточно</strong>
              <p style={{ fontSize: '12px', color: '#666', margin: '5px 0 0 0' }}>
                Ставки доступны 24 часа в сутки, 7 дней в неделю
              </p>
            </div>
            <div>
              <div style={{ fontSize: '30px', marginBottom: '10px' }}>⚡</div>
              <strong>Мгновенно</strong>
              <p style={{ fontSize: '12px', color: '#666', margin: '5px 0 0 0' }}>
                Результаты и выплаты в режиме реального времени
              </p>
            </div>
            <div>
              <div style={{ fontSize: '30px', marginBottom: '10px' }}>🎯</div>
              <strong>Разнообразие</strong>
              <p style={{ fontSize: '12px', color: '#666', margin: '5px 0 0 0' }}>
                Более 50 различных игр и типов ставок
              </p>
            </div>
            <div>
              <div style={{ fontSize: '30px', marginBottom: '10px' }}>🛡️</div>
              <strong>Надежно</strong>
              <p style={{ fontSize: '12px', color: '#666', margin: '5px 0 0 0' }}>
                Честные алгоритмы и лицензированные игры
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Bets247;