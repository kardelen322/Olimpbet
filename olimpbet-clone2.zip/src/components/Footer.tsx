import React, { useState, CSSProperties } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

// Type definitions for partners and social media
interface Partner {
  icon: string;
  title: string;
  subtitle: string;
}

interface SocialMediaPlatform {
  name: 'telegram' | 'vk' | 'instagram' | 'tiktok' | 'youtube';
  icon: React.ReactNode;
}

const Footer: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [currentSlide, setCurrentSlide] = useState(0);
  const totalSlides = 2; // We have 2 slides with 6 partners each

  // Navigation methods
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  // Partners data
  const partnersSlide1: Partner[] = [
    {
      icon: '🏇',
      title: 'BÄIGE FEDERASIASY',
      subtitle: translate('partnerOrg1')
    },
    {
      icon: '🦅',
      title: 'ALASH PRIDE',
      subtitle: translate('partnerOrg2')
    },
    {
      icon: '🥊',
      title: 'QAZAQSTAN COMBAT ARTS ASSOCIATION',
      subtitle: translate('partnerOrg3')
    },
    {
      icon: '🥇',
      title: 'TOP DOG FC',
      subtitle: translate('partnerOrg4')
    },
    {
      icon: '🏓',
      title: 'TTFRK',
      subtitle: translate('partnerOrg5')
    },
    {
      icon: '🤼',
      title: 'ҚАЗАҚСТАН КҮРЕС ФЕДЕРАЦИЯСЫ',
      subtitle: translate('partnerOrg6')
    }
  ];

  const partnersSlide2: Partner[] = [
    {
      icon: '⚽',
      title: 'FOOTBALL FEDERATION',
      subtitle: translate('partnerOrg7')
    },
    {
      icon: '🎾',
      title: 'TENNIS CLUB',
      subtitle: translate('partnerOrg8')
    },
    {
      icon: '🏊',
      title: 'SWIMMING FEDERATION',
      subtitle: translate('partnerOrg9')
    },
    {
      icon: '🏃',
      title: 'ATHLETICS FEDERATION',
      subtitle: translate('partnerOrg10')
    },
    {
      icon: '🏸',
      title: 'BADMINTON ASSOCIATION',
      subtitle: translate('partnerOrg8')
    },
    {
      icon: '🥋',
      title: 'MARTIAL ARTS FEDERATION',
      subtitle: translate('partnerOrg3')
    }
  ];

  // Social media platforms
  const socialMediaPlatforms: SocialMediaPlatform[] = [
    {
      name: 'telegram',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.244-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
        </svg>
      )
    },
    {
      name: 'vk',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.864-.525-2.049-1.709-1.033-1.01-1.49-1.135-1.744-1.135-.356 0-.458.102-.458.593v1.575c0 .424-.135.678-1.253.678-1.846 0-3.896-1.118-5.335-3.202C4.624 10.857 4.03 8.57 4.03 8.145c0-.254.102-.491.593-.491h1.744c.44 0 .61.203.78.677.864 2.49 2.303 4.675 2.896 4.675.22 0 .322-.102.322-.66V9.721c-.068-1.186-.695-1.287-.695-1.71 0-.204.17-.407.44-.407h2.744c.373 0 .508.203.508.643v3.473c0 .372.169.508.271.508.22 0 .407-.136.813-.542 1.254-1.406 2.151-3.574 2.151-3.574.119-.254.322-.491.763-.491h1.744c.525 0 .644.27.525.643-.22 1.017-2.354 4.031-2.354 4.031-.186.305-.254.44 0 .78.186.254.796.779 1.202 1.253.745.847 1.32 1.558 1.473 2.05.17.49-.085.744-.576.744z"/>
        </svg>
      )
    },
    {
      name: 'instagram',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
        </svg>
      )
    },
    {
      name: 'tiktok',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
        </svg>
      )
    },
    {
      name: 'youtube',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
        </svg>
      )
    }
  ];

  // Reusable styles
  const styles = {
    socialButton: (platform: string): CSSProperties => ({
      width: '35px',
      height: '35px',
      backgroundColor: '#e53e3e',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'white',
      border: 'none',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      flexShrink: 0
    }),

    appStoreButton: (platform: string): CSSProperties => ({
      backgroundColor: '#2a2a2a',
      border: '1px solid #404040',
      padding: '8px 12px',
      borderRadius: '6px',
      fontSize: '11px',
      color: 'white',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      transition: 'all 0.3s ease',
      whiteSpace: 'nowrap',
      minWidth: '90px',
      justifyContent: 'center'
    })
  };

  // Render partner card
  const renderPartnerCard = (partner: Partner, index: number) => (
    <div
      key={index}
      style={{
        backgroundColor: 'rgba(74, 85, 104, 0.3)',
        border: '1px solid rgba(255,255,255,0.1)',
        padding: '20px',
        borderRadius: '12px',
        textAlign: 'center',
        height: '140px',
        width: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        transition: 'all 0.3s ease',
        cursor: 'pointer',
        backdropFilter: 'blur(10px)',
        boxSizing: 'border-box'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-5px)';
        e.currentTarget.style.backgroundColor = 'rgba(74, 85, 104, 0.5)';
        e.currentTarget.style.borderColor = 'rgba(255,255,255,0.3)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.backgroundColor = 'rgba(74, 85, 104, 0.3)';
        e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';
      }}
    >
      <div style={{
        width: '50px',
        height: '50px',
        backgroundColor: 'rgba(45, 55, 72, 0.8)',
        borderRadius: '50%',
        marginBottom: '8px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '20px',
        border: '2px solid rgba(255,255,255,0.2)',
        flexShrink: 0
      }}>
        {partner.icon}
      </div>
      <div style={{
        fontSize: '9px',
        fontWeight: 'bold',
        marginBottom: '4px',
        color: 'white',
        lineHeight: '1.1',
        textAlign: 'center',
        overflow: 'hidden',
        display: '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical'
      }}>
        {partner.title}
      </div>
      <div style={{
        fontSize: '8px',
        color: '#cbd5e0',
        lineHeight: '1.1',
        textAlign: 'center',
        overflow: 'hidden',
        display: '-webkit-box',
        WebkitLineClamp: 1,
        WebkitBoxOrient: 'vertical'
      }}>
        {partner.subtitle}
      </div>
    </div>
  );

  return (
    <footer
      style={{
        backgroundColor: '#232323',
        background: 'linear-gradient(135deg, #232323 0%, #2a2a2a 50%, #232323 100%)',
        color: 'white',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        width: '100%',
        position: 'relative',
        minWidth: '1600px',
        padding: '30px 0',
        minHeight: '400px',
        overflow: 'hidden'
      } as React.CSSProperties}
      dir="rtl"
    >
      {/* Partners Section */}
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '0 20px' }}>
        {/* Partners Heading */}
        <h3 style={{
          fontSize: '18px',
          margin: '0 0 40px 0',
          color: 'white',
          fontWeight: 'bold',
          textAlign: 'center',
          height: '22px'
        }}>
          {translate('partners')}
        </h3>

        {/* Partners Carousel Container */}
        <div style={{
          position: 'relative',
          marginBottom: '40px',
          height: '180px',
          overflow: 'hidden'
        }}>
          {/* Navigation Arrows and Slides (existing implementation) */}
          {/* ... (rest of the existing carousel implementation) ... */}
        </div>

        {/* Bottom Section */}
        <div style={{
          borderTop: '1px solid rgba(255,255,255,0.1)',
          paddingTop: '20px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          minHeight: '80px'
        }}>
          {/* Left Side - Age Restriction & Social Media */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '20px'
          }}>
            {/* Age Restriction */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px'
            }}>
              <div style={{
                width: '35px',
                height: '35px',
                backgroundColor: 'rgba(74, 85, 104, 0.5)',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 'bold',
                fontSize: '14px',
                border: '2px solid rgba(255,255,255,0.2)',
                flexShrink: 0
              }}>
                21+
              </div>
              <span style={{
                fontSize: '13px',
                color: '#cbd5e0',
                display: 'flex',
                alignItems: 'center',
                gap: '5px',
                whiteSpace: 'nowrap'
              }}>
                🛡️ {translate('responsible_play')}
              </span>
            </div>

            {/* Social Media Icons */}
            <div style={{
              display: 'flex',
              gap: '8px'
            }}>
              {socialMediaPlatforms.map((platform) => (
                <button
                  key={platform.name}
                  style={styles.socialButton(platform.name)}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'scale(1.1)';
                    e.currentTarget.style.backgroundColor = '#dc2626';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'scale(1)';
                    e.currentTarget.style.backgroundColor = '#e53e3e';
                  }}
                >
                  {platform.icon}
                </button>
              ))}
            </div>
          </div>

          {/* Middle Section - App Downloads & OLIMPBET */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '15px'
          }}>
            {/* App Download Buttons */}
            <div style={{
              display: 'flex',
              gap: '6px'
            }}>
              {['AppGallery', 'Galaxy Store', 'App Store', 'Android'].map((platform) => (
                <button
                  key={platform}
                  style={styles.appStoreButton(platform)}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#404040';
                    e.currentTarget.style.borderColor = '#555555';
                    e.currentTarget.style.transform = 'translateY(-2px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#2a2a2a';
                    e.currentTarget.style.borderColor = '#404040';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  {platform}
                </button>
              ))}
            </div>

            {/* OLIMPBET Logo */}
            <div style={{
              backgroundColor: '#e53e3e',
              padding: '8px 16px',
              borderRadius: '6px',
              textAlign: 'center',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              flexShrink: 0
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#dc2626';
              e.currentTarget.style.transform = 'scale(1.05)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#e53e3e';
              e.currentTarget.style.transform = 'scale(1)';
            }}
            >
              <div style={{
                color: 'white',
                fontWeight: 'bold',
                fontSize: '14px',
                whiteSpace: 'nowrap'
              }}>
                🅾 OLIMPBET
              </div>
            </div>
          </div>

          {/* Right Side - Mobile Version & Copyright */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-end',
            gap: '5px'
          }}>
            <button style={{
              fontSize: '13px',
              color: '#cbd5e0',
              textDecoration: 'underline',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              transition: 'color 0.3s ease',
              whiteSpace: 'nowrap'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = 'white';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = '#cbd5e0';
            }}
            >
              {translate('mobileVersion')}
            </button>
            <div style={{
              fontSize: '12px',
              color: '#a0aec0',
              textAlign: isRTL ? 'right' : 'left',
              whiteSpace: 'nowrap'
            }}>
              NetBet LLP {translate('copyright')} 2025
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer; 
