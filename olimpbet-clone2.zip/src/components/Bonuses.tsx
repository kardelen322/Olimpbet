import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const Bonuses: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState('active');

  const activeBonuses = [
    {
      id: 1,
      title: 'Приветственный бонус 100%',
      subtitle: 'До 25 000 ₽ на первый депозит',
      description: 'Получите 100% бонус на первый депозит до 25 000 рублей. Минимальный депозит 500 ₽.',
      type: 'welcome',
      icon: '🎁',
      color: '#6b0c17',
      requirements: ['Минимальный депозит: 500 ₽', 'Вейджер: x5', 'Срок отыгрыша: 30 дней'],
      terms: 'Бонус действует только для новых пользователей. Необходимо отыграть сумму бонуса с коэффициентом 5 раз.',
      validUntil: '31.12.2024',
      claimed: false
    },
    {
      id: 2,
      title: 'Кэшбек до 10%',
      subtitle: 'Еженедельный возврат проигранных средств',
      description: 'Получайте до 10% кэшбека с проигранных ставок каждую неделю. Автоматическое начисление по понедельникам.',
      type: 'cashback',
      icon: '💰',
      color: '#22c55e',
      requirements: ['Минимальные ставки: 1000 ₽/неделю', 'Максимальный кэшбек: 5000 ₽', 'Начисление: понедельник'],
      terms: 'Кэшбек рассчитывается с чистого проигрыша за неделю. Без вейджера.',
      validUntil: 'Постоянно',
      claimed: true
    },
    {
      id: 3,
      title: 'Фрибет 2000 ₽',
      subtitle: 'Бесплатная ставка на футбол',
      description: 'Получите бесплатную ставку 2000 рублей на любой футбольный матч с коэффициентом от 1.80.',
      type: 'freebet',
      icon: '⚽',
      color: '#3b82f6',
      requirements: ['Коэффициент: от 1.80', 'Только футбол', 'Срок действия: 7 дней'],
      terms: 'Фрибет выдается после выполнения условий акции. Выигрыш зачисляется без учета суммы фрибета.',
      validUntil: '15.01.2025',
      claimed: false
    },
    {
      id: 4,
      title: 'Акция "Экспресс дня"',
      subtitle: '+15% к выигрышу',
      description: 'Дополнительные 15% к выигрышу за экспресс ставки от 3 событий с общим коэффициентом от 4.0.',
      type: 'boost',
      icon: '🚀',
      color: '#f59e0b',
      requirements: ['Минимум 3 события', 'Общий коэффициент: от 4.0', 'Максимальный бонус: 10 000 ₽'],
      terms: 'Бонус начисляется автоматически при выигрыше экспресс ставки, соответствующей условиям.',
      validUntil: 'Ежедневно',
      claimed: false
    }
  ];

  const vipLevels = [
    {
      level: 'Bronze',
      icon: '🥉',
      color: '#cd7f32',
      minBets: '10 000 ₽',
      benefits: ['Кэшбек 2%', 'День рождения бонус 1000 ₽', 'Приоритетная поддержка'],
      current: false
    },
    {
      level: 'Silver',
      icon: '🥈',
      color: '#c0c0c0',
      minBets: '50 000 ₽',
      benefits: ['Кэшбек 5%', 'День рождения бонус 2500 ₽', 'Персональный менеджер', 'Ускоренные выводы'],
      current: true
    },
    {
      level: 'Gold',
      icon: '🥇',
      color: '#ffd700',
      minBets: '150 000 ₽',
      benefits: ['Кэшбек 8%', 'День рождения бонус 5000 ₽', 'VIP турниры', 'Эксклюзивные бонусы'],
      current: false
    },
    {
      level: 'Platinum',
      icon: '💎',
      color: '#e5e4e2',
      minBets: '500 000 ₽',
      benefits: ['Кэшбек 10%', 'День рождения бонус 10000 ₽', 'Индивидуальные лимиты', 'VIP мероприятия'],
      current: false
    }
  ];

  const expiredBonuses = [
    {
      id: 5,
      title: 'Новогодний марафон',
      subtitle: 'Праздничные бонусы завершены',
      description: 'Специальная новогодняя акция с ежедневными подарками.',
      expiredDate: '10.01.2024',
      type: 'seasonal'
    },
    {
      id: 6,
      title: 'Бонус на Чемпионат Европы',
      subtitle: 'Турнирные бонусы завершены',
      description: 'Специальные предложения на матчи Евро-2024.',
      expiredDate: '15.07.2024',
      type: 'tournament'
    }
  ];

  const promoCode = 'OLIMP2024';

  return (
    <div style={{ 
      display: 'flex', 
      margin: '0 auto', 
      padding: '20px 20px 20px 10px',
      gap: '20px' 
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />
      
      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '40px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          background: 'linear-gradient(135deg, #6b0c17 0%, #8b1a1a 100%)',
          color: 'white'
        }}>
          <h1 style={{
            fontSize: '36px',
            fontWeight: 'bold',
            margin: '0 0 10px 0'
          }}>
            🎁 БОНУСЫ И АКЦИИ
          </h1>
          <p style={{
            fontSize: '18px',
            margin: '0 0 20px 0',
            opacity: 0.9
          }}>
            Получайте дополнительные выгоды от игры на OLIMPBET
          </p>
          
          {/* Promo Code Section */}
          <div style={{
            backgroundColor: 'rgba(255,255,255,0.1)',
            borderRadius: '10px',
            padding: '20px',
            marginTop: '20px',
            display: 'inline-block'
          }}>
            <div style={{ fontSize: '14px', marginBottom: '8px', opacity: 0.8 }}>
              ПРОМОКОД МЕСЯЦА
            </div>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '15px',
              justifyContent: 'center'
            }}>
              <div style={{
                backgroundColor: 'white',
                color: '#6b0c17',
                padding: '10px 20px',
                borderRadius: '8px',
                fontSize: '18px',
                fontWeight: 'bold',
                letterSpacing: '2px'
              }}>
                {promoCode}
              </div>
              <button
                onClick={() => navigator.clipboard.writeText(promoCode)}
                style={{
                  backgroundColor: 'transparent',
                  border: '2px solid white',
                  color: 'white',
                  padding: '10px 16px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'white';
                  e.currentTarget.style.color = '#6b0c17';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.color = 'white';
                }}
              >
                КОПИРОВАТЬ
              </button>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div style={{
          backgroundColor: 'white',
          padding: '0',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ display: 'flex' }}>
            {[
              { key: 'active', label: 'Активные бонусы', count: activeBonuses.length },
              { key: 'vip', label: 'VIP программа', count: vipLevels.length },
              { key: 'expired', label: 'Завершенные', count: expiredBonuses.length }
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                style={{
                  flex: 1,
                  padding: '15px 20px',
                  border: 'none',
                  backgroundColor: activeTab === tab.key ? '#6b0c17' : 'white',
                  color: activeTab === tab.key ? 'white' : '#666',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== tab.key) {
                    e.currentTarget.style.backgroundColor = '#f5f5f5';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== tab.key) {
                    e.currentTarget.style.backgroundColor = 'white';
                  }
                }}
              >
                <span>{tab.label}</span>
                <span style={{
                  backgroundColor: activeTab === tab.key ? 'rgba(255,255,255,0.2)' : '#6b0c17',
                  color: activeTab === tab.key ? 'white' : 'white',
                  padding: '2px 8px',
                  borderRadius: '12px',
                  fontSize: '12px',
                  minWidth: '20px'
                }}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Active Bonuses Tab */}
        {activeTab === 'active' && (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
            gap: '20px'
          }}>
            {activeBonuses.map((bonus) => (
              <div
                key={bonus.id}
                style={{
                  backgroundColor: 'white',
                  borderRadius: '16px',
                  padding: '30px',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                  border: `3px solid ${bonus.color}20`,
                  position: 'relative',
                  overflow: 'hidden',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-5px)';
                  e.currentTarget.style.boxShadow = `0 8px 25px ${bonus.color}30`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
                }}
              >
                {/* Bonus Type Badge */}
                <div style={{
                  position: 'absolute',
                  top: '15px',
                  right: '15px',
                  backgroundColor: bonus.color,
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '20px',
                  fontSize: '11px',
                  fontWeight: 'bold',
                  textTransform: 'uppercase'
                }}>
                  {bonus.type}
                </div>

                {/* Header */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '15px',
                  marginBottom: '20px'
                }}>
                  <div style={{
                    fontSize: '40px',
                    width: '60px',
                    height: '60px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: `${bonus.color}15`,
                    borderRadius: '50%'
                  }}>
                    {bonus.icon}
                  </div>
                  <div>
                    <h3 style={{
                      fontSize: '20px',
                      fontWeight: 'bold',
                      color: bonus.color,
                      margin: '0 0 5px 0'
                    }}>
                      {bonus.title}
                    </h3>
                    <p style={{
                      fontSize: '14px',
                      color: '#666',
                      margin: '0',
                      fontWeight: '500'
                    }}>
                      {bonus.subtitle}
                    </p>
                  </div>
                </div>

                {/* Description */}
                <p style={{
                  fontSize: '15px',
                  color: '#555',
                  lineHeight: 1.6,
                  marginBottom: '20px'
                }}>
                  {bonus.description}
                </p>

                {/* Requirements */}
                <div style={{ marginBottom: '20px' }}>
                  <h4 style={{
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333',
                    marginBottom: '10px'
                  }}>
                    Условия:
                  </h4>
                  {bonus.requirements.map((req, index) => (
                    <div key={index} style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      marginBottom: '6px'
                    }}>
                      <div style={{
                        width: '6px',
                        height: '6px',
                        borderRadius: '50%',
                        backgroundColor: bonus.color
                      }} />
                      <span style={{
                        fontSize: '13px',
                        color: '#666'
                      }}>
                        {req}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Terms */}
                <div style={{
                  backgroundColor: '#f8f9fa',
                  padding: '15px',
                  borderRadius: '8px',
                  marginBottom: '20px'
                }}>
                  <p style={{
                    fontSize: '12px',
                    color: '#666',
                    margin: '0',
                    lineHeight: 1.4
                  }}>
                    <strong>Условия:</strong> {bonus.terms}
                  </p>
                </div>

                {/* Footer */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <div style={{
                    fontSize: '12px',
                    color: '#666'
                  }}>
                    Действует до: <strong>{bonus.validUntil}</strong>
                  </div>
                  <button
                    disabled={bonus.claimed}
                    style={{
                      backgroundColor: bonus.claimed ? '#e5e7eb' : bonus.color,
                      color: bonus.claimed ? '#9ca3af' : 'white',
                      border: 'none',
                      padding: '10px 20px',
                      borderRadius: '8px',
                      fontSize: '14px',
                      fontWeight: 'bold',
                      cursor: bonus.claimed ? 'not-allowed' : 'pointer',
                      transition: 'all 0.3s ease'
                    }}
                    onMouseEnter={(e) => {
                      if (!bonus.claimed) {
                        e.currentTarget.style.transform = 'translateY(-2px)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!bonus.claimed) {
                        e.currentTarget.style.transform = 'translateY(0)';
                      }
                    }}
                  >
                    {bonus.claimed ? 'Получен' : 'Получить'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* VIP Program Tab */}
        {activeTab === 'vip' && (
          <div>
            {/* VIP Header */}
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '12px',
              marginBottom: '30px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
              textAlign: 'center',
              background: 'linear-gradient(135deg, #1f2937 0%, #374151 100%)',
              color: 'white'
            }}>
              <h2 style={{
                fontSize: '28px',
                fontWeight: 'bold',
                marginBottom: '15px'
              }}>
                💎 VIP ПРОГРАММА OLIMPBET
              </h2>
              <p style={{
                fontSize: '16px',
                opacity: 0.9,
                marginBottom: '20px'
              }}>
                Эксклюзивные привилегии для наших лучших игроков
              </p>
              <div style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '10px',
                backgroundColor: 'rgba(255,255,255,0.1)',
                padding: '10px 20px',
                borderRadius: '25px'
              }}>
                <span style={{ fontSize: '14px' }}>Ваш текущий статус:</span>
                <span style={{
                  backgroundColor: '#c0c0c0',
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '15px',
                  fontSize: '14px',
                  fontWeight: 'bold'
                }}>
                  🥈 SILVER
                </span>
              </div>
            </div>

            {/* VIP Levels Grid */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '20px',
              marginBottom: '30px'
            }}>
              {vipLevels.map((level, index) => (
                <div
                  key={level.level}
                  style={{
                    backgroundColor: 'white',
                    borderRadius: '16px',
                    padding: '25px',
                    boxShadow: level.current ? `0 8px 25px ${level.color}40` : '0 4px 12px rgba(0, 0, 0, 0.1)',
                    border: level.current ? `3px solid ${level.color}` : '3px solid transparent',
                    position: 'relative',
                    transform: level.current ? 'scale(1.05)' : 'scale(1)',
                    transition: 'all 0.3s ease'
                  }}
                  onMouseEnter={(e) => {
                    if (!level.current) {
                      e.currentTarget.style.transform = 'translateY(-5px)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!level.current) {
                      e.currentTarget.style.transform = 'translateY(0)';
                    }
                  }}
                >
                  {level.current && (
                    <div style={{
                      position: 'absolute',
                      top: '15px',
                      right: '15px',
                      backgroundColor: level.color,
                      color: 'white',
                      padding: '6px 12px',
                      borderRadius: '15px',
                      fontSize: '11px',
                      fontWeight: 'bold'
                    }}>
                      ТЕКУЩИЙ
                    </div>
                  )}

                  <div style={{
                    textAlign: 'center',
                    marginBottom: '20px'
                  }}>
                    <div style={{
                      fontSize: '48px',
                      marginBottom: '10px'
                    }}>
                      {level.icon}
                    </div>
                    <h3 style={{
                      fontSize: '22px',
                      fontWeight: 'bold',
                      color: level.color,
                      margin: '0 0 8px 0'
                    }}>
                      {level.level}
                    </h3>
                    <p style={{
                      fontSize: '14px',
                      color: '#666',
                      margin: '0'
                    }}>
                      От {level.minBets} ставок
                    </p>
                  </div>

                  <div>
                    <h4 style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#333',
                      marginBottom: '15px'
                    }}>
                      Привилегии:
                    </h4>
                    {level.benefits.map((benefit, benefitIndex) => (
                      <div key={benefitIndex} style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        marginBottom: '10px'
                      }}>
                        <div style={{
                          width: '20px',
                          height: '20px',
                          borderRadius: '50%',
                          backgroundColor: level.color,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '12px'
                        }}>
                          ✓
                        </div>
                        <span style={{
                          fontSize: '14px',
                          color: '#555'
                        }}>
                          {benefit}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* VIP Progress */}
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '12px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
            }}>
              <h3 style={{
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#333',
                marginBottom: '20px',
                textAlign: 'center'
              }}>
                Прогресс до следующего уровня
              </h3>
              
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '20px',
                marginBottom: '15px'
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}>
                  <span style={{ fontSize: '24px' }}>🥈</span>
                  <span style={{ fontWeight: 'bold' }}>Silver</span>
                </div>
                
                <div style={{
                  flex: 1,
                  height: '12px',
                  backgroundColor: '#f1f5f9',
                  borderRadius: '6px',
                  overflow: 'hidden'
                }}>
                  <div style={{
                    height: '100%',
                    width: '65%',
                    backgroundColor: '#ffd700',
                    borderRadius: '6px',
                    transition: 'width 0.5s ease'
                  }} />
                </div>
                
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}>
                  <span style={{ fontSize: '24px' }}>🥇</span>
                  <span style={{ fontWeight: 'bold' }}>Gold</span>
                </div>
              </div>
              
              <div style={{
                textAlign: 'center',
                fontSize: '14px',
                color: '#666'
              }}>
                Сделано ставок: <strong>97 500 ₽</strong> из <strong>150 000 ₽</strong>
                <br />
                До Gold статуса осталось: <strong>52 500 ₽</strong>
              </div>
            </div>
          </div>
        )}

        {/* Expired Bonuses Tab */}
        {activeTab === 'expired' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '30px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '25px',
              textAlign: 'center'
            }}>
              Завершенные акции
            </h2>
            
            {expiredBonuses.map((bonus) => (
              <div
                key={bonus.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '20px',
                  padding: '20px',
                  marginBottom: '15px',
                  backgroundColor: '#f8f9fa',
                  borderRadius: '10px',
                  border: '1px solid #e5e7eb',
                  opacity: 0.7
                }}
              >
                <div style={{
                  width: '60px',
                  height: '60px',
                  borderRadius: '50%',
                  backgroundColor: '#9ca3af',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '24px'
                }}>
                  ⏰
                </div>
                
                <div style={{ flex: 1 }}>
                  <h3 style={{
                    fontSize: '18px',
                    fontWeight: 'bold',
                    color: '#6b7280',
                    margin: '0 0 5px 0'
                  }}>
                    {bonus.title}
                  </h3>
                  <p style={{
                    fontSize: '14px',
                    color: '#9ca3af',
                    margin: '0 0 8px 0'
                  }}>
                    {bonus.subtitle}
                  </p>
                  <p style={{
                    fontSize: '13px',
                    color: '#6b7280',
                    margin: '0'
                  }}>
                    {bonus.description}
                  </p>
                </div>
                
                <div style={{
                  textAlign: 'right'
                }}>
                  <div style={{
                    fontSize: '12px',
                    color: '#ef4444',
                    fontWeight: 'bold'
                  }}>
                    ЗАВЕРШЕНА
                  </div>
                  <div style={{
                    fontSize: '12px',
                    color: '#9ca3af',
                    marginTop: '4px'
                  }}>
                    {bonus.expiredDate}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Bonuses; 