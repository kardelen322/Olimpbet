import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import ImageCarousel from './ImageCarousel';

const LiveMatches: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [selectedSport, setSelectedSport] = useState('all');
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every second for live feeling
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const liveMatches = [
    {
      id: 1,
      sport: 'football',
      sportName: 'Футбол',
      league: 'Премьер-лига России',
      homeTeam: 'Зенит',
      awayTeam: 'Спартак',
      homeScore: 1,
      awayScore: 0,
      time: '67\'',
      status: 'live',
      odds: { home: '1.85', draw: '3.90', away: '4.20' },
      viewers: 25840,
      events: [
        { time: '23\'', type: 'goal', team: 'home', player: 'Азмун', score: '', winner: '' },
        { time: '45\'', type: 'yellow', team: 'away', player: 'Промес', score: '', winner: '' },
        { time: '62\'', type: 'substitution', team: 'home', player: 'Малком → Сутормин', score: '', winner: '' }
      ]
    },
    {
      id: 2,
      sport: 'football',
      sportName: 'Футбол',
      league: 'Английская Премьер-лига',
      homeTeam: 'Манчестер Юнайтед',
      awayTeam: 'Ливерпуль',
      homeScore: 2,
      awayScore: 2,
      time: '84\'',
      status: 'live',
      odds: { home: '2.10', draw: '3.50', away: '3.40' },
      viewers: 45320,
      events: [
        { time: '12\'', type: 'goal', team: 'away', player: 'Салах', score: '', winner: '' },
        { time: '35\'', type: 'goal', team: 'home', player: 'Рашфорд', score: '', winner: '' },
        { time: '52\'', type: 'goal', team: 'home', player: 'Бруну Фернандеш', score: '', winner: '' },
        { time: '71\'', type: 'goal', team: 'away', player: 'Нуньес', score: '', winner: '' },
        { time: '78\'', type: 'red', team: 'home', player: 'Касемиро', score: '', winner: '' }
      ]
    },
    {
      id: 3,
      sport: 'football',
      sportName: 'Футбол',
      league: 'Лига Чемпионов UEFA',
      homeTeam: 'Реал Мадрид',
      awayTeam: 'Бавария',
      homeScore: 1,
      awayScore: 1,
      time: '45+2\'',
      status: 'live',
      odds: { home: '2.75', draw: '3.40', away: '2.60' },
      viewers: 89650,
      events: [
        { time: '23\'', type: 'goal', team: 'home', player: 'Винисиус Жуниор', score: '', winner: '' },
        { time: '38\'', type: 'goal', team: 'away', player: 'Сане', score: '', winner: '' },
        { time: '41\'', type: 'yellow', team: 'home', player: 'Карвахаль', score: '', winner: '' }
      ]
    },
    {
      id: 4,
      sport: 'tennis',
      sportName: 'Теннис',
      league: 'ATP 250 Вашингтон',
      homeTeam: 'Медведев Д.',
      awayTeam: 'Циципас С.',
      homeScore: 2,
      awayScore: 1,
      time: '3-й сет',
      status: 'live',
      odds: { home: '1.65', draw: '-', away: '2.20' },
      viewers: 12500,
      events: [
        { time: '1-й сет', type: 'set', team: 'home', player: '', score: '6-4', winner: 'home' },
        { time: '2-й сет', type: 'set', team: 'away', player: '', score: '7-6', winner: 'away' },
        { time: '3-й сет', type: 'game', team: 'home', player: '', score: '4-2', winner: '' }
      ]
    },
    {
      id: 5,
      sport: 'basketball',
      sportName: 'Баскетбол',
      league: 'Евролига',
      homeTeam: 'ЦСКА Москва',
      awayTeam: 'Реал Мадрид',
      homeScore: 78,
      awayScore: 82,
      time: '4-я четверть 3:45',
      status: 'live',
      odds: { home: '2.90', draw: '-', away: '1.40' },
      viewers: 18900,
      events: [
        { time: '1-я ч.', type: 'quarter', team: '', player: '', score: '22-20', winner: 'home' },
        { time: '2-я ч.', type: 'quarter', team: '', player: '', score: '18-25', winner: 'away' },
        { time: '3-я ч.', type: 'quarter', team: '', player: '', score: '20-22', winner: 'away' },
        { time: '36:15', type: 'timeout', team: 'home', player: 'Тайм-аут ЦСКА', score: '', winner: '' }
      ]
    },
    {
      id: 6,
      sport: 'hockey',
      sportName: 'Хоккей',
      league: 'КХЛ',
      homeTeam: 'СКА',
      awayTeam: 'Ак Барс',
      homeScore: 3,
      awayScore: 2,
      time: '3-й период 12:30',
      status: 'live',
      odds: { home: '1.70', draw: '4.20', away: '4.50' },
      viewers: 22100,
      events: [
        { time: '08:45', type: 'goal', team: 'home', player: 'Гусев', score: '1-0', winner: '' },
        { time: '15:20', type: 'goal', team: 'away', player: 'Радулов', score: '1-1', winner: '' },
        { time: '28:10', type: 'goal', team: 'home', player: 'Морозов', score: '2-1', winner: '' },
        { time: '35:55', type: 'goal', team: 'away', player: 'Галимов', score: '2-2', winner: '' },
        { time: '42:18', type: 'goal', team: 'home', player: 'Кузьменко', score: '3-2', winner: '' }
      ]
    },
    {
      id: 7,
      sport: 'volleyball',
      sportName: 'Волейбол',
      league: 'Суперлига России',
      homeTeam: 'Зенит-Казань',
      awayTeam: 'Динамо Москва',
      homeScore: 2,
      awayScore: 1,
      time: '4-й сет',
      status: 'live',
      odds: { home: '1.35', draw: '-', away: '3.10' },
      viewers: 8700,
      events: [
        { time: '1-й сет', type: 'set', team: 'home', player: '', score: '25-23', winner: 'home' },
        { time: '2-й сет', type: 'set', team: 'away', player: '', score: '22-25', winner: 'away' },
        { time: '3-й сет', type: 'set', team: 'home', player: '', score: '25-20', winner: 'home' },
        { time: '4-й сет', type: 'game', team: '', player: '', score: '18-16', winner: '' }
      ]
    },
    {
      id: 8,
      sport: 'handball',
      sportName: 'Гандбол',
      league: 'Лига Чемпионов EHF',
      homeTeam: 'Барселона',
      awayTeam: 'ПСЖ',
      homeScore: 28,
      awayScore: 26,
      time: '2-й тайм 25:00',
      status: 'live',
      odds: { home: '1.55', draw: '12.00', away: '2.35' },
      viewers: 6500,
      events: [
        { time: '1-й тайм', type: 'half', team: '', player: '', score: '14-13', winner: 'home' },
        { time: '48:30', type: 'penalty', team: 'away', player: 'Реймсон - 7м', score: '', winner: '' },
        { time: '52:10', type: 'suspension', team: 'home', player: 'Фабрегас - 2 мин', score: '', winner: '' }
      ]
    },
    {
      id: 9,
      sport: 'tabletennis',
      sportName: 'Настольный теннис',
      league: 'WTT Star Contender',
      homeTeam: 'Фан Чжэндун',
      awayTeam: 'Ма Лонг',
      homeScore: 3,
      awayScore: 2,
      time: '6-й сет',
      status: 'live',
      odds: { home: '1.80', draw: '-', away: '1.95' },
      viewers: 3200,
      events: [
        { time: '1-й сет', type: 'set', team: 'home', player: '', score: '11-9', winner: 'home' },
        { time: '2-й сет', type: 'set', team: 'away', player: '', score: '8-11', winner: 'away' },
        { time: '3-й сет', type: 'set', team: 'home', player: '', score: '11-7', winner: 'home' },
        { time: '4-й сет', type: 'set', team: 'away', player: '', score: '9-11', winner: 'away' },
        { time: '5-й сет', type: 'set', team: 'home', player: '', score: '11-8', winner: 'home' },
        { time: '6-й сет', type: 'game', team: '', player: '', score: '7-5', winner: '' }
      ]
    },
    {
      id: 10,
      sport: 'esports',
      sportName: 'Киберспорт',
      league: 'CS:GO - ESL Pro League',
      homeTeam: 'Na\'Vi',
      awayTeam: 'FaZe Clan',
      homeScore: 1,
      awayScore: 0,
      time: 'Карта 2 - Mirage',
      status: 'live',
      odds: { home: '1.72', draw: '-', away: '2.05' },
      viewers: 125000,
      events: [
        { time: 'Карта 1', type: 'map', team: 'home', player: '', score: '16-12', winner: 'home' },
        { time: 'Mirage', type: 'round', team: '', player: '', score: '8-4', winner: '' },
        { time: 'Раунд 12', type: 'ace', team: 'home', player: 's1mple - ACE!', score: '', winner: '' }
      ]
    }
  ];

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'goal': return '⚽';
      case 'yellow': return '🟨';
      case 'red': return '🟥';
      case 'substitution': return '🔄';
      case 'set': return '🎾';
      case 'game': return '🎯';
      case 'quarter': return '🏀';
      case 'half': return '⏱️';
      case 'timeout': return '⏸️';
      case 'penalty': return '⚠️';
      case 'suspension': return '🚫';
      case 'map': return '🗺️';
      case 'round': return '🎮';
      case 'ace': return '🌟';
      default: return '📝';
    }
  };

  // Promotional banner images
  const bannerImages = [
    '/image1.png',
    '/image2.png',
    '/image3.png',
    '/image4.png',
    '/image5.png',
    '/image6.png'
  ];

  return (
    <div style={{
      flex: 1,
      backgroundColor: '#f5f5f5',
      borderRadius: '8px',
      overflow: 'hidden'
    }}>
      {/* Promotional Banner/Carousel */}
      <div style={{
        marginBottom: '20px',
        height: '350px'
      }}>
        <ImageCarousel images={bannerImages} autoSlideInterval={5000} />
      </div>

      {/* Live Matches Section */}
      <div style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
          color: 'white'
        }}>
          <h1 style={{
            fontSize: '36px',
            fontWeight: 'bold',
            margin: '0 0 10px 0',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '15px'
          }}>
            🔴 ЛАЙВ
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
              fontSize: '18px',
              fontWeight: 'normal'
            }}>
              <div style={{
                width: '12px',
                height: '12px',
                borderRadius: '50%',
                backgroundColor: '#22c55e',
                animation: 'pulse 2s infinite'
              }}></div>
              LIVE
            </div>
          </h1>
        </div>

        {/* Quick Bets Section */}
        <div style={{
          backgroundColor: '#f9fafb',
          borderRadius: '8px',
          padding: '20px',
          marginBottom: '20px'
        }}>
          <h3 style={{
            fontSize: '18px',
            fontWeight: 'bold',
            marginBottom: '15px',
            color: '#333'
          }}>
            ⚡ Быстрые ставки
          </h3>
          <div style={{
            display: 'flex',
            gap: '10px',
            flexWrap: 'wrap'
          }}>
            <button style={{
              backgroundColor: '#6b0c17',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#8b1c27'}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#6b0c17'}>
              Топ матчи
            </button>
            <button style={{
              backgroundColor: 'white',
              color: '#333',
              border: '1px solid #e5e7eb',
              padding: '10px 20px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '14px',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#f3f4f6'; e.currentTarget.style.borderColor = '#6b0c17'; }}
            onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'white'; e.currentTarget.style.borderColor = '#e5e7eb'; }}>
              Высокие коэффициенты
            </button>
            <button style={{
              backgroundColor: 'white',
              color: '#333',
              border: '1px solid #e5e7eb',
              padding: '10px 20px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '14px',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#f3f4f6'; e.currentTarget.style.borderColor = '#6b0c17'; }}
            onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'white'; e.currentTarget.style.borderColor = '#e5e7eb'; }}>
              Популярные
            </button>
            <button style={{
              backgroundColor: 'white',
              color: '#333',
              border: '1px solid #e5e7eb',
              padding: '10px 20px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '14px',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#f3f4f6'; e.currentTarget.style.borderColor = '#6b0c17'; }}
            onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'white'; e.currentTarget.style.borderColor = '#e5e7eb'; }}>
              Начинаются скоро
            </button>
          </div>
        </div>

        {/* Matches List */}
        {liveMatches.map(match => (
          <div 
            key={match.id} 
            style={{
              backgroundColor: 'white',
              borderRadius: '12px',
              padding: '20px',
              marginBottom: '15px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
            }}
          >
            {/* Match Details */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '15px'
            }}>
              <div style={{
                fontSize: '16px',
                fontWeight: 'bold',
                color: '#6b0c17'
              }}>
                {match.league}
              </div>
              <div style={{
                backgroundColor: '#e5e7eb',
                color: 'red',
                padding: '4px 8px',
                borderRadius: '4px',
                fontSize: '12px',
                fontWeight: 'bold'
              }}>
                LIVE {match.time}
              </div>
            </div>

            {/* Teams and Score */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '15px'
            }}>
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                flex: 1
              }}>
                <div style={{
                  fontSize: '18px',
                  fontWeight: 'bold'
                }}>
                  {match.homeTeam}
                </div>
                <div style={{
                  fontSize: '24px',
                  fontWeight: 'bold',
                  color: '#6b0c17'
                }}>
                  {match.homeScore}
                </div>
              </div>
              <div style={{
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#666',
                margin: '0 15px'
              }}>
                :
              </div>
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                flex: 1
              }}>
                <div style={{
                  fontSize: '18px',
                  fontWeight: 'bold'
                }}>
                  {match.awayTeam}
                </div>
                <div style={{
                  fontSize: '24px',
                  fontWeight: 'bold',
                  color: '#6b0c17'
                }}>
                  {match.awayScore}
                </div>
              </div>
            </div>

            {/* Match Events */}
            <div style={{
              backgroundColor: '#f9fafb',
              borderRadius: '8px',
              padding: '10px',
              maxHeight: '150px',
              overflowY: 'auto'
            }}>
              {match.events.map((event, index) => (
                <div 
                  key={`match-${match.id}-event-${index}`}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    marginBottom: '5px',
                    fontSize: '14px',
                    color: '#666'
                  }}
                >
                  <span style={{ marginRight: '10px' }}>
                    {getEventIcon(event.type)}
                  </span>
                  <span style={{ fontWeight: 'bold', marginRight: '10px' }}>
                    {event.time}
                  </span>
                  <span>
                    {event.player} - {event.type}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      {/* Upcoming Matches Section */}
      <div style={{
        marginTop: '30px',
        backgroundColor: 'white',
        borderRadius: '12px',
        padding: '20px',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
      }}>
        <h2 style={{
          fontSize: '24px',
          fontWeight: 'bold',
          marginBottom: '20px',
          color: '#333'
        }}>
          📅 Предстоящие матчи
        </h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: '15px'
        }}>
          {/* Football upcoming */}
          <div style={{
            border: '1px solid #e5e7eb',
            borderRadius: '8px',
            padding: '15px',
            backgroundColor: '#f9fafb'
          }}>
            <div style={{ fontSize: '12px', color: '#666', marginBottom: '5px' }}>
              Футбол • Лига Европы • Завтра 20:00
            </div>
            <div style={{ fontWeight: 'bold', marginBottom: '10px' }}>
              Арсенал vs Милан
            </div>
            <div style={{ display: 'flex', gap: '10px', fontSize: '14px' }}>
              <span style={{ backgroundColor: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>1: 1.85</span>
              <span style={{ backgroundColor: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>X: 3.60</span>
              <span style={{ backgroundColor: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>2: 4.20</span>
            </div>
          </div>
          
          {/* Tennis upcoming */}
          <div style={{
            border: '1px solid #e5e7eb',
            borderRadius: '8px',
            padding: '15px',
            backgroundColor: '#f9fafb'
          }}>
            <div style={{ fontSize: '12px', color: '#666', marginBottom: '5px' }}>
              Теннис • US Open • Сегодня 23:00
            </div>
            <div style={{ fontWeight: 'bold', marginBottom: '10px' }}>
              Джокович Н. vs Алькарас К.
            </div>
            <div style={{ display: 'flex', gap: '10px', fontSize: '14px' }}>
              <span style={{ backgroundColor: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>1: 2.10</span>
              <span style={{ backgroundColor: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>2: 1.70</span>
            </div>
          </div>
          
          {/* Basketball upcoming */}
          <div style={{
            border: '1px solid #e5e7eb',
            borderRadius: '8px',
            padding: '15px',
            backgroundColor: '#f9fafb'
          }}>
            <div style={{ fontSize: '12px', color: '#666', marginBottom: '5px' }}>
              Баскетбол • NBA • Завтра 02:00
            </div>
            <div style={{ fontWeight: 'bold', marginBottom: '10px' }}>
              Lakers vs Celtics
            </div>
            <div style={{ display: 'flex', gap: '10px', fontSize: '14px' }}>
              <span style={{ backgroundColor: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>1: 1.90</span>
              <span style={{ backgroundColor: '#e5e7eb', padding: '2px 8px', borderRadius: '4px' }}>2: 1.85</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Statistics Banner */}
      <div style={{
        marginTop: '30px',
        background: 'linear-gradient(135deg, #6b0c17 0%, #8b1c27 100%)',
        borderRadius: '12px',
        padding: '40px',
        color: 'white',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)'
      }}>
        <h2 style={{
          fontSize: '28px',
          fontWeight: 'bold',
          marginBottom: '30px',
          textAlign: 'center'
        }}>
          🏆 Почему выбирают OLIMPBET
        </h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '30px',
          textAlign: 'center'
        }}>
          <div>
            <div style={{ fontSize: '36px', fontWeight: 'bold', marginBottom: '10px' }}>2,500,000+</div>
            <div style={{ fontSize: '14px', opacity: 0.9 }}>Активных пользователей</div>
          </div>
          <div>
            <div style={{ fontSize: '36px', fontWeight: 'bold', marginBottom: '10px' }}>30+</div>
            <div style={{ fontSize: '14px', opacity: 0.9 }}>Видов спорта</div>
          </div>
          <div>
            <div style={{ fontSize: '36px', fontWeight: 'bold', marginBottom: '10px' }}>1000+</div>
            <div style={{ fontSize: '14px', opacity: 0.9 }}>Событий ежедневно</div>
          </div>
          <div>
            <div style={{ fontSize: '36px', fontWeight: 'bold', marginBottom: '10px' }}>24/7</div>
            <div style={{ fontSize: '14px', opacity: 0.9 }}>Поддержка клиентов</div>
          </div>
        </div>
      </div>
      
      {/* Sport Category Cards */}
      <div style={{
        marginTop: '30px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '20px',
        padding: '20px'
      }}>
        {/* Soccer Card */}
        <div style={{
          backgroundColor: '#1a1a2e',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>⚽</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>SOCCER</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>Russia. Premier Liga</p>
        </div>

        {/* Soccer Europa Card */}
        <div style={{
          backgroundColor: '#0f7938',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #0f7938 0%, #0d5c2c 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>⚽</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>SOCCER</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>UEFA Europa Conference League. 2nd qualifying round. First leg</p>
        </div>

        {/* Soccer Europa League Card */}
        <div style={{
          backgroundColor: '#f39c12',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #f39c12 0%, #d68910 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>⚽</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>SOCCER</h3>
          <p style={{ fontSize: '14px', opacity: 0.9 }}>UEFA Europa League. 2nd qualifying round. First leg</p>
        </div>

        {/* Tennis Card */}
        <div style={{
          backgroundColor: '#27ae60',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #27ae60 0%, #229954 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>🎾</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>TENNIS</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>ATP 250. Washington, USA. Hard</p>
        </div>

        {/* Tennis WTA Card */}
        <div style={{
          backgroundColor: '#3498db',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #3498db 0%, #2980b9 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>🎾</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>TENNIS</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>WTA 500. Washington, USA. Hard</p>
        </div>

        {/* Basketball Card */}
        <div style={{
          backgroundColor: '#e74c3c',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>🏀</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>BASKETBALL</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>Euroleague. Regular Season</p>
        </div>

        {/* Hockey Card */}
        <div style={{
          backgroundColor: '#34495e',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #34495e 0%, #2c3e50 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>🏒</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>HOCKEY</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>KHL. Regular Championship</p>
        </div>

        {/* Esports Card */}
        <div style={{
          backgroundColor: '#9b59b6',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>🎮</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>ESPORTS</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>CS:GO, Dota 2, League of Legends</p>
        </div>

        {/* Volleyball Card */}
        <div style={{
          backgroundColor: '#1abc9c',
          borderRadius: '12px',
          padding: '30px',
          color: 'white',
          textAlign: 'center',
          backgroundImage: 'linear-gradient(135deg, #1abc9c 0%, #16a085 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          cursor: 'pointer',
          transition: 'transform 0.3s ease',
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
          <div style={{ fontSize: '48px', marginBottom: '15px' }}>🏐</div>
          <h3 style={{ fontSize: '24px', marginBottom: '10px' }}>VOLLEYBALL</h3>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>Russian Super League</p>
        </div>
      </div>
    </div>
  );
};

export default LiveMatches;
