import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useBalance } from '../contexts/BalanceContext';

interface Bet {
  id: string;
  date: string;
  event: string;
  selection: string;
  odds: number;
  amount: number;
  potentialWin: number;
  status: 'pending' | 'won' | 'lost' | 'cashout';
  cashoutValue?: number;
  sport: string;
  league: string;
}

const MyBetsMobile: React.FC = () => {
  const { translate } = useLanguage();
  const { currentUser } = useAuth();
  const { formatBalance } = useBalance();
  
  const [activeTab, setActiveTab] = useState<string>('all');
  const [bets, setBets] = useState<Bet[]>([]);
  const [filteredBets, setFilteredBets] = useState<Bet[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [dateRange, setDateRange] = useState<string>('7days');
  
  // Mock data for bets
  const mockBets: Bet[] = [
    {
      id: 'BET-123456',
      date: '2023-06-15T14:30:00',
      event: 'Man Utd vs Liverpool',
      selection: '1',
      odds: 2.1,
      amount: 1000,
      potentialWin: 2100,
      status: 'won',
      sport: 'Football',
      league: 'Premier League'
    },
    {
      id: 'BET-123457',
      date: '2023-06-16T18:45:00',
      event: 'Barcelona vs Real Madrid',
      selection: 'X',
      odds: 3.2,
      amount: 500,
      potentialWin: 1600,
      status: 'lost',
      sport: 'Football',
      league: 'La Liga'
    },
    {
      id: 'BET-123458',
      date: '2023-06-17T20:00:00',
      event: 'Lakers vs Bulls',
      selection: '1',
      odds: 1.6,
      amount: 2000,
      potentialWin: 3200,
      status: 'pending',
      cashoutValue: 1800,
      sport: 'Basketball',
      league: 'NBA'
    },
    {
      id: 'BET-123459',
      date: '2023-06-18T15:30:00',
      event: 'Djokovic vs Nadal',
      selection: '2',
      odds: 2.1,
      amount: 1500,
      potentialWin: 3150,
      status: 'pending',
      cashoutValue: 1200,
      sport: 'Tennis',
      league: 'Wimbledon'
    },
    {
      id: 'BET-123460',
      date: '2023-06-19T19:15:00',
      event: 'Bayern vs Dortmund',
      selection: '1',
      odds: 1.8,
      amount: 1000,
      potentialWin: 1800,
      status: 'cashout',
      cashoutValue: 900,
      sport: 'Football',
      league: 'Bundesliga'
    },
  ];
  
  // Load bets on component mount
  useEffect(() => {
    const loadBets = async () => {
      setIsLoading(true);
      try {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        setBets(mockBets);
      } catch (error) {
        console.error('Error loading bets:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadBets();
  }, []);
  
  // Filter bets based on active tab and date range
  useEffect(() => {
    let filtered = [...bets];
    
    // Filter by status
    if (activeTab === 'won') {
      filtered = filtered.filter(bet => bet.status === 'won');
    } else if (activeTab === 'lost') {
      filtered = filtered.filter(bet => bet.status === 'lost');
    } else if (activeTab === 'pending') {
      filtered = filtered.filter(bet => bet.status === 'pending');
    } else if (activeTab === 'cashout') {
      filtered = filtered.filter(bet => bet.status === 'cashout');
    }
    
    // Filter by date range
    const now = new Date();
    let startDate: Date;
    
    if (dateRange === '24hours') {
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    } else if (dateRange === '7days') {
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (dateRange === '30days') {
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    } else {
      // 'all' - no date filtering
      startDate = new Date(0); // Beginning of time
    }
    
    filtered = filtered.filter(bet => new Date(bet.date) >= startDate);
    
    // Sort by date (newest first)
    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    setFilteredBets(filtered);
  }, [bets, activeTab, dateRange]);
  
  const handleCashout = async (betId: string, cashoutValue: number) => {
    // Simulate API call for cashout
    try {
      // Update the bet status locally
      const updatedBets = bets.map(bet => {
        if (bet.id === betId) {
          return { ...bet, status: 'cashout' as const, cashoutValue };
        }
        return bet;
      });
      
      setBets(updatedBets);
      
      // Show success message
      alert(translate('cashoutSuccessful'));
    } catch (error) {
      console.error('Error processing cashout:', error);
      alert(translate('cashoutFailed'));
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'won': return '#27ae60';
      case 'lost': return '#e74c3c';
      case 'pending': return '#f39c12';
      case 'cashout': return '#3498db';
      default: return '#7f8c8d';
    }
  };
  
  const getStatusText = (status: string) => {
    switch (status) {
      case 'won': return translate('won');
      case 'lost': return translate('lost');
      case 'pending': return translate('pending');
      case 'cashout': return translate('cashedOut');
      default: return status;
    }
  };
  
  const getSelectionText = (selection: string) => {
    switch (selection) {
      case '1': return translate('homeWin');
      case '2': return translate('awayWin');
      case 'X': return translate('draw');
      default: return selection;
    }
  };
  
  return (
    <div style={{ padding: '15px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '15px', fontSize: '20px' }}>
        {translate('myBets')}
      </h1>
      
      <div style={{ marginBottom: '15px' }}>
        <div style={{ display: 'flex', overflowX: 'auto', gap: '8px', marginBottom: '10px', paddingBottom: '5px' }}>
          <button 
            onClick={() => setActiveTab('all')}
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'all' ? '#3498db' : '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              fontSize: '14px'
            }}
          >
            {translate('all')}
          </button>
          <button 
            onClick={() => setActiveTab('pending')}
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'pending' ? '#3498db' : '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              fontSize: '14px'
            }}
          >
            {translate('pending')}
          </button>
          <button 
            onClick={() => setActiveTab('won')}
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'won' ? '#3498db' : '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              fontSize: '14px'
            }}
          >
            {translate('won')}
          </button>
          <button 
            onClick={() => setActiveTab('lost')}
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'lost' ? '#3498db' : '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              fontSize: '14px'
            }}
          >
            {translate('lost')}
          </button>
          <button 
            onClick={() => setActiveTab('cashout')}
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'cashout' ? '#3498db' : '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              fontSize: '14px'
            }}
          >
            {translate('cashedOut')}
          </button>
        </div>
        
        <div>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            style={{
              width: '100%',
              padding: '8px 12px',
              backgroundColor: '#34495e',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            <option value="24hours">{translate('last24Hours')}</option>
            <option value="7days">{translate('last7Days')}</option>
            <option value="30days">{translate('last30Days')}</option>
            <option value="all">{translate('allTime')}</option>
          </select>
        </div>
      </div>
      
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '30px' }}>
          <div style={{ fontSize: '16px' }}>{translate('loading')}...</div>
        </div>
      ) : filteredBets.length === 0 ? (
        <div style={{ 
          backgroundColor: '#2c3e50', 
          padding: '15px', 
          borderRadius: '8px', 
          textAlign: 'center',
          marginTop: '15px'
        }}>
          <div style={{ fontSize: '16px', marginBottom: '8px' }}>{translate('noBetsFound')}</div>
          <div style={{ color: '#7f8c8d', fontSize: '14px' }}>{translate('tryDifferentFilters')}</div>
        </div>
      ) : (
        <div>
          {filteredBets.map(bet => (
            <div 
              key={bet.id} 
              style={{
                backgroundColor: '#2c3e50',
                borderRadius: '8px',
                marginBottom: '12px',
                overflow: 'hidden'
              }}
            >
              <div style={{ 
                backgroundColor: '#34495e', 
                padding: '10px 15px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <div style={{ fontWeight: 'bold', fontSize: '14px' }}>{bet.event}</div>
                  <div style={{ color: '#bdc3c7', fontSize: '12px' }}>
                    {bet.sport} - {bet.league}
                  </div>
                </div>
                <div style={{ 
                  backgroundColor: getStatusColor(bet.status),
                  color: 'white',
                  padding: '3px 8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}>
                  {getStatusText(bet.status)}
                </div>
              </div>
              
              <div style={{ padding: '12px 15px' }}>
                <div style={{ 
                  display: 'grid', 
                  gridTemplateColumns: '1fr 1fr',
                  gap: '10px',
                  marginBottom: '10px',
                  fontSize: '13px'
                }}>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('betId')}
                    </div>
                    <div>{bet.id}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('date')}
                    </div>
                    <div>{formatDate(bet.date)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('selection')}
                    </div>
                    <div>{getSelectionText(bet.selection)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('odds')}
                    </div>
                    <div>{bet.odds.toFixed(2)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {translate('betAmount')}
                    </div>
                    <div>{formatBalance(bet.amount)}</div>
                  </div>
                  <div>
                    <div style={{ color: '#bdc3c7', marginBottom: '3px', fontSize: '12px' }}>
                      {bet.status === 'cashout' 
                        ? translate('cashoutAmount')
                        : bet.status === 'won'
                          ? translate('winAmount')
                          : translate('potentialWin')}
                    </div>
                    <div style={{ 
                      color: bet.status === 'won' || bet.status === 'cashout' ? '#2ecc71' : 'white',
                      fontWeight: bet.status === 'won' || bet.status === 'cashout' ? 'bold' : 'normal'
                    }}>
                      {bet.status === 'cashout' 
                        ? formatBalance(bet.cashoutValue || 0)
                        : bet.status === 'won'
                          ? formatBalance(bet.potentialWin)
                          : formatBalance(bet.potentialWin)}
                    </div>
                  </div>
                </div>
                
                {bet.status === 'pending' && bet.cashoutValue && (
                  <div style={{ textAlign: 'right' }}>
                    <button
                      onClick={() => handleCashout(bet.id, bet.cashoutValue || 0)}
                      style={{
                        padding: '8px 12px',
                        backgroundColor: '#e74c3c',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: 'bold',
                        fontSize: '14px'
                      }}
                    >
                      {translate('cashout')} {formatBalance(bet.cashoutValue)}
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyBetsMobile;