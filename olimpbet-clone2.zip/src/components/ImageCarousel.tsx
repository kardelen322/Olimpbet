import React, { useState, useEffect, CSSProperties } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

interface ImageCarouselProps {
  images: string[];
  autoSlideInterval?: number;
}

const ImageCarousel: React.FC<ImageCarouselProps> = ({ 
  images, 
  autoSlideInterval = 5000 
}) => {
  const { translate, isRTL } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);

  // Utility function for string formatting
  const formatString = (template: string, ...args: any[]) => {
    return template.replace(/{(\d+)}/g, (match, number) => {
      return typeof args[number] !== 'undefined' ? args[number] : match;
    });
  };

  // Auto slide functionality
  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, autoSlideInterval);

    return () => clearInterval(slideInterval);
  }, [images.length, autoSlideInterval]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const goToPrevious = () => {
    setCurrentIndex(currentIndex === 0 ? images.length - 1 : currentIndex - 1);
  };

  const goToNext = () => {
    setCurrentIndex(currentIndex === images.length - 1 ? 0 : currentIndex + 1);
  };

  // Styles
  const containerStyle: CSSProperties = {
    position: 'relative',
    width: '100%',
    height: '350px', // Reduced height to match reference
    overflow: 'hidden',
    borderRadius: '8px',
    margin: '0', // Remove extra margins
    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
    direction: isRTL ? 'rtl' : 'ltr'
  };

  const imageContainerStyle: CSSProperties = {
    display: 'flex',
    transition: 'transform 0.5s ease-in-out',
    transform: `translateX(-${currentIndex * 100}%)`,
    height: '100%'
  };

  const imageStyle: CSSProperties = {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    flexShrink: 0
  };

  const arrowButtonStyle = (side: 'left' | 'right'): CSSProperties => ({
    position: 'absolute',
    [side]: '20px',
    top: '50%',
    transform: 'translateY(-50%)',
    backgroundColor: 'rgba(0,0,0,0.5)',
    color: 'white',
    border: 'none',
    borderRadius: '50%',
    width: '50px',
    height: '50px',
    fontSize: '20px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.3s ease',
    zIndex: 2
  });

  const paginationContainerStyle: CSSProperties = {
    position: 'absolute',
    bottom: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    display: 'flex',
    gap: '10px',
    zIndex: 2
  };

  const paginationDotStyle = (isActive: boolean): CSSProperties => ({
    width: '12px',
    height: '12px',
    borderRadius: '50%',
    border: 'none',
    backgroundColor: isActive ? 'white' : 'rgba(255,255,255,0.5)',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
  });

  const progressBarContainerStyle: CSSProperties = {
    position: 'absolute',
    bottom: '0',
    left: '0',
    width: '100%',
    height: '4px',
    backgroundColor: 'rgba(255,255,255,0.3)',
    zIndex: 1
  };

  const progressBarStyle: CSSProperties = {
    height: '100%',
    backgroundColor: '#FFD700',
    width: `${((currentIndex + 1) / images.length) * 100}%`,
    transition: 'width 0.5s ease-in-out'
  };

  return (
    <div style={containerStyle}>
      {/* Image Container */}
      <div style={imageContainerStyle}>
        {images.map((image, index) => (
          <img
            key={`carousel-image-${index}`}
            src={image}
            alt={formatString(translate('promotionalBanner'), index + 1)}
            style={imageStyle}
            onError={(e) => {
              // Fallback for broken images
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
              target.parentElement!.style.backgroundColor = '#6B0C17';
              target.parentElement!.innerHTML = `
                <div style="
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  height: 100%;
                  color: white;
                  font-size: 16px;
                  font-weight: bold;
                ">
                  OLIMPBET
                </div>
              `;
            }}
          />
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={goToPrevious}
        style={arrowButtonStyle('left')}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.8)';
          e.currentTarget.style.transform = 'translateY(-50%) scale(1.1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.5)';
          e.currentTarget.style.transform = 'translateY(-50%) scale(1)';
        }}
      >
        ‹
      </button>

      <button
        onClick={goToNext}
        style={arrowButtonStyle('right')}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.8)';
          e.currentTarget.style.transform = 'translateY(-50%) scale(1.1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.5)';
          e.currentTarget.style.transform = 'translateY(-50%) scale(1)';
        }}
      >
        ›
      </button>

      {/* Pagination Dots */}
      <div style={paginationContainerStyle}>
        {images.map((_, index) => (
          <button
            key={`carousel-dot-${index}`}
            onClick={() => goToSlide(index)}
            style={paginationDotStyle(currentIndex === index)}
            onMouseEnter={(e) => {
              if (currentIndex !== index) {
                e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.8)';
              }
            }}
            onMouseLeave={(e) => {
              if (currentIndex !== index) {
                e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.5)';
              }
            }}
          />
        ))}
      </div>

      {/* Progress Bar */}
      <div style={progressBarContainerStyle}>
        <div style={progressBarStyle} />
      </div>
    </div>
  );
};

export default ImageCarousel;
