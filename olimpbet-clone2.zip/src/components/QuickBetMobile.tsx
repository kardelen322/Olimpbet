import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useBalance } from '../contexts/BalanceContext';

const QuickBetMobile: React.FC = () => {
  const { translate } = useLanguage();
  const { balance, formatBalance, withdrawFunds } = useBalance();
  
  const [betAmount, setBetAmount] = useState<string>('100');
  const [selectedSport, setSelectedSport] = useState<string>('football');
  const [selectedEvent, setSelectedEvent] = useState<string>('');
  const [selectedOutcome, setSelectedOutcome] = useState<string>('');
  const [odds, setOdds] = useState<number>(2.0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [betPlaced, setBetPlaced] = useState<boolean>(false);
  const [betResult, setBetResult] = useState<{id: string, status: string, potentialWin: number} | null>(null);
  
  // Mock data for sports events
  const sportsEvents = {
    football: [
      { id: 'f1', name: 'Man Utd vs Liverpool', outcomes: ['1', 'X', '2'], odds: [2.1, 3.2, 3.5] },
      { id: 'f2', name: 'Barcelona vs Real Madrid', outcomes: ['1', 'X', '2'], odds: [2.4, 3.1, 2.8] },
      { id: 'f3', name: 'Bayern vs Dortmund', outcomes: ['1', 'X', '2'], odds: [1.8, 3.5, 4.2] },
    ],
    basketball: [
      { id: 'b1', name: 'Lakers vs Bulls', outcomes: ['1', '2'], odds: [1.6, 2.3] },
      { id: 'b2', name: 'Celtics vs Heat', outcomes: ['1', '2'], odds: [1.9, 1.9] },
    ],
    tennis: [
      { id: 't1', name: 'Djokovic vs Nadal', outcomes: ['1', '2'], odds: [1.7, 2.1] },
      { id: 't2', name: 'Federer vs Murray', outcomes: ['1', '2'], odds: [1.5, 2.5] },
    ],
    hockey: [
      { id: 'h1', name: 'Maple Leafs vs Canadiens', outcomes: ['1', 'X', '2'], odds: [2.2, 3.3, 2.9] },
    ],
  };
  
  const handleSportChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const sport = e.target.value;
    setSelectedSport(sport);
    setSelectedEvent('');
    setSelectedOutcome('');
    setOdds(2.0);
  };
  
  const handleEventChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const eventId = e.target.value;
    setSelectedEvent(eventId);
    setSelectedOutcome('');
    setOdds(2.0);
  };
  
  const handleOutcomeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const outcomeIndex = parseInt(e.target.value);
    const event = sportsEvents[selectedSport as keyof typeof sportsEvents].find(ev => ev.id === selectedEvent);
    
    if (event) {
      setSelectedOutcome(event.outcomes[outcomeIndex]);
      setOdds(event.odds[outcomeIndex]);
    }
  };
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) {
      setBetAmount(value);
    }
  };
  
  const handleQuickAmounts = (amount: number) => {
    setBetAmount(amount.toString());
  };
  
  const handlePlaceBet = async () => {
    if (!selectedSport || !selectedEvent || !selectedOutcome || !betAmount) {
      alert(translate('pleaseCompleteAllFields'));
      return;
    }
    
    const amount = parseInt(betAmount);
    if (isNaN(amount) || amount <= 0) {
      alert(translate('invalidBetAmount'));
      return;
    }
    
    if (amount > balance) {
      alert(translate('insufficientFunds'));
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Simulate API call
      const success = await withdrawFunds(amount);
      
      if (success) {
        // Simulate bet placement delay
        setTimeout(() => {
          const betId = `QB-${Date.now().toString().slice(-6)}`;
          setBetResult({
            id: betId,
            status: 'accepted',
            potentialWin: amount * odds
          });
          setBetPlaced(true);
          setIsLoading(false);
        }, 1500);
      } else {
        alert(translate('betPlacementFailed'));
        setIsLoading(false);
      }
    } catch (error) {
      alert(translate('betPlacementFailed'));
      setIsLoading(false);
    }
  };
  
  const handleNewBet = () => {
    setBetPlaced(false);
    setBetResult(null);
    setBetAmount('100');
    setSelectedSport('football');
    setSelectedEvent('');
    setSelectedOutcome('');
    setOdds(2.0);
  };
  
  return (
    <div style={{ padding: '15px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '15px', fontSize: '20px' }}>
        {translate('quickBet')}
      </h1>
      
      {!betPlaced ? (
        <div style={{ backgroundColor: '#2c3e50', padding: '15px', borderRadius: '8px' }}>
          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('selectSport')}</label>
            <select
              value={selectedSport}
              onChange={handleSportChange}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white',
                fontSize: '14px'
              }}
            >
              <option value="football">{translate('football')}</option>
              <option value="basketball">{translate('basketball')}</option>
              <option value="tennis">{translate('tennis')}</option>
              <option value="hockey">{translate('hockey')}</option>
            </select>
          </div>
          
          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('selectEvent')}</label>
            <select
              value={selectedEvent}
              onChange={handleEventChange}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white',
                fontSize: '14px'
              }}
              disabled={!selectedSport}
            >
              <option value="">{translate('selectEvent')}</option>
              {selectedSport && sportsEvents[selectedSport as keyof typeof sportsEvents].map(event => (
                <option key={event.id} value={event.id}>{event.name}</option>
              ))}
            </select>
          </div>
          
          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('selectOutcome')}</label>
            <select
              value={selectedOutcome ? selectedEvent && sportsEvents[selectedSport as keyof typeof sportsEvents]
                .find(ev => ev.id === selectedEvent)?.outcomes.indexOf(selectedOutcome).toString() : ''}
              onChange={handleOutcomeChange}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white',
                fontSize: '14px'
              }}
              disabled={!selectedEvent}
            >
              <option value="">{translate('selectOutcome')}</option>
              {selectedEvent && sportsEvents[selectedSport as keyof typeof sportsEvents]
                .find(ev => ev.id === selectedEvent)?.outcomes.map((outcome, index) => (
                  <option key={index} value={index.toString()}>
                    {outcome === '1' ? translate('homeWin') : 
                     outcome === '2' ? translate('awayWin') : 
                     outcome === 'X' ? translate('draw') : outcome} 
                    ({sportsEvents[selectedSport as keyof typeof sportsEvents]
                      .find(ev => ev.id === selectedEvent)?.odds[index]})
                  </option>
                ))}
            </select>
          </div>
          
          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px' }}>{translate('betAmount')}</label>
            <input
              type="text"
              value={betAmount}
              onChange={handleAmountChange}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white',
                fontSize: '14px'
              }}
            />
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginTop: '8px' }}>
              <button 
                onClick={() => handleQuickAmounts(100)}
                style={{
                  padding: '8px',
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                100
              </button>
              <button 
                onClick={() => handleQuickAmounts(500)}
                style={{
                  padding: '8px',
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                500
              </button>
              <button 
                onClick={() => handleQuickAmounts(1000)}
                style={{
                  padding: '8px',
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                1000
              </button>
              <button 
                onClick={() => handleQuickAmounts(5000)}
                style={{
                  padding: '8px',
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                5000
              </button>
            </div>
          </div>
          
          <div style={{ 
            backgroundColor: '#34495e', 
            padding: '12px', 
            borderRadius: '4px', 
            marginBottom: '15px',
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: '14px'
          }}>
            <div>
              <div style={{ marginBottom: '3px' }}>{translate('odds')}</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold' }}>{odds.toFixed(2)}</div>
            </div>
            <div>
              <div style={{ marginBottom: '3px' }}>{translate('potentialWin')}</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#2ecc71' }}>
                {formatBalance(parseInt(betAmount || '0') * odds)}
              </div>
            </div>
          </div>
          
          <button
            onClick={handlePlaceBet}
            disabled={isLoading}
            style={{
              width: '100%',
              padding: '12px',
              backgroundColor: isLoading ? '#7f8c8d' : '#e74c3c',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: isLoading ? 'not-allowed' : 'pointer',
              fontSize: '16px',
              fontWeight: 'bold'
            }}
          >
            {isLoading ? translate('placingBet') : translate('placeBet')}
          </button>
        </div>
      ) : (
        <div style={{ backgroundColor: '#2c3e50', padding: '15px', borderRadius: '8px', textAlign: 'center' }}>
          <div style={{ 
            backgroundColor: '#27ae60', 
            color: 'white', 
            width: '60px', 
            height: '60px', 
            borderRadius: '50%', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            margin: '0 auto 15px',
            fontSize: '30px'
          }}>
            ✓
          </div>
          
          <h2 style={{ marginBottom: '15px', fontSize: '18px' }}>{translate('betAccepted')}</h2>
          
          <div style={{ 
            backgroundColor: '#34495e', 
            padding: '12px', 
            borderRadius: '4px', 
            marginBottom: '15px',
            textAlign: 'left',
            fontSize: '14px'
          }}>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('betId')}:</span>
              <span>{betResult?.id}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('event')}:</span>
              <span>{sportsEvents[selectedSport as keyof typeof sportsEvents].find(ev => ev.id === selectedEvent)?.name}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('selection')}:</span>
              <span>{selectedOutcome === '1' ? translate('homeWin') : 
                     selectedOutcome === '2' ? translate('awayWin') : 
                     selectedOutcome === 'X' ? translate('draw') : selectedOutcome}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('odds')}:</span>
              <span>{odds.toFixed(2)}</span>
            </div>
            <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('betAmount')}:</span>
              <span>{formatBalance(parseInt(betAmount))}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
              <span>{translate('potentialWin')}:</span>
              <span style={{ color: '#2ecc71' }}>{formatBalance(betResult?.potentialWin || 0)}</span>
            </div>
          </div>
          
          <button
            onClick={handleNewBet}
            style={{
              width: '100%',
              padding: '12px',
              backgroundColor: '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: 'bold'
            }}
          >
            {translate('placeBetAgain')}
          </button>
        </div>
      )}
    </div>
  );
};

export default QuickBetMobile;