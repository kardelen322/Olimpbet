import React, { useState, useEffect, ReactNode } from 'react';

interface ResponsiveWrapperProps {
  desktop: ReactNode;
  mobile: ReactNode;
  breakpoint?: number;
}

const ResponsiveWrapper: React.FC<ResponsiveWrapperProps> = ({ 
  desktop, 
  mobile, 
  breakpoint = 768 
}) => {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= breakpoint);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= breakpoint);
    };

    // Add resize listener
    window.addEventListener('resize', handleResize);

    // Initial check
    handleResize();

    // Cleanup listener
    return () => window.removeEventListener('resize', handleResize);
  }, [breakpoint]);

  return (
    <div 
      style={{ 
        width: '100%', 
        height: '100%', 
        transition: 'all 0.3s ease' 
      }}
    >
      {isMobile ? mobile : desktop}
    </div>
  );
};

export default ResponsiveWrapper; 
