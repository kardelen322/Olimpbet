import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import HeaderAuth from './HeaderAuth';
import PaymentButton from './PaymentButton';
import { TranslationKey } from '../types/language';
import { CSSProperties } from 'react';

// Type for navigation items
interface NavItem {
  path: string;
  translationKey: TranslationKey;
  activeColor?: string;
}

// Top navigation items for red bar
const TOP_NAV_ITEMS: NavItem[] = [
  { path: '/sports', translationKey: 'sports' },
  { path: '/live', translationKey: 'live' },
  { path: '/bets247', translationKey: 'bets247' },
  { path: '/esports', translationKey: 'esports' }
];

// Bottom navigation items for white bar
const BOTTOM_NAV_ITEMS: NavItem[] = [
  { path: '/bonuses', translationKey: 'bonusesAndPromotions' },
  { path: '/results-live', translationKey: 'resultsLive' },
  { path: '/results', translationKey: 'results' },
  { path: '/statistics', translationKey: 'statistics' },
  { path: '/terms', translationKey: 'termsConditions' },
  { path: '/support', translationKey: 'support' },
  { path: '/warning', translationKey: 'warningOfHarmfulEffect' },
  { path: '/faq', translationKey: 'faq' },
  { path: '/about', translationKey: 'aboutUs' }
];

// Fallback translation function
const defaultTranslate = (key: string): string => {
  return key
    .replace(/([A-Z])/g, ' $1')  // Insert space before capital letters
    .replace(/^./, (str: string) => str.toUpperCase())  // Capitalize first letter
    .trim();
};

const Header: React.FC = () => {
  const location = useLocation();
  
  // Directly use the language context hook
  const languageContext = useLanguage();
  
  // Use fallback values if context is not available
  const translate = languageContext?.translate || defaultTranslate;
  const isRTL = languageContext?.isRTL || false;

  // Reusable styles with explicit CSSProperties
  const styles = {
    topBar: {
      backgroundColor: '#6b0c17',
      color: 'white',
      padding: '0px',
      borderBottom: '1px solid #eee'
    } as CSSProperties,
    topBarContainer: {
      maxWidth: '1400px',
      margin: '0 auto',
      padding: '0px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: 48,
      position: 'relative'
    } as CSSProperties,
    logo: {
      display: 'flex', 
      alignItems: 'center', 
      gap: 8, 
      textDecoration: 'none'
    } as CSSProperties,
    logoImage: {
      width: 36,
      height: 36,
      backgroundColor: 'white',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden'
    } as CSSProperties,
    logoText: {
      fontSize: 20, 
      fontWeight: 'bold', 
      color: 'white', 
      margin: 0
    } as CSSProperties,
    navLink: (isActive: boolean): CSSProperties => ({
      color: 'white',
      fontWeight: 'bold',
      background: 'none',
      border: 'none',
      fontSize: 14,
      cursor: 'pointer',
      padding: '8px 12px',
      textDecoration: 'none',
      textTransform: 'uppercase' as const
    }),
    bottomBar: {
      backgroundColor: '#e5eaf3',
      color: '#374151',
      borderBottom: '1px solid #d1d5db'
    } as CSSProperties,
    bottomBarContainer: {
      maxWidth: '1400px',
      margin: '0 auto',
      padding: '0 20px',
      display: 'flex',
      alignItems: 'center',
      height: 38
    } as CSSProperties,
    bottomNavLink: (path: string, currentPath: string): CSSProperties => ({
      color: path === currentPath ? '#fff' : '#374151',
      backgroundColor: path === currentPath ? '#7b8ba3' : 'transparent',
      fontWeight: 'bold',
      textDecoration: 'none',
      padding: '8px 12px',
      borderRadius: 4,
      textTransform: 'uppercase' as const,
      fontSize: 13
    }),
    divider: {
      width: 1, 
      height: 20, 
      backgroundColor: 'rgba(55, 65, 81, 0.3)', 
      margin: '0 8px'
    } as CSSProperties,
    loginInput: {
      padding: '4px 8px',
      border: 'none',
      borderRadius: 3,
      fontSize: 12,
      width: 120
    } as CSSProperties,
    loginButton: {
      backgroundColor: '#FFD700',
      color: '#6b0c17',
      border: 'none',
      padding: '6px 12px',
      borderRadius: 3,
      fontSize: 12,
      cursor: 'pointer',
      fontWeight: 'bold'
    } as CSSProperties
  };

  return (
    <header 
      style={{ fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif' }} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Top Red Bar */}
      <div style={styles.topBar}>
        <div style={styles.topBarContainer}>
          {/* Left: Logo and Main Nav */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginLeft: '20px', flex: 1 }}>
            {/* Logo */}
            <Link to="/" style={styles.logo}>
              <div style={styles.logoImage}>
                <img
                  src="/app-banner-logo.png"
                  alt="OLIMPBET Logo"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'contain'
                  }}
                />
              </div>
              <h1 style={styles.logoText}>OLIMPBET</h1>
            </Link>

            {/* Top Navigation */}
            <nav style={{ display: 'flex', alignItems: 'center' }}>
              {TOP_NAV_ITEMS.map((item, index) => (
                <React.Fragment key={item.path}>
                  <Link 
                    to={item.path} 
                    style={styles.navLink(location.pathname === item.path)}
                  >
                    {translate(item.translationKey)}
                  </Link>
                  {index < TOP_NAV_ITEMS.length - 1 && (
                    <div style={styles.divider}></div>
                  )}
                </React.Fragment>
              ))}
            </nav>
          </div>

          {/* Middle: Empty space */}
          <div style={{ flex: 1 }}></div>

          {/* Right: Time, Login/Register */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 15, marginRight: '20px' }}>
            {/* Time */}
            <span style={{ color: 'white', fontSize: 13 }}>GMT +05</span>

            {/* Login/Register */}
            <HeaderAuth />
          </div>
        </div>
      </div>

      {/* Bottom White Bar */}
      <div style={styles.bottomBar}>
        <div style={styles.bottomBarContainer}>
          <nav style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
            {BOTTOM_NAV_ITEMS.map((item, index) => (
              <React.Fragment key={item.path}>
                <Link 
                  to={item.path} 
                  style={styles.bottomNavLink(item.path, location.pathname)}
                >
                  {translate(item.translationKey)}
                </Link>
                {index < BOTTOM_NAV_ITEMS.length - 1 && (
                  <div style={styles.divider}></div>
                )}
              </React.Fragment>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
