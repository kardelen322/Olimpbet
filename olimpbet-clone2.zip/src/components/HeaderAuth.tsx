import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import AuthModal from './AuthModal';
import UserSidebar from './UserSidebar';

const HeaderAuth: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authModalView, setAuthModalView] = useState<'login' | 'register'>('login');
  const [showUserSidebar, setShowUserSidebar] = useState(false);
  const [loginData, setLoginData] = useState({
    username: '',
    password: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLogin = () => {
    navigate('/login');
  };

  const handleRegister = () => {
    navigate('/register');
  };

  // This function will be used in future implementations
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const handleOpenAuthModal = (view: 'login' | 'register') => {
    setAuthModalView(view);
    setShowAuthModal(true);
  };

  const handleCloseAuthModal = () => {
    setShowAuthModal(false);
  };

  const handleLogout = () => {
    logout();
  };

  const toggleUserSidebar = () => {
    setShowUserSidebar(prev => !prev);
  };

  const closeUserSidebar = () => {
    setShowUserSidebar(false);
  };



  if (currentUser) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 15 }}>
        <span style={{ color: 'white', fontSize: 14 }}>
          {translate('welcome')}, {currentUser.username || currentUser.phone}!
        </span>

        {/* User Profile Picture */}
        <div 
          onClick={toggleUserSidebar}
          style={{
            width: '36px',
            height: '36px',
            backgroundColor: 'white',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden',
            cursor: 'pointer',
            border: '2px solid #FFD700'
          }}
        >
          <img
            src="/app-banner-logo.png"
            alt="User"
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain'
            }}
          />
        </div>

        {/* User Sidebar */}
        <UserSidebar isOpen={showUserSidebar} onClose={closeUserSidebar} />
      </div>
    );
  }

  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 15 }}>
        <input 
          type="text" 
          name="username"
          value={loginData.username}
          onChange={handleInputChange}
          placeholder={translate('loginPhone')} 
          style={{
            ...styles.loginInput,
            textAlign: isRTL ? 'right' : 'left'
          }} 
        />
        <input 
          type="password" 
          name="password"
          value={loginData.password}
          onChange={handleInputChange}
          placeholder={translate('password')} 
          style={{
            ...styles.loginInput,
            textAlign: isRTL ? 'right' : 'left'
          }} 
        />
        <button 
          onClick={handleLogin}
          style={styles.loginButton}
        >
          {'→'}
        </button>
        <button 
          onClick={handleRegister}
          style={{
            ...styles.loginButton,
            textTransform: 'uppercase' as const
          }}
        >
          {translate('joinNow')}
        </button>
      </div>

      {showAuthModal && (
        <AuthModal 
          isOpen={showAuthModal}
          initialView={authModalView} 
          onClose={handleCloseAuthModal} 
        />
      )}
    </>
  );
};

const styles = {
  loginInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    border: 'none',
    borderRadius: '4px',
    color: 'white',
    padding: '8px 12px',
    fontSize: '14px',
    width: '120px',
    '::placeholder': {
      color: 'rgba(255, 255, 255, 0.7)'
    }
  },
  loginButton: {
    backgroundColor: 'white',
    color: '#6b0c17',
    border: 'none',
    borderRadius: '4px',
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '40px',
  }
};

export default HeaderAuth;