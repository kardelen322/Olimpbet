import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';
import PaymentButton from './PaymentButton';

const Sports: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [selectedSport, setSelectedSport] = useState('football');
  const [selectedLeague, setSelectedLeague] = useState('all');

  const sportsCategories = [
    {
      id: 'football',
      name: 'Футбол',
      icon: '⚽',
      matches: 1160,
      color: '#22c55e',
      leagues: ['Премьер-лига России', 'Английская Премьер-лига', 'Лига Чемпионов', 'Лига Европы', 'Чемпионат мира']
    },
    {
      id: 'tennis',
      name: 'Теннис',
      icon: '🎾',
      matches: 321,
      color: '#f59e0b',
      leagues: ['ATP Tour', 'WTA Tour', 'Australian Open', 'Wimbledon', 'Roland Garros']
    },
    {
      id: 'basketball',
      name: 'Баскетбол',
      icon: '🏀',
      matches: 243,
      color: '#ef4444',
      leagues: ['НБА', 'Евролига', 'ВТБ', 'NCAA', 'ФИБА']
    },
    {
      id: 'hockey',
      name: 'Хоккей',
      icon: '🏒',
      matches: 146,
      color: '#3b82f6',
      leagues: ['КХЛ', 'НХЛ', 'Чемпионат мира', 'Олимпиада', 'МЧМ']
    },
    {
      id: 'volleyball',
      name: 'Волейбол',
      icon: '🏐',
      matches: 89,
      color: '#8b5cf6',
      leagues: ['Суперлига России', 'Лига наций', 'Чемпионат мира', 'Олимпиада', 'Лига чемпионов']
    },
    {
      id: 'esports',
      name: 'Киберспорт',
      icon: '🎮',
      matches: 567,
      color: '#06b6d4',
      leagues: ['CS:GO', 'Dota 2', 'League of Legends', 'Valorant', 'FIFA']
    }
  ];

  const popularMatches = [
    {
      id: 1,
      sport: 'football',
      league: 'Премьер-лига России',
      homeTeam: 'Зенит',
      awayTeam: 'Спартак',
      time: '15:30',
      date: '2024-01-16',
      odds: { home: '2.15', draw: '3.40', away: '2.85' },
      status: 'upcoming',
      viewers: 15420
    },
    {
      id: 2,
      sport: 'tennis',
      league: 'Australian Open',
      homeTeam: 'Новак Джокович',
      awayTeam: 'Рафаэль Надаль',  
      time: '09:00',
      date: '2024-01-16',
      odds: { player1: '1.65', player2: '2.20' },
      status: 'live',
      viewers: 8930
    },
    {
      id: 3,
      sport: 'basketball',
      league: 'НБА',
      homeTeam: 'Lakers',
      awayTeam: 'Warriors',
      time: '06:00',
      date: '2024-01-16',
      odds: { home: '1.95', spread: '1.90', away: '1.85' },
      status: 'upcoming',
      viewers: 12340
    },
    {
      id: 4,
      sport: 'hockey',
      league: 'КХЛ',
      homeTeam: 'ЦСКА',
      awayTeam: 'СКА',
      time: '19:30',
      date: '2024-01-16',
      odds: { home: '2.05', draw: '3.60', away: '2.45' },
      status: 'upcoming',
      viewers: 9876
    }
  ];

  const topLeagues = [
    { name: 'Премьер-лига России', matches: 156, icon: '🇷🇺' },
    { name: 'Английская Премьер-лига', matches: 243, icon: '🇬🇧' },
    { name: 'Ла Лига', matches: 198, icon: '🇪🇸' },
    { name: 'Серия А', matches: 176, icon: '🇮🇹' },
    { name: 'Бундеслига', matches: 165, icon: '🇩🇪' },
    { name: 'Лига 1', matches: 142, icon: '🇫🇷' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return '#ef4444';
      case 'upcoming': return '#22c55e';
      case 'finished': return '#6b7280';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'live': return '🔴 LIVE';
      case 'upcoming': return '🕐 Предстоящий';
      case 'finished': return '✅ Завершен';
      default: return status;
    }
  };

  const selectedSportData = sportsCategories.find(sport => sport.id === selectedSport);
  const filteredMatches = popularMatches.filter(match => match.sport === selectedSport);

  return (
    <div style={{
      display: 'flex',
      margin: '0 auto',
      padding: '20px 20px 20px 10px',
      gap: '20px'
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />

      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          background: 'linear-gradient(135deg, #6b0c17 0%, #8b1a1a 100%)',
          color: 'white'
        }}>
          <h1 style={{
            fontSize: '36px',
            fontWeight: 'bold',
            margin: '0 0 10px 0'
          }}>
            ⚽ СПОРТ
          </h1>
          <p style={{
            fontSize: '18px',
            margin: '0',
            opacity: 0.9
          }}>
            Ставки на все виды спорта с лучшими коэффициентами
          </p>
        </div>

        {/* Sports Categories Grid */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '25px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 20px 0',
            textAlign: 'center'
          }}>
            🏆 Категории спорта
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '15px',
            marginBottom: '20px'
          }}>
            {sportsCategories.map(sport => (
              <div
                key={sport.id}
                onClick={() => setSelectedSport(sport.id)}
                style={{
                  padding: '20px',
                  borderRadius: '12px',
                  border: selectedSport === sport.id ? `3px solid ${sport.color}` : '2px solid #e5e7eb',
                  backgroundColor: selectedSport === sport.id ? `${sport.color}15` : 'white',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '15px',
                  boxShadow: selectedSport === sport.id ? `0 8px 25px ${sport.color}40` : '0 2px 8px rgba(0,0,0,0.1)'
                }}
              >
                <div style={{
                  fontSize: '40px',
                  width: '60px',
                  height: '60px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  backgroundColor: sport.color,
                  borderRadius: '12px',
                  color: 'white'
                }}>
                  {sport.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <h3 style={{
                    fontSize: '18px',
                    fontWeight: 'bold',
                    color: selectedSport === sport.id ? sport.color : '#333',
                    margin: '0 0 5px 0'
                  }}>
                    {sport.name}
                  </h3>
                  <p style={{
                    fontSize: '14px',
                    color: '#666',
                    margin: '0'
                  }}>
                    {sport.matches} активных матчей
                  </p>
                </div>
                <div style={{
                  fontSize: '24px',
                  color: sport.color,
                  fontWeight: 'bold'
                }}>
                  →
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Sport Details */}
        {selectedSportData && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '25px',
            marginBottom: '20px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
            border: `2px solid ${selectedSportData.color}`
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '15px',
              marginBottom: '20px'
            }}>
              <div style={{
                fontSize: '40px',
                width: '60px',
                height: '60px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: selectedSportData.color,
                borderRadius: '12px',
                color: 'white'
              }}>
                {selectedSportData.icon}
              </div>
              <div>
                <h2 style={{
                  fontSize: '28px',
                  fontWeight: 'bold',
                  color: selectedSportData.color,
                  margin: '0 0 5px 0'
                }}>
                  {selectedSportData.name}
                </h2>
                <p style={{
                  fontSize: '16px',
                  color: '#666',
                  margin: '0'
                }}>
                  {selectedSportData.matches} активных матчей доступно для ставок
                </p>
              </div>
            </div>

            {/* Leagues Filter */}
            <div style={{ marginBottom: '20px' }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#333',
                margin: '0 0 15px 0'
              }}>
                🏆 Лиги и турниры:
              </h3>
              <div style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '10px'
              }}>
                <button
                  onClick={() => setSelectedLeague('all')}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '20px',
                    border: selectedLeague === 'all' ? `2px solid ${selectedSportData.color}` : '2px solid #e5e7eb',
                    backgroundColor: selectedLeague === 'all' ? selectedSportData.color : 'white',
                    color: selectedLeague === 'all' ? 'white' : '#333',
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: 'bold',
                    transition: 'all 0.3s ease'
                  }}
                >
                  Все лиги
                </button>
                {selectedSportData.leagues.map(league => (
                  <button
                    key={league}
                    onClick={() => setSelectedLeague(league)}
                    style={{
                      padding: '8px 16px',
                      borderRadius: '20px',
                      border: selectedLeague === league ? `2px solid ${selectedSportData.color}` : '2px solid #e5e7eb',
                      backgroundColor: selectedLeague === league ? selectedSportData.color : 'white',
                      color: selectedLeague === league ? 'white' : '#333',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: 'bold',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    {league}
                  </button>
                ))}
              </div>
            </div>

            {/* Matches for Selected Sport */}
            <div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#333',
                margin: '0 0 15px 0'
              }}>
                🔥 Популярные матчи:
              </h3>
              
              {filteredMatches.length > 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                  {filteredMatches.map(match => (
                    <div
                      key={match.id}
                      style={{
                        padding: '20px',
                        borderRadius: '12px',
                        border: '2px solid #f3f4f6',
                        backgroundColor: '#fafbfc',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '20px',
                        transition: 'all 0.3s ease'
                      }}
                    >
                      <div style={{ flex: 1 }}>
                        <div style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          marginBottom: '8px'
                        }}>
                          <span style={{
                            color: getStatusColor(match.status),
                            fontSize: '12px',
                            fontWeight: 'bold'
                          }}>
                            {getStatusText(match.status)}
                          </span>
                          <span style={{ fontSize: '12px', color: '#666' }}>
                            {match.league}
                          </span>
                        </div>
                        
                        <div style={{
                          fontSize: '16px',
                          fontWeight: 'bold',
                          color: '#333',
                          marginBottom: '5px'
                        }}>
                          {match.homeTeam} vs {match.awayTeam}
                        </div>
                        
                        <div style={{
                          fontSize: '13px',
                          color: '#666',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '15px'
                        }}>
                          <span>📅 {match.date}</span>
                          <span>🕐 {match.time}</span>
                          <span>👥 {match.viewers.toLocaleString()} зрителей</span>
                        </div>
                      </div>

                      <div style={{
                        display: 'flex',
                        gap: '10px',
                        alignItems: 'center'
                      }}>
                        {match.sport === 'tennis' ? (
                          <>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#22c55e',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              {match.odds.player1}
                            </button>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#ef4444',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              {match.odds.player2}
                            </button>
                          </>
                        ) : match.sport === 'basketball' ? (
                          <>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#22c55e',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              П1 {match.odds.home}
                            </button>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#f59e0b',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              Ф {match.odds.spread}
                            </button>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#ef4444',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              П2 {match.odds.away}
                            </button>
                          </>
                        ) : (
                          <>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#22c55e',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              1 {match.odds.home}
                            </button>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#f59e0b',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              X {match.odds.draw}
                            </button>
                            <button style={{
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: 'none',
                              backgroundColor: '#ef4444',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '13px',
                              fontWeight: 'bold'
                            }}>
                              2 {match.odds.away}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{
                  textAlign: 'center',
                  padding: '40px',
                  color: '#666',
                  fontSize: '16px'
                }}>
                  Нет доступных матчей для данного вида спорта
                </div>
              )}
            </div>
          </div>
        )}

        {/* Top Leagues */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '25px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 20px 0',
            textAlign: 'center'
          }}>
            🌟 Топ лиги
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '15px'
          }}>
            {topLeagues.map((league, index) => (
              <div
                key={index}
                style={{
                  padding: '15px',
                  borderRadius: '10px',
                  border: '2px solid #f3f4f6',
                  backgroundColor: '#fafbfc',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
              >
                <div style={{ fontSize: '24px' }}>
                  {league.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <h3 style={{
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: '#333',
                    margin: '0 0 5px 0'
                  }}>
                    {league.name}
                  </h3>
                  <p style={{
                    fontSize: '12px',
                    color: '#666',
                    margin: '0'
                  }}>
                    {league.matches} матчей
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Payment Section */}
        <div style={{
          background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
          borderRadius: '16px',
          padding: '35px',
          marginBottom: '20px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
          textAlign: 'center',
          border: '3px solid #6b0c17',
          position: 'relative',
          overflow: 'hidden'
        }}>
          {/* Background decoration */}
          <div style={{
            position: 'absolute',
            top: '-50%',
            left: '-50%',
            width: '200%',
            height: '200%',
            background: 'radial-gradient(circle, rgba(107, 12, 23, 0.05) 0%, transparent 70%)',
            pointerEvents: 'none'
          }}></div>
          
          <h2 style={{
            fontSize: '28px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 18px 0',
            textShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
            position: 'relative',
            zIndex: 1
          }}>
            💳 Пополнить счет для ставок
          </h2>
          <p style={{
            fontSize: '16px',
            color: '#555',
            margin: '0 0 30px 0',
            lineHeight: '1.5',
            position: 'relative',
            zIndex: 1
          }}>
            Быстрое и безопасное пополнение через Kaspi.kz • Начните делать ставки прямо сейчас!
          </p>
          <PaymentButton 
            variant="sports"
            style={{
              background: 'linear-gradient(135deg, #6b0c17 0%, #8b1a1a 100%)',
              color: 'white',
              border: '3px solid #6b0c17',
              padding: '16px 40px',
              borderRadius: '50px',
              fontSize: '18px',
              fontWeight: 'bold',
              cursor: 'pointer',
              textTransform: 'uppercase',
              boxShadow: '0 8px 25px rgba(107, 12, 23, 0.4)',
              transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
              transform: 'scale(1)',
              letterSpacing: '1px',
              position: 'relative',
              zIndex: 1,
              minWidth: '220px',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'scale(1.08) translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 12px 35px rgba(107, 12, 23, 0.6)';
              e.currentTarget.style.background = 'linear-gradient(135deg, #8b1a1a 0%, #6b0c17 100%)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'scale(1) translateY(0)';
              e.currentTarget.style.boxShadow = '0 8px 25px rgba(107, 12, 23, 0.4)';
              e.currentTarget.style.background = 'linear-gradient(135deg, #6b0c17 0%, #8b1a1a 100%)';
            }}
          />
          <div style={{
            marginTop: '20px',
            fontSize: '13px',
            color: '#666',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: '15px',
            flexWrap: 'wrap',
            position: 'relative',
            zIndex: 1
          }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>⚡ Мгновенно</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>🔒 Безопасно</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>🎯 Без комиссий</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sports;