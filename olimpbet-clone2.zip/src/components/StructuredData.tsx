import React from 'react';

interface StructuredDataProps {
  type?: string;
  customData?: Record<string, any>;
}

const StructuredData: React.FC<StructuredDataProps> = ({ type, customData }) => {
  // We'll use location in future implementations if needed
  // Commented out to avoid ESLint warning
  // const location = useLocation();
  // const currentUrl = `https://olimpbet.com${location.pathname}`;
  
  // Default organization data
  const organizationData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    'name': 'OLIMPBET',
    'url': 'https://olimpbet.com',
    'logo': {
      '@type': 'ImageObject',
      'url': 'https://olimpbet.com/social-share.svg',
      'width': '1200',
       'height': '630'
    },
    'sameAs': [
      'https://facebook.com/olimpbet',
      'https://twitter.com/olimpbet',
      'https://instagram.com/olimpbet'
    ],
    'description': 'OLIMPBET offers sports betting, live betting, casino games and more. Join now for the best odds and bonuses!'
  };
  
  // Website data
  const websiteData = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    'url': 'https://olimpbet.com',
    'name': 'OLIMPBET - Sports Betting & Casino',
    'description': 'OLIMPBET offers sports betting, live betting, casino games and more. Join now for the best odds and bonuses!',
    'potentialAction': {
      '@type': 'SearchAction',
      'target': 'https://olimpbet.com/search?q={search_term_string}',
      'query-input': 'required name=search_term_string'
    }
  };
  
  // Sports event data template
  const sportsEventData = {
    '@context': 'https://schema.org',
    '@type': 'SportsEvent',
    'name': 'Sports Betting Events',
    'url': 'https://olimpbet.com/sports',
    'description': 'Bet on your favorite sports with OLIMPBET. We offer competitive odds on football, basketball, tennis and more!',
    'location': {
      '@type': 'VirtualLocation',
      'name': 'OLIMPBET Online Platform'
    },
    'offers': {
      '@type': 'Offer',
      'url': 'https://olimpbet.com/sports',
      'availability': 'https://schema.org/InStock',
      'price': '0',
      'priceCurrency': 'USD'
    }
  };
  
  // Determine which structured data to use based on type prop or current path
  let structuredData;
  
  if (type === 'organization' || customData?.['@type'] === 'Organization') {
    structuredData = { ...organizationData, ...customData };
  } else if (type === 'website' || customData?.['@type'] === 'WebSite') {
    structuredData = { ...websiteData, ...customData };
  } else if (type === 'sportsEvent' || customData?.['@type'] === 'SportsEvent') {
    structuredData = { ...sportsEventData, ...customData };
  } else if (customData) {
    // Use custom data if provided
    structuredData = customData;
  } else {
    // Default to website data
    structuredData = websiteData;
  }
  
  return (
    <script 
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  );
};

export default StructuredData;