import React, { useState, CSSProperties } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

// Type definitions for FAQ sections and questions
interface FAQQuestion {
  id?: number;
  question: string;
  answer?: string;
}

interface FAQSection {
  id: string;
  icon: string;
  title: string;
  questions: string[];
}

const FAQ: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const toggleSection = (sectionId: string) => {
    // Always close all sections first, then open the clicked one if it wasn't already open
    setExpandedSection(expandedSection === sectionId ? null : sectionId);
  };

  const faqSections: FAQSection[] = [
    {
      id: 'general',
      icon: '❓',
      title: translate('allQuestions'),
      questions: [
        translate('howToChangePasswordDetail'),
        translate('howToWithdraw'),
        translate('whatIsResult')
      ]
    },
    {
      id: 'account',
      icon: '👤',
      title: translate('accountTitle'),
      questions: [
        translate('howToChangePassword'),
        translate('howToWithdrawFunds'),
        translate('howToChangePasswordDetail')
      ]
    },
    {
      id: 'deposits',
      icon: '💰',
      title: translate('depositsWithdrawalsTitle'),
      questions: [
        translate('howToDeposit'),
        translate('howToWithdrawFunds'),
        translate('directDepositWithdrawal')
      ]
    },
    {
      id: 'payments',
      icon: '💳',
      title: translate('paymentMethodsTitle'),
      questions: [
        translate('depositMethods'),
        translate('withdrawalMethods'),
        translate('directWithdrawal')
      ]
    },
    {
      id: 'results',
      icon: '📊',
      title: translate('mainResultsTitle'),
      questions: [
        translate('whatIsResult'),
        translate('whatIsSystem'),
        translate('whatIsExpress')
      ]
    },
    {
      id: 'safety',
      icon: '🔒',
      title: translate('userSafetyTitle'),
      questions: [
        translate('personalInfoSecurity'),
        translate('whatIsAgeVerification'),
        translate('whyNeedDocuments')
      ]
    }
  ];

  // Reusable styles
  const styles = {
    container: {
      display: 'flex',
      margin: '0 auto',
      padding: '20px 20px 20px 10px',
      gap: '20px'
    } as CSSProperties,

    content: {
      flex: 1,
      backgroundColor: '#f8f9fa',
      fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
    } as CSSProperties,

    header: {
      backgroundColor: 'white',
      padding: '20px',
      borderRadius: '8px',
      marginBottom: '20px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
    } as CSSProperties,

    headerTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: '#6b0c17',
      margin: '0',
      textAlign: 'center'
    } as CSSProperties,

    faqGrid: {
      display: 'flex',
      flexDirection: 'column',
      gap: '20px',
      padding: '0'
    } as CSSProperties,

    rowContainer: {
      display: 'flex',
      gap: '20px'
    } as CSSProperties
  };

  const renderFAQSection = (section: FAQSection) => {
    const isExpanded = expandedSection === section.id;

    return (
      <div
        key={`faq-section-${section.id}`}
        style={{
          flex: 1,
          backgroundColor: 'white',
          border: isExpanded ? '2px solid #6b0c17' : '1px solid #e5e7eb',
          borderRadius: '12px',
          overflow: 'hidden',
          boxShadow: isExpanded 
            ? '0 4px 12px rgba(107, 12, 23, 0.2)' 
            : '0 2px 4px rgba(0, 0, 0, 0.1)',
          transition: 'all 0.3s ease'
        }}
      >
        {/* Section Header */}
        <div
          onClick={() => toggleSection(section.id)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '20px',
            backgroundColor: isExpanded ? '#f1f5f9' : '#f8f9fa',
            cursor: 'pointer',
            transition: 'background-color 0.3s',
            borderBottom: isExpanded ? '1px solid #e5e7eb' : 'none'
          }}
          onMouseEnter={(e) => {
            if (!isExpanded) {
              e.currentTarget.style.backgroundColor = '#f1f5f9';
            }
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = isExpanded ? '#f1f5f9' : '#f8f9fa';
          }}
        >
          {/* Section Icon */}
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            backgroundColor: '#6b0c17',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '18px',
            flexShrink: 0
          }}>
            {section.icon}
          </div>

          {/* Section Title */}
          <h3 style={{
            fontSize: '16px',
            fontWeight: 'bold',
            color: '#333',
            margin: '0',
            flex: 1
          }}>
            {section.title}
          </h3>

          {/* Expand/Collapse Indicator */}
          <div style={{
            fontSize: '12px',
            color: '#6b7280',
            transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)',
            transition: 'transform 0.3s'
          }}>
            ▼
          </div>
        </div>

        {/* Questions List */}
        {isExpanded && (
          <div style={{
            padding: '20px',
            animation: 'slideDown 0.3s ease-out',
            backgroundColor: '#ffffff'
          }}>
            {section.questions.map((question, index) => (
              <div
                key={index}
                style={{
                  padding: '12px 0',
                  borderBottom: index < section.questions.length - 1 
                    ? '1px solid #f1f5f9' 
                    : 'none',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#f8f9fa';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <div style={{
                  fontSize: '14px',
                  color: '#374151',
                  lineHeight: '1.5'
                }}>
                  {question}
                </div>
              </div>
            ))}

            {/* All Questions Button */}
            <div style={{ 
              marginTop: '20px', 
              textAlign: 'center' 
            }}>
              <button 
                style={{
                  backgroundColor: '#6b0c17',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '6px',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  transition: 'background-color 0.3s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#7f1d1d';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#6b0c17';
                }}
              >
                {translate('allQuestions')}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      <style>
        {`
          @keyframes slideDown {
            from {
              opacity: 0;
              max-height: 0;
              transform: translateY(-10px);
            }
            to {
              opacity: 1;
              max-height: 500px;
              transform: translateY(0);
            }
          }
        `}
      </style>

      <div 
        style={styles.container} 
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <Sidebar />

        <div style={styles.content}>
          {/* Page Header */}
          <div style={styles.header}>
            <h1 style={styles.headerTitle}>
              {translate('faqTitle')}
            </h1>
          </div>

          {/* FAQ Sections Grid */}
          <div style={styles.faqGrid}>
            {/* First Row */}
            <div style={styles.rowContainer}>
              {faqSections
                .filter(section => ['general', 'account'].includes(section.id))
                .map(renderFAQSection)
              }
            </div>

            {/* Second Row */}
            <div style={styles.rowContainer}>
              {faqSections
                .filter(section => ['deposits', 'payments'].includes(section.id))
                .map(renderFAQSection)
              }
            </div>

            {/* Third Row */}
            <div style={styles.rowContainer}>
              {faqSections
                .filter(section => ['results', 'safety'].includes(section.id))
                .map(renderFAQSection)
              }
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FAQ; 
