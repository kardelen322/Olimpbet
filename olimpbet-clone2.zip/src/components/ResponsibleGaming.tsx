import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const ResponsibleGaming: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [showWarning, setShowWarning] = useState(true);

  const warningSign = [
    'Вы тратите на игру больше времени и денег, чем планировали',
    'Игра мешает работе, учебе или отношениям с близкими',
    'Вы занимаете деньги или продаете вещи для продолжения игры',
    'Вы лжете о размере ставок или частоте игры',
    'Вы играете, чтобы забыть о проблемах или плохом настроении',
    'Вы чувствуете беспокойство, когда не можете играть',
    'Неудачные попытки сократить или прекратить игру',
    'Вы пытаетесь отыграться после проигрышей'
  ];

  const helpResources = [
    {
      name: 'Анонимные игроки',
      phone: '8-800-200-01-04',
      website: 'https://gamblers-anonymous.ru',
      description: 'Группы взаимопомощи для людей с игровой зависимостью',
      available: '24/7'
    },
    {
      name: 'Центр лечения зависимостей',
      phone: '8-495-123-45-67',
      website: 'https://addiction-center.ru',
      description: 'Профессиональная помощь психологов и врачей',
      available: 'Пн-Пт 9:00-18:00'
    },
    {
      name: 'Телефон доверия',
      phone: '8-800-100-01-91',
      website: 'https://doverie.org',
      description: 'Бесплатная психологическая помощь',
      available: '24/7'
    }
  ];

  const selfControlTools = [
    {
      icon: '💰',
      title: 'Лимиты депозитов',
      description: 'Установите максимальную сумму, которую можете внести за день/неделю/месяц',
      action: 'Установить лимит'
    },
    {
      icon: '🎯',
      title: 'Лимиты ставок',
      description: 'Ограничьте размер отдельных ставок и общую сумму ставок за период',
      action: 'Установить лимит'
    },
    {
      icon: '⏰',
      title: 'Лимиты времени',
      description: 'Установите максимальное время, которое можете провести на сайте',
      action: 'Установить лимит'
    },
    {
      icon: '🚫',
      title: 'Самоисключение',
      description: 'Заблокируйте доступ к аккаунту на определенный период времени',
      action: 'Заблокировать аккаунт'
    }
  ];

  const gamblingSafely = [
    {
      icon: '💡',
      title: 'Играйте для развлечения',
      description: 'Ставки должны быть развлечением, а не способом заработка'
    },
    {
      icon: '📊',
      title: 'Установите бюджет',
      description: 'Никогда не ставьте больше, чем можете позволить себе проиграть'
    },
    {
      icon: '⏱️',
      title: 'Контролируйте время',
      description: 'Делайте регулярные перерывы, не играйте слишком долго'
    },
    {
      icon: '🚫',
      title: 'Не играйте в долг',
      description: 'Никогда не занимайте деньги для игры и не играйте в кредит'
    },
    {
      icon: '🧠',
      title: 'Играйте трезво',
      description: 'Не играйте под воздействием алкоголя или когда расстроены'
    },
    {
      icon: '❌',
      title: 'Не отыгрывайтесь',
      description: 'Проигрыш - это часть игры, не пытайтесь его отыграть'
    }
  ];

  return (
    <div style={{ 
      display: 'flex', 
      margin: '0 auto', 
      padding: '20px 20px 20px 10px',
      gap: '20px' 
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />
      
      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Warning Modal */}
        {showWarning && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000
          }}>
            <div style={{
              backgroundColor: 'white',
              borderRadius: '16px',
              padding: '40px',
              maxWidth: '500px',
              margin: '20px',
              textAlign: 'center',
              border: '4px solid #ef4444'
            }}>
              <div style={{
                fontSize: '48px',
                marginBottom: '20px'
              }}>
                ⚠️
              </div>
              <h2 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#ef4444',
                marginBottom: '20px'
              }}>
                ПРЕДУПРЕЖДЕНИЕ О ВРЕДНОМ ВОЗДЕЙСТВИИ!
              </h2>
              <p style={{
                fontSize: '16px',
                color: '#333',
                lineHeight: 1.6,
                marginBottom: '30px'
              }}>
                Азартные игры могут вызывать зависимость и наносить вред вашему здоровью, 
                отношениям и финансовому положению. Играйте ответственно!
              </p>
              <div style={{
                display: 'flex',
                gap: '15px',
                justifyContent: 'center'
              }}>
                <button
                  onClick={() => setShowWarning(false)}
                  style={{
                    backgroundColor: '#ef4444',
                    color: 'white',
                    border: 'none',
                    padding: '12px 25px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}
                >
                  Я понимаю риски
                </button>
                <button
                  onClick={() => window.history.back()}
                  style={{
                    backgroundColor: 'transparent',
                    color: '#ef4444',
                    border: '2px solid #ef4444',
                    padding: '12px 25px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}
                >
                  Покинуть сайт
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '40px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
          color: 'white'
        }}>
          <div style={{
            fontSize: '48px',
            marginBottom: '20px'
          }}>
            🛡️
          </div>
          <h1 style={{
            fontSize: '32px',
            fontWeight: 'bold',
            margin: '0 0 15px 0'
          }}>
            ОТВЕТСТВЕННАЯ ИГРА
          </h1>
          <p style={{
            fontSize: '18px',
            margin: '0',
            opacity: 0.9,
            lineHeight: 1.6
          }}>
            Ваше благополучие - наш приоритет. Играйте безопасно и контролируйте свои расходы.
          </p>
        </div>

        {/* Age Restriction */}
        <div style={{
          backgroundColor: '#fef2f2',
          border: '2px solid #fecaca',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '30px',
          display: 'flex',
          alignItems: 'center',
          gap: '15px'
        }}>
          <div style={{
            fontSize: '36px',
            minWidth: '50px'
          }}>
            🔞
          </div>
          <div>
            <h3 style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: '#dc2626',
              margin: '0 0 8px 0'
            }}>
              Возрастные ограничения
            </h3>
            <p style={{
              fontSize: '14px',
              color: '#991b1b',
              margin: '0',
              lineHeight: 1.5
            }}>
              Участие в азартных играх запрещено лицам младше 18 лет. 
              Мы проверяем возраст всех пользователей при регистрации.
            </p>
          </div>
        </div>

        {/* Warning Signs */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '30px',
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#dc2626',
            marginBottom: '20px',
            textAlign: 'center',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '10px'
          }}>
            <span style={{ fontSize: '28px' }}>⚠️</span>
            Признаки игровой зависимости
          </h2>
          <p style={{
            fontSize: '16px',
            color: '#666',
            textAlign: 'center',
            marginBottom: '25px'
          }}>
            Если вы узнали себя в трех или более пунктах, обратитесь за помощью
          </p>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
            gap: '15px'
          }}>
            {warningSign.map((sign, index) => (
              <div
                key={index}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '12px',
                  padding: '15px',
                  backgroundColor: '#fef2f2',
                  borderRadius: '10px',
                  border: '1px solid #fecaca'
                }}
              >
                <div style={{
                  minWidth: '24px',
                  height: '24px',
                  borderRadius: '50%',
                  backgroundColor: '#dc2626',
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  marginTop: '2px'
                }}>
                  {index + 1}
                </div>
                <span style={{
                  fontSize: '14px',
                  color: '#991b1b',
                  lineHeight: 1.5
                }}>
                  {sign}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Self-Control Tools */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '30px',
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '20px',
            textAlign: 'center'
          }}>
            🔧 Инструменты самоконтроля
          </h2>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '20px'
          }}>
            {selfControlTools.map((tool, index) => (
              <div
                key={index}
                style={{
                  padding: '25px',
                  border: '2px solid #e5e7eb',
                  borderRadius: '12px',
                  textAlign: 'center',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = '#6b0c17';
                  e.currentTarget.style.backgroundColor = '#fef7f7';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = '#e5e7eb';
                  e.currentTarget.style.backgroundColor = 'white';
                }}
              >
                <div style={{
                  fontSize: '40px',
                  marginBottom: '15px'
                }}>
                  {tool.icon}
                </div>
                <h3 style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#333',
                  marginBottom: '10px'
                }}>
                  {tool.title}
                </h3>
                <p style={{
                  fontSize: '14px',
                  color: '#666',
                  lineHeight: 1.5,
                  marginBottom: '20px'
                }}>
                  {tool.description}
                </p>
                <button
                  style={{
                    backgroundColor: '#6b0c17',
                    color: 'white',
                    border: 'none',
                    padding: '10px 20px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    transition: 'background-color 0.3s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#7f1d1d';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#6b0c17';
                  }}
                >
                  {tool.action}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Safe Gaming Tips */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '30px',
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '20px',
            textAlign: 'center'
          }}>
            ✅ Как играть безопасно
          </h2>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '20px'
          }}>
            {gamblingSafely.map((tip, index) => (
              <div
                key={index}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '15px',
                  padding: '20px',
                  backgroundColor: '#f0f9ff',
                  borderRadius: '10px',
                  border: '1px solid #bae6fd'
                }}
              >
                <div style={{
                  fontSize: '28px',
                  minWidth: '35px'
                }}>
                  {tip.icon}
                </div>
                <div>
                  <h3 style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    color: '#0369a1',
                    marginBottom: '8px'
                  }}>
                    {tip.title}
                  </h3>
                  <p style={{
                    fontSize: '14px',
                    color: '#0284c7',
                    lineHeight: 1.5,
                    margin: '0'
                  }}>
                    {tip.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Help Resources */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '30px',
          marginBottom: '30px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '20px',
            textAlign: 'center'
          }}>
            🆘 Получить помощь
          </h2>
          <p style={{
            fontSize: '16px',
            color: '#666',
            textAlign: 'center',
            marginBottom: '25px'
          }}>
            Если вы или ваши близкие столкнулись с проблемой игровой зависимости, обратитесь за помощью
          </p>
          
          {helpResources.map((resource, index) => (
            <div
              key={index}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '20px',
                padding: '20px',
                marginBottom: '15px',
                backgroundColor: '#f8f9fa',
                borderRadius: '10px',
                border: '1px solid #e5e7eb'
              }}
            >
              <div style={{
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                backgroundColor: '#22c55e',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '24px',
                color: 'white'
              }}>
                📞
              </div>
              
              <div style={{ flex: 1 }}>
                <h3 style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#333',
                  marginBottom: '5px'
                }}>
                  {resource.name}
                </h3>
                <p style={{
                  fontSize: '14px',
                  color: '#666',
                  marginBottom: '8px'
                }}>
                  {resource.description}
                </p>
                <div style={{
                  display: 'flex',
                  gap: '15px',
                  fontSize: '14px'
                }}>
                  <span style={{ color: '#22c55e', fontWeight: 'bold' }}>
                    📞 {resource.phone}
                  </span>
                  <span style={{ color: '#666' }}>
                    🕒 {resource.available}
                  </span>
                </div>
              </div>
              
              <button
                onClick={() => window.open(resource.website, '_blank')}
                style={{
                  backgroundColor: '#22c55e',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
              >
                Перейти на сайт
              </button>
            </div>
          ))}
        </div>

        {/* Footer Message */}
        <div style={{
          backgroundColor: '#6b0c17',
          color: 'white',
          padding: '30px',
          borderRadius: '12px',
          textAlign: 'center'
        }}>
          <div style={{
            fontSize: '32px',
            marginBottom: '15px'
          }}>
            💙
          </div>
          <h3 style={{
            fontSize: '20px',
            fontWeight: 'bold',
            marginBottom: '15px'
          }}>
            Помните: обратиться за помощью - это признак силы, а не слабости
          </h3>
          <p style={{
            fontSize: '16px',
            opacity: 0.9,
            lineHeight: 1.6,
            marginBottom: '20px'
          }}>
            Если вы чувствуете, что теряете контроль над игрой, не стесняйтесь обращаться за поддержкой. 
            Многие люди успешно преодолевают игровую зависимость с помощью специалистов.
          </p>
          
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '15px'
          }}>
            <button
              onClick={() => setShowWarning(true)}
              style={{
                backgroundColor: 'white',
                color: '#6b0c17',
                border: 'none',
                padding: '12px 25px',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}
            >
              Показать предупреждение
            </button>
            <button
              onClick={() => window.open('tel:88002000104')}
              style={{
                backgroundColor: 'transparent',
                color: 'white',
                border: '2px solid white',
                padding: '12px 25px',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}
            >
              Горячая линия
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResponsibleGaming; 