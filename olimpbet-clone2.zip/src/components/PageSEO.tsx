import React from 'react';
import { useLocation } from 'react-router-dom';
import SEO from './SEO';

const PageSEO: React.FC = () => {
  const location = useLocation();
  const path = location.pathname;
  
  // Define SEO metadata for each page
  const pageSEO = {
    '/': {
      title: 'OLIMPBET - Sports Betting & Casino',
      description: 'OLIMPBET offers sports betting, live betting, casino games and more. Join now for the best odds and bonuses!',
      keywords: 'sports betting, online betting, casino, olimpbet, betting odds, live betting'
    },
    '/sports': {
      title: 'Sports Betting | OLIMPBET',
      description: 'Bet on your favorite sports with OLIMPBET. We offer competitive odds on football, basketball, tennis and more!',
      keywords: 'sports betting, football betting, basketball betting, tennis betting, olimpbet sports'
    },
    '/live': {
      title: 'Live Betting | OLIMPBET',
      description: 'Experience the thrill of live betting with OLIMPBET. Place bets on ongoing matches with real-time odds!',
      keywords: 'live betting, in-play betting, real-time odds, live sports betting'
    },
    '/casino': {
      title: 'Online Casino | OLIMPBET',
      description: 'Play the best casino games at OLIMPBET. Enjoy slots, table games, and live dealer games with big bonuses!',
      keywords: 'online casino, casino games, slots, table games, live dealer'
    },
    '/bonuses': {
      title: 'Bonuses & Promotions | OLIMPBET',
      description: 'Discover exclusive bonuses and promotions at OLIMPBET. Get welcome bonuses, free bets, and more!',
      keywords: 'betting bonuses, casino bonuses, free bets, welcome bonus, promotions'
    },
    '/about': {
      title: 'About Us | OLIMPBET',
      description: 'Learn about OLIMPBET, a leading online betting and casino platform offering the best odds and gaming experience.',
      keywords: 'about olimpbet, betting company, online casino, sports betting platform'
    },
    '/register': {
      title: 'Register | OLIMPBET',
      description: 'Sign up with OLIMPBET today and get exclusive welcome bonuses. Fast and secure registration process!',
      keywords: 'register olimpbet, sign up, create account, betting registration'
    },
    '/login': {
      title: 'Login | OLIMPBET',
      description: 'Log in to your OLIMPBET account to place bets, play casino games, and manage your funds.',
      keywords: 'login olimpbet, sign in, account access, betting login'
    }
  };
  
  // Get SEO data for current page or use default
  const currentPageSEO = pageSEO[path as keyof typeof pageSEO] || pageSEO['/'];
  
  return (
    <SEO 
      title={currentPageSEO.title}
      description={currentPageSEO.description}
      keywords={currentPageSEO.keywords}
    />
  );
};

export default PageSEO;