import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const Results: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [activeTab, setActiveTab] = useState('today');
  const [selectedSport, setSelectedSport] = useState('all');

  const todayResults = [
    {
      id: 1,
      sport: 'Футбол',
      league: 'Премьер-лига России',
      homeTeam: 'Зенит',
      awayTeam: 'Спартак',
      homeScore: 2,
      awayScore: 1,
      status: 'Завершен',
      time: '90+3',
      date: '2024-01-15',
      startTime: '19:30',
      icon: '⚽',
      betStatus: 'win',
      odds: '2.15'
    },
    {
      id: 2,
      sport: 'Баскетбол',
      league: 'НБА',
      homeTeam: 'Los Angeles Lakers',
      awayTeam: 'Golden State Warriors',
      homeScore: 118,
      awayScore: 112,
      status: 'Завершен',
      time: '48:00',
      date: '2024-01-15',
      startTime: '06:00',
      icon: '🏀',
      betStatus: 'loss',
      odds: '1.95'
    },
    {
      id: 3,
      sport: 'Теннис',
      league: 'Australian Open',
      homeTeam: 'Новак Джокович',
      awayTeam: 'Рафаэль Надаль',
      homeScore: 3,
      awayScore: 1,
      status: 'Завершен',
      time: 'Сеты',
      date: '2024-01-15',
      startTime: '09:00',
      icon: '🎾',
      betStatus: 'win',
      odds: '1.75'
    },
    {
      id: 4,
      sport: 'Хоккей',
      league: 'КХЛ',
      homeTeam: 'ЦСКА',
      awayTeam: 'СКА',
      homeScore: 3,
      awayScore: 4,
      status: 'Завершен (ОТ)',
      time: '65:00',
      date: '2024-01-15',
      startTime: '19:30',
      icon: '🏒',
      betStatus: 'loss',
      odds: '2.05'
    }
  ];

  const yesterdayResults = [
    {
      id: 5,
      sport: 'Футбол',
      league: 'Лига Чемпионов',
      homeTeam: 'Реал Мадрид',
      awayTeam: 'Барселона',
      homeScore: 1,
      awayScore: 2,
      status: 'Завершен',
      time: '90+2',
      date: '2024-01-14',
      startTime: '22:00',
      icon: '⚽',
      betStatus: 'win',
      odds: '3.20'
    },
    {
      id: 6,
      sport: 'Баскетбол',
      league: 'Евролига',
      homeTeam: 'ЦСКА Москва',
      awayTeam: 'Фенербахче',
      homeScore: 89,
      awayScore: 94,
      status: 'Завершен',
      time: '40:00',
      date: '2024-01-14',
      startTime: '20:00',
      icon: '🏀',
      betStatus: 'loss',
      odds: '1.85'
    }
  ];

  const weekResults = [
    {
      id: 7,
      sport: 'Футбол',
      league: 'Английская Премьер-лига',
      homeTeam: 'Манчестер Сити',
      awayTeam: 'Ливерпуль',
      homeScore: 0,
      awayScore: 1,
      status: 'Завершен',
      time: '90+1',
      date: '2024-01-13',
      startTime: '17:30',
      icon: '⚽',
      betStatus: 'loss',
      odds: '2.45'
    },
    {
      id: 8,
      sport: 'Теннис',
      league: 'ATP 500',
      homeTeam: 'Даниил Медведев',
      awayTeam: 'Стефанос Циципас',
      homeScore: 2,
      awayScore: 0,
      status: 'Завершен',
      time: '1:35',
      date: '2024-01-12',
      startTime: '14:00',
      icon: '🎾',
      betStatus: 'win',
      odds: '1.65'
    }
  ];

  const popularSports = [
    { key: 'all', name: 'Все виды спорта', icon: '🏆', count: 156 },
    { key: 'football', name: 'Футбол', icon: '⚽', count: 45 },
    { key: 'basketball', name: 'Баскетбол', icon: '🏀', count: 28 },
    { key: 'tennis', name: 'Теннис', icon: '🎾', count: 22 },
    { key: 'hockey', name: 'Хоккей', icon: '🏒', count: 18 },
    { key: 'volleyball', name: 'Волейбол', icon: '🏐', count: 12 }
  ];

  const getResultsForTab = () => {
    switch (activeTab) {
      case 'today':
        return todayResults;
      case 'yesterday':
        return yesterdayResults;
      case 'week':
        return weekResults;
      default:
        return todayResults;
    }
  };

  const getBetStatusColor = (status: string) => {
    switch (status) {
      case 'win':
        return '#22c55e';
      case 'loss':
        return '#ef4444';
      default:
        return '#6b7280';
    }
  };

  const getBetStatusText = (status: string) => {
    switch (status) {
      case 'win':
        return 'Выигрыш';
      case 'loss':
        return 'Проигрыш';
      default:
        return '';
    }
  };

  return (
    <div style={{ 
      display: 'flex', 
      margin: '0 auto', 
      padding: '20px 20px 20px 10px',
      gap: '20px' 
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />
      
      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center'
        }}>
          <h1 style={{
            fontSize: '32px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 10px 0'
          }}>
            📊 РЕЗУЛЬТАТЫ МАТЧЕЙ
          </h1>
          <p style={{
            fontSize: '16px',
            color: '#666',
            margin: '0'
          }}>
            Результаты завершенных спортивных событий и статистика ставок
          </p>
        </div>

        {/* Sports Filter */}
        <div style={{
          backgroundColor: 'white',
          padding: '20px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
        }}>
          <h3 style={{
            fontSize: '16px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '15px'
          }}>
            Фильтр по видам спорта:
          </h3>
          <div style={{
            display: 'flex',
            gap: '10px',
            flexWrap: 'wrap'
          }}>
            {popularSports.map((sport) => (
              <button
                key={sport.key}
                onClick={() => setSelectedSport(sport.key)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '10px 16px',
                  border: 'none',
                  borderRadius: '20px',
                  backgroundColor: selectedSport === sport.key ? '#6b0c17' : '#f1f5f9',
                  color: selectedSport === sport.key ? 'white' : '#333',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => {
                  if (selectedSport !== sport.key) {
                    e.currentTarget.style.backgroundColor = '#e5e7eb';
                  }
                }}
                onMouseLeave={(e) => {
                  if (selectedSport !== sport.key) {
                    e.currentTarget.style.backgroundColor = '#f1f5f9';
                  }
                }}
              >
                <span>{sport.icon}</span>
                <span>{sport.name}</span>
                <span style={{
                  backgroundColor: selectedSport === sport.key ? 'rgba(255,255,255,0.2)' : '#6b0c17',
                  color: 'white',
                  padding: '2px 6px',
                  borderRadius: '10px',
                  fontSize: '11px',
                  minWidth: '18px',
                  textAlign: 'center'
                }}>
                  {sport.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Time Period Tabs */}
        <div style={{
          backgroundColor: 'white',
          padding: '0',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ display: 'flex' }}>
            {[
              { key: 'today', label: 'Сегодня', count: todayResults.length },
              { key: 'yesterday', label: 'Вчера', count: yesterdayResults.length },
              { key: 'week', label: 'За неделю', count: weekResults.length }
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                style={{
                  flex: 1,
                  padding: '15px 20px',
                  border: 'none',
                  backgroundColor: activeTab === tab.key ? '#6b0c17' : 'white',
                  color: activeTab === tab.key ? 'white' : '#666',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== tab.key) {
                    e.currentTarget.style.backgroundColor = '#f5f5f5';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== tab.key) {
                    e.currentTarget.style.backgroundColor = 'white';
                  }
                }}
              >
                <span>{tab.label}</span>
                <span style={{
                  backgroundColor: activeTab === tab.key ? 'rgba(255,255,255,0.2)' : '#6b0c17',
                  color: 'white',
                  padding: '2px 8px',
                  borderRadius: '12px',
                  fontSize: '12px',
                  minWidth: '20px'
                }}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Results List */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          overflow: 'hidden',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          {/* Header */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '80px 200px 1fr 120px 100px 120px',
            gap: '15px',
            alignItems: 'center',
            padding: '20px',
            backgroundColor: '#f8f9fa',
            borderBottom: '2px solid #e5e7eb',
            fontSize: '14px',
            fontWeight: 'bold',
            color: '#666'
          }}>
            <div>Спорт</div>
            <div>Лига</div>
            <div>Матч</div>
            <div style={{ textAlign: 'center' }}>Счет</div>
            <div style={{ textAlign: 'center' }}>Статус</div>
            <div style={{ textAlign: 'center' }}>Время</div>
          </div>

          {/* Results */}
          {getResultsForTab().map((result, index) => (
            <div
              key={result.id}
              style={{
                display: 'grid',
                gridTemplateColumns: '80px 200px 1fr 120px 100px 120px',
                gap: '15px',
                alignItems: 'center',
                padding: '20px',
                borderBottom: index < getResultsForTab().length - 1 ? '1px solid #f1f5f9' : 'none',
                backgroundColor: index % 2 === 0 ? '#ffffff' : '#fafafa',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#f0f9ff';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = index % 2 === 0 ? '#ffffff' : '#fafafa';
              }}
            >
              {/* Sport */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <div style={{
                  fontSize: '24px',
                  width: '40px',
                  height: '40px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  backgroundColor: '#f1f5f9',
                  borderRadius: '50%'
                }}>
                  {result.icon}
                </div>
              </div>

              {/* League */}
              <div>
                <div style={{
                  fontSize: '14px',
                  fontWeight: 'bold',
                  color: '#333',
                  marginBottom: '4px'
                }}>
                  {result.sport}
                </div>
                <div style={{
                  fontSize: '12px',
                  color: '#666',
                  lineHeight: 1.2
                }}>
                  {result.league}
                </div>
              </div>

              {/* Match */}
              <div>
                <div style={{
                  fontSize: '15px',
                  fontWeight: 'bold',
                  color: '#333',
                  marginBottom: '4px'
                }}>
                  {result.homeTeam} - {result.awayTeam}
                </div>
                <div style={{
                  fontSize: '12px',
                  color: '#666',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}>
                  <span>{result.date}</span>
                  <span>•</span>
                  <span>{result.startTime}</span>
                  {result.betStatus && (
                    <>
                      <span>•</span>
                      <span style={{
                        color: getBetStatusColor(result.betStatus),
                        fontWeight: 'bold'
                      }}>
                        {getBetStatusText(result.betStatus)}
                      </span>
                      {result.odds && (
                        <span style={{ color: '#6b0c17', fontWeight: 'bold' }}>
                          ({result.odds})
                        </span>
                      )}
                    </>
                  )}
                </div>
              </div>

              {/* Score */}
              <div style={{
                textAlign: 'center'
              }}>
                <div style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#333',
                  backgroundColor: '#f8f9fa',
                  padding: '8px 12px',
                  borderRadius: '8px',
                  display: 'inline-block'
                }}>
                  {result.homeScore} : {result.awayScore}
                </div>
              </div>

              {/* Status */}
              <div style={{
                textAlign: 'center'
              }}>
                <span style={{
                  backgroundColor: result.status.includes('Завершен') ? '#22c55e' : '#f59e0b',
                  color: 'white',
                  padding: '6px 10px',
                  borderRadius: '15px',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}>
                  {result.status}
                </span>
              </div>

              {/* Time */}
              <div style={{
                textAlign: 'center',
                fontSize: '14px',
                color: '#666',
                fontWeight: '500'
              }}>
                {result.time}
              </div>
            </div>
          ))}
        </div>

        {/* Statistics Summary */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '20px',
          marginTop: '30px'
        }}>
          {[
            { label: 'Всего матчей', value: '156', icon: '🏆', color: '#6b0c17' },
            { label: 'Выигрышных ставок', value: '89', icon: '✅', color: '#22c55e' },
            { label: 'Проигрышных ставок', value: '67', icon: '❌', color: '#ef4444' },
            { label: 'Процент успеха', value: '57%', icon: '📈', color: '#3b82f6' }
          ].map((stat, index) => (
            <div
              key={index}
              style={{
                backgroundColor: 'white',
                padding: '25px',
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                textAlign: 'center',
                border: `2px solid ${stat.color}20`
              }}
            >
              <div style={{
                fontSize: '32px',
                marginBottom: '10px'
              }}>
                {stat.icon}
              </div>
              <div style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: stat.color,
                marginBottom: '5px'
              }}>
                {stat.value}
              </div>
              <div style={{
                fontSize: '14px',
                color: '#666'
              }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Results; 