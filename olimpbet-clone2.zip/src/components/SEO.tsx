import React from 'react';
import { Helmet } from 'react-helmet';
import { useLocation } from 'react-router-dom';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  ogUrl?: string;
  ogType?: string;
  twitterCard?: string;
}

const SEO: React.FC<SEOProps> = ({
  title = 'OLIMPBET - Sports Betting & Casino',
  description = 'OLIMPBET offers sports betting, live betting, casino games and more. Join now for the best odds and bonuses!',
  keywords = 'sports betting, online betting, casino, olimpbet, betting odds, live betting',
  ogImage = 'https://olimpbet.com/social-share.svg',
  ogUrl = 'https://olimpbet.com',
  ogType = 'website',
  twitterCard = 'summary_large_image'
}) => {
  const location = useLocation();
  const siteTitle = title.includes('OLIMPBET') ? title : `${title} | OLIMPBET`;
  
  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{siteTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      
      {/* Open Graph Meta Tags */}
      <meta property="og:title" content={siteTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={ogImage} />
      <meta property="og:url" content={ogUrl} />
      <meta property="og:type" content={ogType} />
      
      {/* Twitter Card Meta Tags */}
      <meta name="twitter:card" content={twitterCard} />
      <meta name="twitter:title" content={siteTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={ogImage} />
      
      {/* Additional Meta Tags */}
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta httpEquiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="language" content="English" />
      <meta name="revisit-after" content="7 days" />
      <meta name="author" content="OLIMPBET" />
      <meta name="robots" content="index, follow" />
      
      {/* Favicon and Logo */}
      <link rel="icon" href="/favicon.ico" />
      <link rel="icon" href="/logo.svg" type="image/svg+xml" sizes="any" />
      <link rel="apple-touch-icon" href="/logo192.png" />
      <link rel="manifest" href="/manifest.json" />
      
      {/* Canonical URL */}
      <link rel="canonical" href={`${ogUrl}${location.pathname}`} />
    </Helmet>
  );
};

export default SEO;