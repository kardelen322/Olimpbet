import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useBalance } from '../contexts/BalanceContext';
import { useWithdrawal } from '../contexts/WithdrawalContext';
import { useAuth } from '../contexts/AuthContext';

const Withdrawal: React.FC = () => {
  const { translate } = useLanguage();
  const { balance, formatBalance } = useBalance();
  const { addWithdrawalRequest } = useWithdrawal();
  const { currentUser } = useAuth();
  
  const [amount, setAmount] = useState<string>('1000');
  const [withdrawalMethod, setWithdrawalMethod] = useState<string>('kaspi');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [showSuccess, setShowSuccess] = useState<boolean>(false);
  const [transactionId, setTransactionId] = useState<string>('');
  const [withdrawalStatus, setWithdrawalStatus] = useState<'pending' | 'rejected'>('pending');
  const [rejectionReason, setRejectionReason] = useState<string>('');
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) {
      setAmount(value);
    }
  };
  
  const handleQuickAmounts = (amount: number) => {
    setAmount(amount.toString());
  };
  
  const handleWithdrawalMethodChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setWithdrawalMethod(e.target.value);
  };
  
  const handleAccountNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAccountNumber(e.target.value);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || parseInt(amount) < 100) {
      alert(translate('minimumWithdrawalAmount'));
      return;
    }
    
    if (parseInt(amount) > balance) {
      alert(translate('insufficientFunds'));
      return;
    }
    
    if (!accountNumber) {
      alert(translate('pleaseEnterAccountNumber'));
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Simulate withdrawal processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate a transaction ID
      const txId = `WD-${Date.now().toString().slice(-6)}`;
      setTransactionId(txId);
      
      // Create withdrawal request instead of directly withdrawing funds
      if (currentUser) {
        await addWithdrawalRequest({
          username: currentUser.username || '',
          amount: parseInt(amount),
          paymentMethod: withdrawalMethod,
          accountNumber: accountNumber
        });
      }
      
      setShowSuccess(true);
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      alert(translate('withdrawalFailed'));
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleNewWithdrawal = () => {
    setShowSuccess(false);
    setAmount('1000');
    setWithdrawalMethod('kaspi');
    setAccountNumber('');
    setWithdrawalStatus('pending');
    setRejectionReason('');
  };
  
  // For demo purposes only - to simulate a rejected withdrawal
  const handleSimulateRejection = () => {
    setWithdrawalStatus('rejected');
    setRejectionReason('Bank account verification failed');
  };
  
  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '20px' }}>
        {translate('withdrawal')}
      </h1>
      
      {!showSuccess ? (
        <div>
          <div style={{ 
            backgroundColor: '#2c3e50', 
            padding: '15px', 
            borderRadius: '8px',
            marginBottom: '20px'
          }}>
            <div style={{ fontSize: '16px' }}>
              {translate('currentBalance')}: <span style={{ fontWeight: 'bold' }}>{formatBalance(balance)}</span>
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div style={{ backgroundColor: '#2c3e50', padding: '20px', borderRadius: '8px' }}>
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '10px' }}>
                  {translate('selectWithdrawalMethod')}
                </label>
                <select
                  value={withdrawalMethod}
                  onChange={handleWithdrawalMethodChange}
                  style={{
                    width: '100%',
                    padding: '12px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white'
                  }}
                >
                  <option value="kaspi">{translate('kaspi')}</option>
                  <option value="visa">{translate('visa')}</option>
                  <option value="mastercard">{translate('mastercard')}</option>
                  <option value="qiwi">{translate('qiwi')}</option>
                </select>
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '10px' }}>
                  {translate('enterAmount')}
                </label>
                <input
                  type="text"
                  value={amount}
                  onChange={handleAmountChange}
                  style={{
                    width: '100%',
                    padding: '12px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white'
                  }}
                  placeholder={translate('enterAmount')}
                />
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '10px', marginTop: '10px' }}>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(1000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                    1,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(5000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                    5,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(10000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                    10,000
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleQuickAmounts(50000)}
                    style={{
                      padding: '8px',
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                    50,000
                  </button>
                </div>
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '10px' }}>
                  {withdrawalMethod === 'kaspi' ? translate('enterPhoneNumber') : 
                   withdrawalMethod === 'qiwi' ? translate('enterQiwiWallet') : 
                   translate('enterCardNumber')}
                </label>
                <input
                  type="text"
                  value={accountNumber}
                  onChange={handleAccountNumberChange}
                  style={{
                    width: '100%',
                    padding: '12px',
                    backgroundColor: '#34495e',
                    border: '1px solid #445566',
                    borderRadius: '4px',
                    color: 'white'
                  }}
                  placeholder={withdrawalMethod === 'kaspi' ? '+7 XXX XXX XX XX' : 
                              withdrawalMethod === 'qiwi' ? translate('qiwiWalletNumber') : 
                              'XXXX XXXX XXXX XXXX'}
                />
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <div style={{ 
                  backgroundColor: '#34495e', 
                  padding: '15px', 
                  borderRadius: '4px',
                  fontSize: '14px'
                }}>
                  <div style={{ marginBottom: '10px', fontWeight: 'bold' }}>
                    {translate('withdrawalInformation')}
                  </div>
                  <ul style={{ paddingLeft: '20px', margin: '0' }}>
                    <li style={{ marginBottom: '5px' }}>{translate('minimumWithdrawalIs')} 100 {translate('currency')}</li>
                    <li style={{ marginBottom: '5px' }}>{translate('processingTimeIs')} 1-24 {translate('hours')}</li>
                    <li style={{ marginBottom: '5px' }}>{translate('withdrawalFeesInfo')}</li>
                    <li>{translate('verificationMayBeRequired')}</li>
                  </ul>
                </div>
              </div>
              
              <button
                type="submit"
                disabled={isProcessing}
                style={{
                  width: '100%',
                  padding: '12px',
                  backgroundColor: isProcessing ? '#7f8c8d' : '#27ae60',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: isProcessing ? 'not-allowed' : 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}
              >
                {isProcessing ? translate('processing') : translate('requestWithdrawal')}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div style={{ backgroundColor: '#2c3e50', padding: '20px', borderRadius: '8px', textAlign: 'center' }}>
          <div style={{ 
            backgroundColor: '#27ae60', 
            color: 'white', 
            width: '80px', 
            height: '80px', 
            borderRadius: '50%', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            margin: '0 auto 20px',
            fontSize: '40px'
          }}>
            ✓
          </div>
          
          <h2 style={{ marginBottom: '20px' }}>{translate('withdrawalRequestSubmitted')}</h2>
          
          <div style={{ 
            backgroundColor: '#34495e', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            textAlign: 'left'
          }}>
            <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('transactionId')}:</span>
              <span>{transactionId}</span>
            </div>
            <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('amount')}:</span>
              <span>{formatBalance(parseInt(amount))}</span>
            </div>
            <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('withdrawalMethod')}:</span>
              <span>{translate(withdrawalMethod)}</span>
            </div>
            <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('accountNumber')}:</span>
              <span>{accountNumber}</span>
            </div>
            <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('date')}:</span>
              <span>{new Date().toLocaleString()}</span>
            </div>
            <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
              <span>{translate('status')}:</span>
              <span style={{ color: withdrawalStatus === 'pending' ? '#f39c12' : '#e74c3c' }}>
                {translate(withdrawalStatus)}
              </span>
            </div>
            {withdrawalStatus === 'rejected' && rejectionReason && (
              <div style={{ marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
                <span>{translate('rejectionReason')}:</span>
                <span style={{ color: '#e74c3c' }}>{rejectionReason}</span>
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
              <span>{translate('newBalance')}:</span>
              <span>{formatBalance(balance)}</span>
            </div>
          </div>
          
          <div style={{ 
            backgroundColor: '#34495e', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            textAlign: 'left',
            fontSize: '14px'
          }}>
            <div style={{ marginBottom: '10px', fontWeight: 'bold' }}>
              {translate('nextSteps')}
            </div>
            <ol style={{ paddingLeft: '20px', margin: '0' }}>
              <li style={{ marginBottom: '5px' }}>{translate('withdrawalProcessingInfo')}</li>
              <li style={{ marginBottom: '5px' }}>{translate('checkEmailForUpdates')}</li>
              <li>{translate('contactSupportForQuestions')}</li>
            </ol>
          </div>
          
          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={handleNewWithdrawal}
              style={{
                flex: '1',
                padding: '12px',
                backgroundColor: '#3498db',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: 'bold'
              }}
            >
              {translate('makeAnotherWithdrawal')}
            </button>
            
            {/* Demo button for testing rejection - would be removed in production */}
            {withdrawalStatus === 'pending' && (
              <button
                onClick={handleSimulateRejection}
                style={{
                  padding: '12px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}
              >
                Demo: Simulate Rejection
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Withdrawal;