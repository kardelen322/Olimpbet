import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const Esports: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [selectedGame, setSelectedGame] = useState('csgo');
  const [selectedTournament, setSelectedTournament] = useState('all');

  const esportsGames = [
    {
      id: 'csgo',
      name: 'Counter-Strike: Global Offensive',
      shortName: 'CS:GO',
      icon: '🔫',
      color: '#f59e0b',
      matches: 89,
      tournaments: ['IEM Katowice', 'ESL Pro League', 'BLAST Premier', 'PGL Major', 'DreamHack']
    },
    {
      id: 'dota2',
      name: 'Dota 2',
      shortName: 'Dota 2',
      icon: '⚔️',
      color: '#ef4444',
      matches: 67,
      tournaments: ['The International', 'DPC Tour', 'ESL One', 'WePlay Esports', 'OGA Dota PIT']
    },
    {
      id: 'lol',
      name: 'League of Legends',
      shortName: 'LoL',
      icon: '🏰',
      color: '#06b6d4',
      matches: 134,
      tournaments: ['World Championship', 'LCS', 'LEC', 'LCK', 'MSI']
    },
    {
      id: 'valorant',
      name: 'Valorant',
      shortName: 'Valorant',
      icon: '🎯',
      color: '#8b5cf6',
      matches: 78,
      tournaments: ['VCT Champions', 'VCT Masters', 'Game Changers', 'Red Bull Campus', 'First Strike']
    },
    {
      id: 'fifa',
      name: 'FIFA 24',
      shortName: 'FIFA',
      icon: '⚽',
      color: '#22c55e',
      matches: 45,
      tournaments: ['FIFA eWorld Cup', 'FUT Champions', 'Global Series', 'ePremier League', 'eChampions League']
    }
  ];

  const liveMatches = [
    {
      id: 1,
      game: 'csgo',
      tournament: 'IEM Katowice 2024',
      team1: 'Team Spirit',
      team2: 'Natus Vincere',
      score1: 1,
      score2: 0,
      currentMap: 'Mirage',
      status: 'live',
      viewers: 45000,
      odds: { team1: '2.25', team2: '1.65' },
      round: 'Round 12',
      time: '08:45',
      startTime: '19:00',
      date: '2024-01-16',
      bo: 'BO3',
      prize: '$100,000'
    },
    {
      id: 2,
      game: 'dota2',
      tournament: 'DreamLeague Season 22',
      team1: 'Team Liquid',
      team2: 'OG',
      score1: 0,
      score2: 1,
      currentMap: 'Game 2',
      status: 'live',
      viewers: 28000,
      odds: { team1: '1.85', team2: '1.95' },
      round: 'Mid Game',
      time: '25:12',
      startTime: '17:30',
      date: '2024-01-16',
      bo: 'BO3',
      prize: '$75,000'
    },
    {
      id: 3,
      game: 'lol',
      tournament: 'LCS Spring 2024',
      team1: 'Cloud9',
      team2: 'Team Liquid',
      score1: 1,
      score2: 1,
      currentMap: 'Game 3',
      status: 'live',
      viewers: 32000,
      odds: { team1: '2.10', team2: '1.75' },
      round: 'Pick & Ban',
      time: '00:00',
      startTime: '21:00',
      date: '2024-01-16',
      bo: 'BO5',
      prize: '$50,000'
    }
  ];

  const upcomingMatches = [
    {
      id: 4,
      game: 'valorant',
      tournament: 'VCT Masters Madrid',
      team1: 'Fnatic',
      team2: 'Sentinels',
      score1: 0,
      score2: 0,
      currentMap: 'TBD',
      status: 'upcoming',
      viewers: 0,
      odds: { team1: '1.95', team2: '1.85' },
      round: 'Pre-match',
      time: '00:00',
      startTime: '18:00',
      date: '2024-01-16',
      bo: 'BO3',
      prize: '$50,000'
    },
    {
      id: 5,
      game: 'csgo',
      tournament: 'ESL Pro League',
      team1: 'Astralis',
      team2: 'FaZe Clan',
      score1: 0,
      score2: 0,
      currentMap: 'TBD',
      status: 'upcoming',
      viewers: 0,
      odds: { team1: '2.40', team2: '1.55' },
      round: 'Pre-match',
      time: '00:00',
      startTime: '20:30',
      date: '2024-01-16',
      bo: 'BO3',
      prize: '$25,000'
    }
  ];

  const tournaments = [
    {
      id: 'iem-katowice',
      name: 'IEM Katowice 2024',
      game: 'CS:GO', 
      prize: '$1,000,000',
      teams: 24,
      status: 'live',
      dates: '29 Jan - 11 Feb',
      location: 'Katowice, Poland'
    },
    {
      id: 'ti-2024',
      name: 'The International 2024',
      game: 'Dota 2',
      prize: '$15,000,000+',
      teams: 20,
      status: 'upcoming',
      dates: '3-13 Oct 2024',
      location: 'Seattle, USA'
    },
    {
      id: 'worlds-2024',
      name: 'Worlds 2024',
      game: 'League of Legends',
      prize: '$2,225,000',
      teams: 22,
      status: 'upcoming',
      dates: '25 Sep - 2 Nov',
      location: 'London, UK'
    }
  ];

  const teamStats = [
    {
      team: 'Team Spirit',
      game: 'CS:GO',
      rank: 1,
      rating: 1.34,
      winRate: '87%',
      lastMatches: ['W', 'W', 'W', 'L', 'W'],
      country: '🇷🇺'
    },
    {
      team: 'Natus Vincere',
      game: 'CS:GO',
      rank: 2,
      rating: 1.29,
      winRate: '82%',
      lastMatches: ['W', 'L', 'W', 'W', 'W'],
      country: '🇺🇦'
    },
    {
      team: 'Team Liquid',
      game: 'Dota 2',
      rank: 3,
      rating: 1.25,
      winRate: '79%',
      lastMatches: ['W', 'W', 'L', 'W', 'L'],
      country: '🇺🇸'
    }
  ];

  const selectedGameData = esportsGames.find(game => game.id === selectedGame);
  const filteredMatches = [...liveMatches, ...upcomingMatches].filter(match => match.game === selectedGame);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return '#ef4444';
      case 'upcoming': return '#22c55e';
      case 'finished': return '#6b7280';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'live': return '🔴 LIVE';
      case 'upcoming': return '🕐 Предстоящий';
      case 'finished': return '✅ Завершен';
      default: return status;
    }
  };

  return (
    <div style={{
      display: 'flex',
      margin: '0 auto',
      padding: '20px 20px 20px 10px',
      gap: '20px'
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />

      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
          color: 'white'
        }}>
          <h1 style={{
            fontSize: '36px',
            fontWeight: 'bold',
            margin: '0 0 10px 0'
          }}>
            🎮 КИБЕРСПОРТ
          </h1>
          <p style={{
            fontSize: '18px',
            margin: '0 0 15px 0',
            opacity: 0.9
          }}>
            Ставки на профессиональный киберспорт и турниры
          </p>
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '30px',
            fontSize: '14px',
            fontWeight: 'bold'
          }}>
            <div>🏆 5 популярных игр</div>
            <div>📺 Live трансляции</div>
            <div>💰 Крупные призовые</div>
            <div>⚡ Быстрые матчи</div>
          </div>
        </div>

        {/* Games Selection */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',  
          padding: '25px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#8b5cf6',
            margin: '0 0 20px 0',
            textAlign: 'center'
          }}>
            🎯 Выберите игру
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '15px'
          }}>
            {esportsGames.map(game => (
              <div
                key={game.id}
                onClick={() => setSelectedGame(game.id)}
                style={{
                  padding: '20px',
                  borderRadius: '12px',
                  border: selectedGame === game.id ? `3px solid ${game.color}` : '2px solid #e5e7eb',
                  backgroundColor: selectedGame === game.id ? `${game.color}15` : 'white',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  textAlign: 'center',
                  boxShadow: selectedGame === game.id ? `0 8px 25px ${game.color}40` : '0 2px 8px rgba(0,0,0,0.1)'
                }}
              >
                <div style={{
                  fontSize: '40px',
                  marginBottom: '10px'
                }}>
                  {game.icon}
                </div>
                <h3 style={{
                  fontSize: '16px',
                  fontWeight: 'bold',
                  color: selectedGame === game.id ? game.color : '#333',
                  margin: '0 0 5px 0'
                }}>
                  {game.shortName}
                </h3>
                <p style={{
                  fontSize: '12px',
                  color: '#666',
                  margin: '0 0 8px 0'
                }}>
                  {game.matches} активных матчей
                </p>
                <div style={{
                  backgroundColor: selectedGame === game.id ? game.color : '#6b7280',
                  color: 'white',
                  padding: '4px 8px',
                  borderRadius: '12px',
                  fontSize: '11px',
                  fontWeight: 'bold'
                }}>
                  {game.matches}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Game Details */}
        {selectedGameData && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '25px',
            marginBottom: '20px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
            border: `2px solid ${selectedGameData.color}`
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '15px',
              marginBottom: '20px'
            }}>
              <div style={{
                fontSize: '50px'
              }}>
                {selectedGameData.icon}
              </div>
              <div>
                <h2 style={{
                  fontSize: '28px',
                  fontWeight: 'bold',
                  color: selectedGameData.color,
                  margin: '0 0 5px 0'
                }}>
                  {selectedGameData.name}
                </h2>
                <p style={{
                  fontSize: '16px',
                  color: '#666',
                  margin: '0'
                }}>
                  {selectedGameData.matches} активных матчей • {selectedGameData.tournaments.length} турниров
                </p>
              </div>
            </div>

            {/* Tournament Filter */}
            <div style={{ marginBottom: '20px' }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#333',
                margin: '0 0 15px 0'
              }}>
                🏆 Турниры:
              </h3>
              <div style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '10px'
              }}>
                <button
                  onClick={() => setSelectedTournament('all')}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '20px',
                    border: selectedTournament === 'all' ? `2px solid ${selectedGameData.color}` : '2px solid #e5e7eb',
                    backgroundColor: selectedTournament === 'all' ? selectedGameData.color : 'white',
                    color: selectedTournament === 'all' ? 'white' : '#333',
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: 'bold',
                    transition: 'all 0.3s ease'
                  }}
                >
                  Все турниры
                </button>
                {selectedGameData.tournaments.map(tournament => (
                  <button
                    key={tournament}
                    onClick={() => setSelectedTournament(tournament)}
                    style={{
                      padding: '8px 16px',
                      borderRadius: '20px',
                      border: selectedTournament === tournament ? `2px solid ${selectedGameData.color}` : '2px solid #e5e7eb',
                      backgroundColor: selectedTournament === tournament ? selectedGameData.color : 'white',
                      color: selectedTournament === tournament ? 'white' : '#333',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: 'bold',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    {tournament}
                  </button>
                ))}
              </div>
            </div>

            {/* Matches */}
            <div>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#333',
                margin: '0 0 15px 0'
              }}>
                🔥 Матчи:
              </h3>
              
              {filteredMatches.length > 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                  {filteredMatches.map(match => (
                    <div
                      key={match.id}
                      style={{
                        padding: '20px',
                        borderRadius: '12px',
                        border: match.status === 'live' ? '3px solid #ef4444' : '2px solid #f3f4f6',
                        backgroundColor: match.status === 'live' ? '#fef2f2' : '#fafbfc',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '20px',
                        position: 'relative'
                      }}
                    >
                      {match.status === 'live' && (
                        <div style={{
                          position: 'absolute',
                          top: 0,
                          right: 0,
                          backgroundColor: '#ef4444',
                          color: 'white',
                          padding: '5px 15px',
                          fontSize: '12px',
                          fontWeight: 'bold',
                          borderBottomLeftRadius: '10px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '5px'
                        }}>
                          <div style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            backgroundColor: 'white',
                            animation: 'pulse 1s infinite'
                          }}></div>
                          LIVE
                        </div>
                      )}

                      <div style={{ flex: 1 }}>
                        <div style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          marginBottom: '8px'
                        }}>
                          <span style={{
                            color: getStatusColor(match.status),
                            fontSize: '12px',
                            fontWeight: 'bold'
                          }}>
                            {getStatusText(match.status)}
                          </span>
                          <span style={{ fontSize: '12px', color: '#666' }}>
                            {match.tournament}
                          </span>
                          {match.viewers && (
                            <>
                              <span>•</span>
                              <span style={{ fontSize: '12px', color: '#666' }}>
                                👥 {match.viewers.toLocaleString()}
                              </span>
                            </>
                          )}
                        </div>
                        
                        <div style={{
                          fontSize: '18px',
                          fontWeight: 'bold',
                          color: '#333',
                          marginBottom: '8px'
                        }}>
                          {match.team1} vs {match.team2}
                        </div>
                        
                        {match.status === 'live' ? (
                          <div style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '15px',
                            fontSize: '16px',
                            fontWeight: 'bold'
                          }}>
                            <span style={{ color: selectedGameData.color }}>
                              {match.score1} - {match.score2}
                            </span>
                            <span style={{
                              fontSize: '14px',
                              backgroundColor: selectedGameData.color,
                              color: 'white',
                              padding: '4px 8px',
                              borderRadius: '15px'
                            }}>
                              {match.currentMap}
                            </span>
                            <span style={{ fontSize: '13px', color: '#666' }}>
                              {match.round} • {match.time}
                            </span>
                          </div>
                        ) : (
                          <div style={{
                            fontSize: '13px',
                            color: '#666',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '15px'
                          }}>
                            <span>📅 {match.date}</span>
                            <span>🕐 {match.startTime}</span>
                            <span>🏆 {match.bo}</span>
                            <span>💰 {match.prize}</span>
                          </div>
                        )}
                      </div>

                      <div style={{
                        display: 'flex',
                        gap: '10px',
                        alignItems: 'center'
                      }}>
                        <button style={{
                          padding: '10px 15px',
                          borderRadius: '8px',
                          border: 'none',
                          backgroundColor: '#22c55e',
                          color: 'white',
                          cursor: 'pointer',
                          fontSize: '14px',
                          fontWeight: 'bold',
                          minWidth: '70px'
                        }}>
                          {match.odds.team1}
                        </button>
                        <button style={{
                          padding: '10px 15px',
                          borderRadius: '8px',
                          border: 'none',
                          backgroundColor: '#ef4444',
                          color: 'white',
                          cursor: 'pointer',
                          fontSize: '14px',
                          fontWeight: 'bold',
                          minWidth: '70px'
                        }}>
                          {match.odds.team2}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{
                  textAlign: 'center',
                  padding: '40px',
                  color: '#666',
                  fontSize: '16px'
                }}>
                  Нет доступных матчей для данной игры
                </div>
              )}
            </div>
          </div>
        )}

        {/* Major Tournaments */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '25px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#8b5cf6',
            margin: '0 0 20px 0',
            textAlign: 'center'
          }}>
            🏆 Крупные турниры
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
            gap: '20px'
          }}>
            {tournaments.map(tournament => (
              <div
                key={tournament.id}
                style={{
                  padding: '25px',
                  borderRadius: '12px',
                  border: tournament.status === 'live' ? '3px solid #ef4444' : '2px solid #e5e7eb',
                  backgroundColor: tournament.status === 'live' ? '#fef2f2' : '#fafbfc',
                  position: 'relative'
                }}
              >
                {tournament.status === 'live' && (
                  <div style={{
                    position: 'absolute',
                    top: 0,
                    right: 0,
                    backgroundColor: '#ef4444',
                    color: 'white',
                    padding: '5px 12px',
                    fontSize: '11px',
                    fontWeight: 'bold',
                    borderBottomLeftRadius: '8px'
                  }}>
                    LIVE
                  </div>
                )}
                
                <h3 style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#333',
                  margin: '0 0 10px 0'
                }}>
                  {tournament.name}
                </h3>
                
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  fontSize: '14px',
                  color: '#666'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>🎮 Игра:</span>
                    <span style={{ fontWeight: 'bold', color: '#333' }}>{tournament.game}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>💰 Призовой фонд:</span>
                    <span style={{ fontWeight: 'bold', color: '#22c55e' }}>{tournament.prize}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>👥 Команд:</span>
                    <span style={{ fontWeight: 'bold', color: '#333' }}>{tournament.teams}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>📅 Даты:</span>
                    <span style={{ fontWeight: 'bold', color: '#333' }}>{tournament.dates}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>📍 Место:</span>
                    <span style={{ fontWeight: 'bold', color: '#333' }}>{tournament.location}</span>
                  </div>
                </div>

                <button style={{
                  width: '100%',
                  padding: '12px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: tournament.status === 'live' ? '#ef4444' : '#8b5cf6',
                  color: 'white',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  marginTop: '15px'
                }}>
                  {tournament.status === 'live' ? 'Смотреть LIVE' : 'Подробнее'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Top Teams */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '25px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#8b5cf6',
            margin: '0 0 20px 0',
            textAlign: 'center'
          }}>
            🌟 Топ команды
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '15px'
          }}>
            {teamStats.map((team, index) => (
              <div
                key={index}
                style={{
                  padding: '20px',
                  borderRadius: '12px',
                  border: '2px solid #f3f4f6',
                  backgroundColor: '#fafbfc',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '15px'
                }}
              >
                <div style={{
                  fontSize: '24px',
                  fontWeight: 'bold',
                  color: '#8b5cf6',
                  backgroundColor: '#8b5cf615',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  #{team.rank}
                </div>
                
                <div style={{ flex: 1 }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginBottom: '5px'
                  }}>
                    <span style={{ fontSize: '20px' }}>{team.country}</span>
                    <h3 style={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: '#333',
                      margin: '0'
                    }}>
                      {team.team}
                    </h3>
                  </div>
                  
                  <div style={{
                    fontSize: '12px',
                    color: '#666',
                    marginBottom: '8px'
                  }}>
                    {team.game} • Рейтинг: {team.rating} • WR: {team.winRate}
                  </div>
                  
                  <div style={{
                    display: 'flex',
                    gap: '4px'
                  }}>
                    {team.lastMatches.map((result, idx) => (
                      <span
                        key={idx}
                        style={{
                          width: '20px',
                          height: '20px',
                          borderRadius: '3px',
                          backgroundColor: result === 'W' ? '#22c55e' : '#ef4444',
                          color: 'white',
                          fontSize: '10px',
                          fontWeight: 'bold',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        {result}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Add CSS animations */}
        <style>{`
          @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
          }
        `}</style>
      </div>
    </div>
  );
};

export default Esports; 