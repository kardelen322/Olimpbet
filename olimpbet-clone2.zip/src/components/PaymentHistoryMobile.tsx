import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useBalance } from '../contexts/BalanceContext';
import { useAuth } from '../contexts/AuthContext';
import { getTransactionHistory } from '../database/payment-adapter';

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  method: string;
  status: 'completed' | 'pending' | 'failed' | 'rejected';
  date: Date;
  details?: string;
  rejectionReason?: string;
}

const PaymentHistoryMobile: React.FC = () => {
  const { translate } = useLanguage();
  const { formatBalance } = useBalance();
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<{ from: string; to: string }>({ 
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days ago
    to: new Date().toISOString().split('T')[0] // today
  });
  
  const { currentUser } = useAuth();

  // Fetch real transaction data
  useEffect(() => {
    const fetchTransactionHistory = async () => {
      if (currentUser?.phone) {
        try {
          const history = await getTransactionHistory(currentUser.phone);
          setTransactions(history);
        } catch (error) {
          console.error('Error fetching transaction history:', error);
          // Fallback to empty array if there's an error
          setTransactions([]);
        }
      }
    };
    
    fetchTransactionHistory();
  }, [currentUser]);
  
  // Apply filters
  useEffect(() => {
    let filtered = [...transactions];
    
    // Filter by type
    if (filter === 'deposits') {
      filtered = filtered.filter(tx => tx.type === 'deposit');
    } else if (filter === 'withdrawals') {
      filtered = filtered.filter(tx => tx.type === 'withdrawal');
    }
    
    // Filter by date range
    const fromDate = new Date(dateRange.from);
    fromDate.setHours(0, 0, 0, 0);
    
    const toDate = new Date(dateRange.to);
    toDate.setHours(23, 59, 59, 999);
    
    filtered = filtered.filter(tx => {
      const txDate = new Date(tx.date);
      return txDate >= fromDate && txDate <= toDate;
    });
    
    // Sort by date (newest first)
    filtered.sort((a, b) => b.date.getTime() - a.date.getTime());
    
    setFilteredTransactions(filtered);
  }, [transactions, filter, dateRange]);
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilter(e.target.value);
  };
  
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDateRange(prev => ({ ...prev, [name]: value }));
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return '#27ae60';
      case 'pending':
        return '#f39c12';
      case 'failed':
        return '#e74c3c';
      case 'rejected':
        return '#ff0000';
      default:
        return '#7f8c8d';
    }
  };
  
  return (
    <div style={{ padding: '15px' }}>
      <h1 style={{ borderBottom: '2px solid #444', paddingBottom: '10px', marginBottom: '15px', fontSize: '20px' }}>
        {translate('paymentHistory')}
      </h1>
      
      <div style={{ 
        marginBottom: '15px',
        backgroundColor: '#2c3e50',
        padding: '15px',
        borderRadius: '8px'
      }}>
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
            {translate('filterBy')}:
          </label>
          <select 
            value={filter} 
            onChange={handleFilterChange}
            style={{
              width: '100%',
              padding: '10px',
              backgroundColor: '#34495e',
              border: '1px solid #445566',
              borderRadius: '4px',
              color: 'white',
              fontSize: '14px'
            }}
          >
            <option value="all">{translate('allTransactions')}</option>
            <option value="deposits">{translate('deposits')}</option>
            <option value="withdrawals">{translate('withdrawals')}</option>
          </select>
        </div>
        
        <div style={{ display: 'flex', gap: '10px' }}>
          <div style={{ flex: 1 }}>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
              {translate('from')}:
            </label>
            <input 
              type="date" 
              name="from" 
              value={dateRange.from} 
              onChange={handleDateChange}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white',
                fontSize: '14px'
              }}
            />
          </div>
          
          <div style={{ flex: 1 }}>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px' }}>
              {translate('to')}:
            </label>
            <input 
              type="date" 
              name="to" 
              value={dateRange.to} 
              onChange={handleDateChange}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#34495e',
                border: '1px solid #445566',
                borderRadius: '4px',
                color: 'white',
                fontSize: '14px'
              }}
            />
          </div>
        </div>
      </div>
      
      {filteredTransactions.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {filteredTransactions.map((tx) => (
            <div 
              key={tx.id} 
              style={{ 
                backgroundColor: '#2c3e50', 
                borderRadius: '8px', 
                padding: '15px',
                fontSize: '14px'
              }}
            >
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                marginBottom: '10px'
              }}>
                <div>
                  <div style={{ fontWeight: 'bold' }}>{tx.id}</div>
                  <div style={{ fontSize: '12px', color: '#7f8c8d' }}>
                    {tx.date.toLocaleDateString()} {tx.date.toLocaleTimeString()}
                  </div>
                </div>
                <div style={{ 
                  display: 'flex', 
                  flexDirection: 'column', 
                  alignItems: 'flex-end'
                }}>
                  <span style={{ 
                    fontWeight: 'bold', 
                    color: tx.type === 'deposit' ? '#27ae60' : '#e74c3c'
                  }}>
                    {tx.type === 'deposit' ? '+' : '-'}{formatBalance(tx.amount)}
                  </span>
                  <div style={{ 
                    display: 'inline-block',
                    padding: '4px 8px',
                    borderRadius: '4px',
                    backgroundColor: getStatusColor(tx.status),
                    fontSize: '12px',
                    marginTop: '5px'
                  }}>
                    {translate(tx.status)}
                  </div>
                </div>
              </div>
              
              <div style={{ 
                backgroundColor: '#34495e', 
                borderRadius: '4px', 
                padding: '10px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                  <span>{translate('type')}:</span>
                  <span>
                    <div style={{ 
                      display: 'inline-block',
                      padding: '2px 6px',
                      borderRadius: '4px',
                      backgroundColor: tx.type === 'deposit' ? '#2980b9' : '#8e44ad',
                      fontSize: '12px'
                    }}>
                      {translate(tx.type)}
                    </div>
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                  <span>{translate('method')}:</span>
                  <span>{translate(tx.method)}</span>
                </div>
                {tx.details && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>{translate('details')}:</span>
                    <span>{tx.details}</span>
                  </div>
                )}
                {tx.status === 'rejected' && tx.rejectionReason && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', color: '#e74c3c', marginTop: '5px' }}>
                    <span>{translate('rejectionReason')}:</span>
                    <span>{tx.rejectionReason}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ 
          backgroundColor: '#2c3e50', 
          padding: '20px', 
          borderRadius: '8px', 
          textAlign: 'center',
          color: '#7f8c8d'
        }}>
          <div style={{ fontSize: '40px', marginBottom: '10px' }}>📋</div>
          <h3 style={{ fontSize: '18px' }}>{translate('noTransactionsFound')}</h3>
          <p style={{ fontSize: '14px' }}>{translate('tryChangingFilters')}</p>
        </div>
      )}
    </div>
  );
};

export default PaymentHistoryMobile;