import React, { Suspense } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';
import LiveMatches from './LiveMatches';
import PaymentButton from './PaymentButton';
import ErrorBoundary from './ErrorBoundary';

const LoadingIndicator: React.FC = () => (
  <div style={{
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundColor: '#f5f5f5',
    fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
  }}>
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '15px'
    }}>
      <div style={{
        width: '40px',
        height: '40px',
        border: '4px solid #f3f3f3',
        borderTop: '4px solid #6b0c17',
        borderRadius: '50%',
        animation: 'spin 1s linear infinite'
      }}></div>
      <div style={{
        color: '#6b0c17',
        fontSize: '16px',
        fontWeight: 'bold'
      }}>
        Loading OLIMPBET...
      </div>
    </div>
    <style>
      {`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}
    </style>
  </div>
);

const HomePage: React.FC = () => {
  const { translate, isRTL } = useLanguage();

  return (
    <ErrorBoundary fallback={
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        backgroundColor: '#f5f5f5',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif',
        textAlign: 'center'
      }}>
        <div>
          <h1 style={{ color: '#6b0c17' }}>🚨 {translate('errorLoadingPage')}</h1>
          <p>{translate('pleaseRefreshOrContactSupport')}</p>
        </div>
      </div>
    }>
      <Suspense fallback={<LoadingIndicator />}>
        <div 
          style={{
            display: 'flex',
            maxWidth: '1400px',
            margin: '0 auto',
            padding: '20px',
            gap: '20px',
            minHeight: 'calc(100vh - 200px)'
          }} 
          dir={isRTL ? 'rtl' : 'ltr'}
        >
          {/* Sidebar - Fixed width */}
          <div style={{
            flexShrink: 0
          }}>
            <Sidebar />
          </div>
          
          {/* Main Content Area - Flexible width */}
          <div style={{
            flex: 1,
            minWidth: 0 // Prevents flex item from overflowing
          }}>
            <LiveMatches />
            
            {/* Payment Section */}
            <div style={{
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)',
              borderRadius: '16px',
              padding: '40px',
              marginTop: '20px',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
              textAlign: 'center',
              border: '3px solid #28a745',
              position: 'relative',
              overflow: 'hidden'
            }}>
              {/* Background decoration */}
              <div style={{
                position: 'absolute',
                top: '-50%',
                right: '-50%',
                width: '200%',
                height: '200%',
                background: 'radial-gradient(circle, rgba(40, 167, 69, 0.05) 0%, transparent 70%)',
                pointerEvents: 'none'
              }}></div>
              
              <h2 style={{
                fontSize: '32px',
                fontWeight: 'bold',
                color: '#6b0c17',
                margin: '0 0 20px 0',
                textShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                position: 'relative',
                zIndex: 1
              }}>
                💰 Начните делать ставки прямо сейчас!
              </h2>
              <p style={{
                fontSize: '18px',
                color: '#555',
                margin: '0 0 35px 0',
                lineHeight: '1.6',
                maxWidth: '600px',
                marginLeft: 'auto',
                marginRight: 'auto',
                position: 'relative',
                zIndex: 1
              }}>
                Пополните свой счет через Kaspi.kz и получите доступ к лучшим коэффициентам на спортивные события
              </p>
              <PaymentButton 
                variant="homepage"
                style={{
                  background: 'linear-gradient(135deg, #28a745 0%, #20c997 100%)',
                  color: 'white',
                  border: '3px solid #28a745',
                  padding: '18px 50px',
                  borderRadius: '50px',
                  fontSize: '20px',
                  fontWeight: 'bold',
                  cursor: 'pointer',
                  textTransform: 'uppercase',
                  boxShadow: '0 8px 25px rgba(40, 167, 69, 0.4)',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  transform: 'scale(1)',
                  letterSpacing: '1px',
                  position: 'relative',
                  zIndex: 1,
                  minWidth: '250px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e: React.MouseEvent<HTMLButtonElement>) => {
                  e.currentTarget.style.transform = 'scale(1.08) translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 12px 35px rgba(40, 167, 69, 0.6)';
                  e.currentTarget.style.background = 'linear-gradient(135deg, #20c997 0%, #28a745 100%)';
                }}
                onMouseLeave={(e: React.MouseEvent<HTMLButtonElement>) => {
                  e.currentTarget.style.transform = 'scale(1) translateY(0)';
                  e.currentTarget.style.boxShadow = '0 8px 25px rgba(40, 167, 69, 0.4)';
                  e.currentTarget.style.background = 'linear-gradient(135deg, #28a745 0%, #20c997 100%)';
                }}
              />
              <div style={{
                marginTop: '25px',
                fontSize: '14px',
                color: '#666',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                gap: '20px',
                flexWrap: 'wrap',
                position: 'relative',
                zIndex: 1
              }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>🔒 Безопасные платежи</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>⚡ Мгновенное зачисление</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>🎯 Без комиссий</span>
              </div>
            </div>
          </div>
        </div>
      </Suspense>
    </ErrorBoundary>
  );
};

export default HomePage;
