import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import Sidebar from './Sidebar';

const Live: React.FC = () => {
  const { translate, isRTL } = useLanguage();
  const [selectedSport, setSelectedSport] = useState('all');
  // Removed currentTime timer to prevent unnecessary re-renders

  const liveMatches = [
    {
      id: 1,
      sport: 'football',
      sportName: 'Футбол',
      league: 'Премьер-лига России',
      homeTeam: 'Зенит',
      awayTeam: 'Спартак',
      homeScore: 1,
      awayScore: 0,
      time: '67\'',
      status: 'live',
      odds: { home: '1.85', draw: '3.90', away: '4.20' },
      viewers: 25840,
      events: [
        { time: '23\'', type: 'goal', team: 'home', player: 'Азмун', score: '', winner: '' },
        { time: '45\'', type: 'yellow', team: 'away', player: 'Промес', score: '', winner: '' },
        { time: '62\'', type: 'substitution', team: 'home', player: 'Малком → Сутормин', score: '', winner: '' }
      ]
    },
    {
      id: 2,
      sport: 'tennis',
      sportName: 'Теннис',
      league: 'Australian Open',
      homeTeam: 'Новак Джокович',
      awayTeam: 'Стефанос Циципас',
      homeScore: 2,
      awayScore: 1,
      time: 'Сет 4',
      status: 'live',
      odds: { player1: '1.45', player2: '2.75' },
      viewers: 12340,
      events: [
        { time: 'Сет 1', type: 'set', team: 'home', player: '', score: '6-4', winner: 'home' },
        { time: 'Сет 2', type: 'set', team: 'away', player: '', score: '4-6', winner: 'away' },
        { time: 'Сет 3', type: 'set', team: 'home', player: '', score: '6-3', winner: 'home' }
      ]
    },
    {
      id: 3,
      sport: 'basketball',
      sportName: 'Баскетбол',
      league: 'НБА',
      homeTeam: 'Los Angeles Lakers',
      awayTeam: 'Boston Celtics',
      homeScore: 89,
      awayScore: 92,
      time: 'Q3 08:45',
      status: 'live',
      odds: { home: '2.10', spread: '1.90', away: '1.75' },
      viewers: 18760,
      events: [
        { time: 'Q1', type: 'quarter', team: 'home', player: '', score: '28-25', winner: 'home' },
        { time: 'Q2', type: 'quarter', team: 'away', player: '', score: '24-29', winner: 'away' },
        { time: 'Q3 11:23', type: '3pt', team: 'away', player: 'Tatum', score: '', winner: '' }
      ]
    },
    {
      id: 4,
      sport: 'hockey',
      sportName: 'Хоккей',
      league: 'КХЛ',
      homeTeam: 'ЦСКА',
      awayTeam: 'Динамо Москва',
      homeScore: 2,
      awayScore: 1,
      time: '2 период 14:32',
      status: 'live',
      odds: { home: '1.95', draw: '4.10', away: '3.45' },
      viewers: 8950,
      events: [
        { time: '1 период 8:15', type: 'goal', team: 'home', player: 'Шипачев', score: '', winner: '' },
        { time: '1 период 16:44', type: 'goal', team: 'away', player: 'Кагарлицкий', score: '', winner: '' },
        { time: '2 период 5:22', type: 'goal', team: 'home', player: 'Федотов', score: '', winner: '' }
      ]
    },
    {
      id: 5,
      sport: 'esports',
      sportName: 'Киберспорт',
      league: 'CS:GO Major',
      homeTeam: 'Team Spirit',
      awayTeam: 'Natus Vincere',
      homeScore: 1,
      awayScore: 0,
      time: 'Карта 2',
      status: 'live',
      odds: { team1: '2.25', team2: '1.65' },
      viewers: 45000,
      events: [
        { time: 'Карта 1', type: 'map', team: 'home', player: '', score: '16-12', winner: 'home' },
        { time: 'Round 8', type: 'ace', team: 'home', player: 'sh1ro', score: '', winner: '' }
      ]
    }
  ];

  const upcomingMatches = [
    {
      id: 6,
      sport: 'football',
      sportName: 'Футбол',
      league: 'Лига Чемпионов',
      homeTeam: 'Реал Мадрид',
      awayTeam: 'Манчестер Сити',
      startTime: '22:00',
      date: '2024-01-16',
      odds: { home: '2.40', draw: '3.20', away: '2.95' },
      prediction: 'high-scoring'
    },
    {
      id: 7,
      sport: 'basketball',
      sportName: 'Баскетбол',
      league: 'Евролига',
      homeTeam: 'ЦСКА',
      awayTeam: 'Фенербахче',
      startTime: '20:00',
      date: '2024-01-16',
      odds: { home: '1.85', spread: '1.90', away: '1.95' },
      prediction: 'close-game'
    }
  ];

  const sportsFilter = [
    { id: 'all', name: 'Все виды спорта', icon: '🏆', count: liveMatches.length },
    { id: 'football', name: 'Футбол', icon: '⚽', count: liveMatches.filter(m => m.sport === 'football').length },
    { id: 'tennis', name: 'Теннис', icon: '🎾', count: liveMatches.filter(m => m.sport === 'tennis').length },
    { id: 'basketball', name: 'Баскетбол', icon: '🏀', count: liveMatches.filter(m => m.sport === 'basketball').length },
    { id: 'hockey', name: 'Хоккей', icon: '🏒', count: liveMatches.filter(m => m.sport === 'hockey').length },
    { id: 'esports', name: 'Киберспорт', icon: '🎮', count: liveMatches.filter(m => m.sport === 'esports').length }
  ];

  const filteredMatches = selectedSport === 'all' 
    ? liveMatches 
    : liveMatches.filter(match => match.sport === selectedSport);

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'goal': return '⚽';
      case 'yellow': return '🟨';
      case 'red': return '🟥';
      case 'substitution': return '🔄';
      case 'set': return '🎾';
      case 'quarter': return '🏀';
      case '3pt': return '3️⃣';
      case 'ace': return '🎯';
      case 'map': return '🗺️';
      default: return '📝';
    }
  };

  return (
    <div style={{
      display: 'flex',
      margin: '0 auto',
      padding: '20px 20px 20px 10px',
      gap: '20px'
    }} dir={isRTL ? 'rtl' : 'ltr'}>
      <Sidebar />

      <div style={{
        flex: 1,
        backgroundColor: '#f8f9fa',
        fontFamily: 'Tahoma, Verdana, Helvetica, sans-serif'
      }}>
        {/* Page Header */}
        <div style={{
          backgroundColor: 'white',
          padding: '30px',
          borderRadius: '12px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          textAlign: 'center',
          background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
          color: 'white'
        }}>
          <h1 style={{
            fontSize: '36px',
            fontWeight: 'bold',
            margin: '0 0 10px 0',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '15px'
          }}>
            🔴 ЛАЙВ
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
              fontSize: '18px',
              fontWeight: 'normal'
            }}>
              <div style={{
                width: '12px',
                height: '12px',
                borderRadius: '50%',
                backgroundColor: '#22c55e',
                animation: 'pulse 2s infinite'
              }}></div>
              LIVE
            </div>
          </h1>
          <p style={{
            fontSize: '18px',
            margin: '0 0 15px 0',
            opacity: 0.9
          }}>
            Следите за матчами в режиме реального времени
          </p>
          <div style={{
            fontSize: '14px',
            opacity: 0.8
          }}>
            Активных матчей: {liveMatches.length}
          </div>
        </div>

        {/* Sports Filter */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <div style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '10px',
            justifyContent: 'center'
          }}>
            {sportsFilter.map(filter => (
              <button
                key={filter.id}
                onClick={() => setSelectedSport(filter.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '12px 20px',
                  borderRadius: '25px',
                  border: selectedSport === filter.id ? '3px solid #ef4444' : '2px solid #e5e7eb',
                  backgroundColor: selectedSport === filter.id ? '#ef444415' : 'white',
                  color: selectedSport === filter.id ? '#ef4444' : '#333',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  transition: 'all 0.3s ease',
                  boxShadow: selectedSport === filter.id ? '0 4px 15px rgba(239, 68, 68, 0.3)' : 'none'
                }}
              >
                <span style={{ fontSize: '18px' }}>{filter.icon}</span>
                {filter.name}
                <span style={{
                  backgroundColor: selectedSport === filter.id ? '#ef4444' : '#6b7280',
                  color: 'white',
                  padding: '2px 8px',
                  borderRadius: '12px',
                  fontSize: '12px',
                  minWidth: '20px',
                  textAlign: 'center'
                }}>
                  {filter.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Live Matches */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '25px',
          marginBottom: '20px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#ef4444',
            margin: '0 0 20px 0',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}>
            🔥 Матчи в прямом эфире
            <div style={{
              width: '10px',
              height: '10px',
              borderRadius: '50%',
              backgroundColor: '#ef4444',
              animation: 'pulse 1.5s infinite'
            }}></div>
          </h2>

          {filteredMatches.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {filteredMatches.map(match => (
                <div
                  key={match.id}
                  style={{
                    padding: '25px',
                    borderRadius: '15px',
                    border: '3px solid #ef4444',
                    backgroundColor: '#fef2f2',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '15px',
                    boxShadow: '0 8px 25px rgba(239, 68, 68, 0.2)',
                    position: 'relative',
                    overflow: 'hidden'
                  }}
                >
                  {/* Live indicator */}
                  <div style={{
                    position: 'absolute',
                    top: 0,
                    right: 0,
                    backgroundColor: '#ef4444',
                    color: 'white',
                    padding: '5px 15px',
                    fontSize: '12px',
                    fontWeight: 'bold',
                    borderBottomLeftRadius: '10px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px'
                  }}>
                    <div style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      backgroundColor: 'white',
                      animation: 'pulse 1s infinite'
                    }}></div>
                    LIVE
                  </div>

                  {/* Match header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={{
                        fontSize: '14px',
                        color: '#666',
                        marginBottom: '5px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px'
                      }}>
                        <span>{match.sportName}</span>
                        <span>•</span>
                        <span>{match.league}</span>
                        <span>•</span>
                        <span>👥 {match.viewers.toLocaleString()}</span>
                      </div>
                      
                      <h3 style={{
                        fontSize: '20px',
                        fontWeight: 'bold',
                        color: '#333',
                        margin: '0 0 10px 0'
                      }}>
                        {match.homeTeam} vs {match.awayTeam}
                      </h3>
                      
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '20px',
                        fontSize: '24px',
                        fontWeight: 'bold',
                        color: '#ef4444'
                      }}>
                        <span>{match.homeScore} - {match.awayScore}</span>
                        <span style={{
                          fontSize: '16px',
                          backgroundColor: '#ef4444',
                          color: 'white',
                          padding: '5px 10px',
                          borderRadius: '20px'
                        }}>
                          {match.time}
                        </span>
                      </div>
                    </div>

                    {/* Live odds */}
                    <div style={{
                      display: 'flex',
                      gap: '8px',
                      alignItems: 'center'
                    }}>
                      {match.sport === 'tennis' ? (
                        <>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#22c55e',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            {match.odds.player1}
                          </button>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#ef4444',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            {match.odds.player2}
                          </button>
                        </>
                      ) : match.sport === 'basketball' ? (
                        <>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#22c55e',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            П1 {match.odds.home}
                          </button>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#f59e0b',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            Ф {match.odds.spread}
                          </button>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#ef4444',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            П2 {match.odds.away}
                          </button>
                        </>
                      ) : match.sport === 'esports' ? (
                        <>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#22c55e',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            {match.odds.team1}
                          </button>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#ef4444',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            {match.odds.team2}
                          </button>
                        </>
                      ) : (
                        <>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#22c55e',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            1 {match.odds.home}
                          </button>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#f59e0b',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            X {match.odds.draw}
                          </button>
                          <button style={{
                            padding: '10px 15px',
                            borderRadius: '8px',
                            border: 'none',
                            backgroundColor: '#ef4444',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            minWidth: '60px'
                          }}>
                            2 {match.odds.away}
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Recent events */}
                  <div style={{
                    backgroundColor: 'white',
                    borderRadius: '10px',
                    padding: '15px',
                    border: '1px solid #f3f4f6'
                  }}>
                    <h4 style={{
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: '#333',
                      margin: '0 0 10px 0'
                    }}>
                      📝 Последние события:
                    </h4>
                    <div style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '8px'
                    }}>
                      {match.events.slice(-3).reverse().map((event, index) => (
                        <div
                          key={`${match.id}-event-${index}`}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '10px',
                            fontSize: '13px',
                            color: '#555'
                          }}
                        >
                          <span style={{ fontSize: '16px' }}>{getEventIcon(event.type)}</span>
                          <span style={{ fontWeight: 'bold', color: '#ef4444' }}>{event.time}</span>
                          <span>{event.player || event.score || 'Событие'}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{
              textAlign: 'center',
              padding: '60px',
              color: '#666',
              fontSize: '18px',
              backgroundColor: '#f9fafb',
              borderRadius: '12px',
              border: '2px dashed #e5e7eb'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '15px' }}>📺</div>
              Нет доступных матчей для выбранного вида спорта
            </div>
          )}
        </div>

        {/* Upcoming Matches */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: '12px',
          padding: '25px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#6b0c17',
            margin: '0 0 20px 0',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}>
            ⏰ Скоро в эфире
          </h2>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            {upcomingMatches.map(match => (
              <div
                key={match.id}
                style={{
                  padding: '20px',
                  borderRadius: '12px',
                  border: '2px solid #f3f4f6',
                  backgroundColor: '#fafbfc',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div>
                  <div style={{
                    fontSize: '12px',
                    color: '#666',
                    marginBottom: '5px'
                  }}>
                    {match.sportName} • {match.league}
                  </div>
                  <h3 style={{
                    fontSize: '16px',
                    fontWeight: 'bold',
                    color: '#333',
                    margin: '0 0 5px 0'
                  }}>
                    {match.homeTeam} vs {match.awayTeam}
                  </h3>
                  <div style={{
                    fontSize: '14px',
                    color: '#6b0c17',
                    fontWeight: 'bold'
                  }}>
                    📅 {match.date} 🕐 {match.startTime}
                  </div>
                </div>

                <div style={{
                  display: 'flex',
                  gap: '8px',
                  alignItems: 'center'
                }}>
                  <button style={{
                    padding: '8px 12px',
                    borderRadius: '6px',
                    border: 'none',
                    backgroundColor: '#22c55e',
                    color: 'white',
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: 'bold'
                  }}>
                    1 {match.odds.home}
                  </button>
                  {match.odds.draw && (
                    <button style={{
                      padding: '8px 12px',
                      borderRadius: '6px',
                      border: 'none',
                      backgroundColor: '#f59e0b',
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: 'bold'
                    }}>
                      X {match.odds.draw}
                    </button>
                  )}
                  <button style={{
                    padding: '8px 12px',
                    borderRadius: '6px',
                    border: 'none',
                    backgroundColor: '#ef4444',
                    color: 'white',
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: 'bold'
                  }}>
                    2 {match.odds.away || match.odds.spread}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Add CSS animations */}
        <style>{`
          @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
          }
        `}</style>
      </div>
    </div>
  );
};

export default Live;