import { ru } from './ru';
import { en } from './en';
import { tr } from './tr';

export const translations = {
  ru,
  en,
  tr,
};

export type TranslationKey = keyof typeof ru;
export type LanguageCode = keyof typeof translations;
