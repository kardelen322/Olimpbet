export interface WithdrawalRequest {
  id: string;
  username: string;
  user_id?: string;
  amount: number;
  paymentMethod: string;
  accountNumber: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  created_at?: string;
  updated_at?: string;
}

export interface WithdrawalContextType {
  withdrawalRequests: WithdrawalRequest[];
  addWithdrawalRequest: (request: Omit<WithdrawalRequest, 'id' | 'date' | 'status'>) => Promise<void>;
  approveWithdrawalRequest: (id: string) => Promise<void>;
  rejectWithdrawalRequest: (id: string, reason: string) => Promise<void>;
  fetchWithdrawalRequests: () => Promise<void>;
}